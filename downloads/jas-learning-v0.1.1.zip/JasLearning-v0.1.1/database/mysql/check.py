from concurrent.futures import ThreadPoolExecutor
import os
from pathlib import Path
import subprocess
import threading
import time
from uuid import uuid4
import pymysql

ROOT = Path(__file__).resolve().parents[2]


def connect(database=None):
    return pymysql.connect(
        host="127.0.0.1",
        port=53306,
        user="root",
        password=os.environ["LAB_PASSWORD"],
        database=database,
        autocommit=False,
        read_timeout=10,
        write_timeout=10,
    )


def main():
    name = "learning_mysql_" + uuid4().hex[:12]
    with connect() as admin, admin.cursor() as cursor:
        cursor.execute(f"CREATE DATABASE `{name}`")
    with connect(name) as connection, connection.cursor() as cursor:
        for statement in (Path(__file__).parent / "schema.sql").read_text().split(";"):
            if statement.strip():
                cursor.execute(statement)
        connection.commit()
    barrier = threading.Barrier(2)

    def buy():
        with connect(name) as connection, connection.cursor() as cursor:
            barrier.wait(timeout=5)
            cursor.execute(
                "UPDATE inventory SET stock=stock-1 WHERE id=%s AND stock>=1", (1,)
            )
            affected = cursor.rowcount
            connection.commit()
            return affected

    with ThreadPoolExecutor(2) as pool:
        futures = [pool.submit(buy) for _ in range(2)]
        assert sorted(future.result(timeout=10) for future in futures) == [0, 1]
    with connect(name) as first, first.cursor() as cursor:
        cursor.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ")
        cursor.execute(
            "SELECT * FROM prices WHERE price BETWEEN %s AND %s FOR UPDATE", (15, 25)
        )
        started = threading.Event()

        def insert():
            with connect(name) as second, second.cursor() as writer:
                writer.execute("SET innodb_lock_wait_timeout=5")
                started.set()
                writer.execute("INSERT INTO prices(price) VALUES(%s)", (20,))
                second.commit()

        with ThreadPoolExecutor(1) as pool:
            future = pool.submit(insert)
            assert started.wait(timeout=5)
            deadline = time.monotonic() + 4
            waiting = False
            while time.monotonic() < deadline:
                with connect() as inspector, inspector.cursor() as query:
                    query.execute(
                        "SELECT count(*) FROM performance_schema.data_lock_waits w JOIN performance_schema.data_locks l ON w.BLOCKING_ENGINE_LOCK_ID=l.ENGINE_LOCK_ID WHERE l.OBJECT_SCHEMA=%s AND l.OBJECT_NAME=%s",
                        (name, "prices"),
                    )
                    waiting = query.fetchone()[0] > 0
                if waiting:
                    break
                time.sleep(0.05)
            assert waiting, "未观察到范围锁等待，不能把顺序插入当作并发验证"
            first.commit()
            future.result(timeout=6)
    restored = name + "_restored"
    with connect() as admin, admin.cursor() as cursor:
        cursor.execute(f"CREATE DATABASE `{restored}`")
    base = [
        "docker",
        "compose",
        "-f",
        str(ROOT / "compose.yaml"),
        "exec",
        "-T",
        "mysql",
        "bash",
        "-c",
    ]
    backup = ROOT / ".local" / (name + ".sql")
    with backup.open("wb") as file:
        subprocess.run(
            base
            + [
                'MYSQL_PWD="$MYSQL_ROOT_PASSWORD" exec mysqldump -uroot --single-transaction --set-gtid-purged=OFF "$1"',
                "dump",
                name,
            ],
            stdout=file,
            check=True,
        )
    with backup.open("rb") as file:
        subprocess.run(
            base
            + [
                'MYSQL_PWD="$MYSQL_ROOT_PASSWORD" exec mysql -uroot "$1"',
                "restore",
                restored,
            ],
            stdin=file,
            check=True,
        )
    with connect(restored) as connection, connection.cursor() as cursor:
        cursor.execute("SELECT stock FROM inventory WHERE id=%s", (1,))
        assert cursor.fetchone()[0] == 0
        cursor.execute("SELECT count(*) FROM prices WHERE price=%s", (20,))
        assert cursor.fetchone()[0] == 1
        cursor.execute("SELECT version()")
        print(
            f"MySQL {cursor.fetchone()[0]}: race, RR range lock and independent restore passed; databases retained: {name}, {restored}"
        )


if __name__ == "__main__":
    main()
