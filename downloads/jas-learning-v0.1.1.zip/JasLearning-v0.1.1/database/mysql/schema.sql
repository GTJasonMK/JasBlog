CREATE TABLE inventory (
    id BIGINT PRIMARY KEY, stock INT NOT NULL CHECK(stock >= 0)
);
INSERT INTO inventory VALUES (1,1);
CREATE TABLE prices (
    id BIGINT PRIMARY KEY AUTO_INCREMENT, price INT NOT NULL, INDEX price_idx(price)
);
INSERT INTO prices(price) VALUES(10),(30);
