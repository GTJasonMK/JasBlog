"""每轮创建自己的数据库，保存恢复结果，绝不重置已有实验库。"""

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import os
import subprocess
import threading
import time
import uuid

import psycopg
from psycopg import sql
from psycopg.conninfo import make_conninfo

ROOT = Path(__file__).resolve().parent


def execute_file(connection, name):
    lines = (ROOT / "sql" / name).read_text().splitlines()
    assert all(
        not line.startswith("\\") or line == "\\set ON_ERROR_STOP on" for line in lines
    )
    connection.execute("\n".join(line for line in lines if not line.startswith("\\")))


def main():
    admin_url = os.environ["PG_ADMIN_URL"]
    name = "learning_verify_" + uuid.uuid4().hex[:12]
    with psycopg.connect(admin_url, autocommit=True) as admin:
        admin.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(name)))
    url = make_conninfo(admin_url, dbname=name)
    with psycopg.connect(url, autocommit=True) as connection:
        connection.execute("CREATE EXTENSION IF NOT EXISTS pg_stat_statements")
        for script in (
            "00-schema.sql",
            "01-seed.sql",
            "02-checks.sql",
            "03-place-order.sql",
            "04-order-checks.sql",
            "06-security-checks.sql",
        ):
            if script == "00-schema.sql":
                connection.execute("DROP EXTENSION pg_stat_statements")
            execute_file(connection, script)
        customer = connection.execute(
            "INSERT INTO shop.customers(email, display_name) VALUES (%s, '并发测试') RETURNING id",
            (f"{name}@example.invalid",),
        ).fetchone()[0]
        product = connection.execute(
            "INSERT INTO shop.products(sku,name,price_cents,stock) VALUES (%s,'并发商品',100,1) RETURNING id",
            (name,),
        ).fetchone()[0]
        connection.execute(
            "INSERT INTO shop.stock_movements(product_id,delta,reason) VALUES (%s,1,'opening')",
            (product,),
        )
    barrier = threading.Barrier(2)

    def order(key):
        try:
            with psycopg.connect(url) as connection:
                connection.execute("SET statement_timeout='10s'")
                barrier.wait(timeout=10)
                return connection.execute(
                    "SELECT shop.place_order(%s,%s,1,%s)", (customer, product, key)
                ).fetchone()[0]
        except psycopg.errors.RaiseException:
            return "sold_out"

    with ThreadPoolExecutor(2) as pool:
        futures = [pool.submit(order, key) for key in ("race-a", "race-b")]
        results = [future.result(timeout=15) for future in futures]
    assert results.count("sold_out") == 1, results
    with psycopg.connect(url, autocommit=True) as connection:
        assert (
            connection.execute(
                "SELECT stock FROM shop.products WHERE id=%s", (product,)
            ).fetchone()[0]
            == 0
        )
        assert (
            connection.execute(
                "SELECT count(*) FROM shop.orders WHERE customer_id=%s", (customer,)
            ).fetchone()[0]
            == 1
        )
        assert (
            connection.execute(
                "SELECT sum(delta) FROM shop.stock_movements WHERE product_id=%s",
                (product,),
            ).fetchone()[0]
            == 0
        )
        connection.execute("UPDATE shop.products SET stock=1 WHERE id=%s", (product,))
    barrier.reset()
    with ThreadPoolExecutor(2) as pool:
        futures = [pool.submit(order, "same-key") for _ in range(2)]
        duplicate = [future.result(timeout=15) for future in futures]
    assert duplicate[0] == duplicate[1] and isinstance(duplicate[0], int), duplicate
    with psycopg.connect(url) as connection:
        connection.execute("SET lock_timeout='1s'")
        connection.execute("ALTER TABLE shop.customers ADD COLUMN region text")
        connection.execute(
            "UPDATE shop.customers SET region='unknown' WHERE region IS NULL AND id <= %s",
            (2,),
        )
    with psycopg.connect(url) as connection:
        connection.execute(
            "UPDATE shop.customers SET region='unknown' WHERE region IS NULL"
        )
        connection.execute(
            "ALTER TABLE shop.customers ADD CONSTRAINT region_present CHECK(region IS NOT NULL) NOT VALID"
        )
        connection.execute(
            "ALTER TABLE shop.customers VALIDATE CONSTRAINT region_present"
        )
        connection.execute(
            "ALTER TABLE shop.customers ALTER COLUMN region SET NOT NULL"
        )
        assert (
            connection.execute(
                "SELECT count(*) FROM shop.customers WHERE region IS NULL"
            ).fetchone()[0]
            == 0
        )
    restored = name + "_restored"
    with psycopg.connect(admin_url, autocommit=True) as admin:
        admin.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(restored)))
    command = [
        "docker",
        "compose",
        "-f",
        str(ROOT.parent / "compose.yaml"),
        "exec",
        "-T",
        "postgres",
    ]
    backup = ROOT.parent / ".local" / f"{name}.dump"
    with backup.open("wb") as file:
        subprocess.run(
            command + ["pg_dump", "-U", "learning", "-Fc", name],
            stdout=file,
            check=True,
        )
    started = time.monotonic()
    with backup.open("rb") as file:
        subprocess.run(
            command
            + ["pg_restore", "-U", "learning", "--exit-on-error", "-d", restored],
            stdin=file,
            check=True,
        )
    with psycopg.connect(make_conninfo(admin_url, dbname=restored)) as connection:
        assert (
            connection.execute(
                "SELECT count(*) FROM shop.orders WHERE customer_id=%s", (customer,)
            ).fetchone()[0]
            == 2
        )
    print(
        f"PostgreSQL: baseline, rejection, concurrency, idempotency, migration and independent restore passed; restore={time.monotonic() - started:.3f}s"
    )
    print(f"保留专用实验库 {name}、{restored} 与本地备份供复查")


if __name__ == "__main__":
    main()
