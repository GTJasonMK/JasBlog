# JasLearning

教学工程与博客应用独立。按 `python/`、`go/`、`typescript/`、`database/` 管理依赖，禁止从其他应用仓库导入源码。通用规则见父目录和 `~/.codex/AGENTS.md`。

每个业务规则只保留一个实现。讲解引用源码路径和版本，阶段通过 Git 标签保存；不得复制整套工程保存阶段。新增业务分支须有行为测试，后端单测默认 60 秒超时。数据库、消息和浏览器边界使用实际依赖验证，依赖不可用时明确失败。

测试使用隔离容器和专用数据库，只清理自己创建的数据。凭据从环境读取，`.local/` 保存数据与验证输出且不提交。部署配置通过 `python scripts/check_deploy.py` 检查；未部署集群不能记录为集群运行通过。

`python scripts/package.py --destination ../JasBlog/public/downloads` 生成固定版本源码包和历史数据库附件。生成物不得手工编辑；源代码仅在本仓库维护。博客发布命令有外部副作用，不能用作测试。
