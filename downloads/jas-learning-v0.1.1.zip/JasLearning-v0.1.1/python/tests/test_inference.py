import joblib
import pandas as pd
from fastapi.testclient import TestClient
from sklearn.dummy import DummyRegressor
from learning.artifacts import atomic_json, sha256
from learning.forecast import FEATURES
from learning.inference import create_app


def test_inference_contract_and_service_auth(tmp_path):
    # 合同测试只训练一个基线；真实业务模型由 scripts/check_models.py 单独验证。
    model = DummyRegressor(strategy="constant", constant=10).fit(
        pd.DataFrame([[1] * 6], columns=FEATURES), [10]
    )
    joblib.dump(model, tmp_path / "model.joblib")
    atomic_json(
        tmp_path / "artifact.json",
        {
            "kind": "forecast",
            "version": "contract",
            "file": "model.joblib",
            "sha256": sha256(tmp_path / "model.joblib"),
            "features": FEATURES,
        },
    )
    token = "x" * 40
    with TestClient(create_app(tmp_path, "forecast", token)) as client:
        payload = {
            "target": "2012-01-08T00:00:00Z",
            "history": [
                {"timestamp": timestamp, "count": 10}
                for timestamp in (
                    "2012-01-07T23:00:00Z",
                    "2012-01-07T00:00:00Z",
                    "2012-01-01T00:00:00Z",
                )
            ],
        }
        assert client.post("/predict", json=payload).status_code == 401
        headers = {"authorization": "Bearer " + token}
        result = client.post("/predict", json=payload, headers=headers)
        assert result.status_code == 200 and result.json()["count"] == 10
        payload["history"].append({"timestamp": payload["target"], "count": 10})
        assert client.post("/predict", json=payload, headers=headers).status_code == 422
        assert (
            client.post(
                "/predict", content=b"x" * (6 * 1024 * 1024 + 1), headers=headers
            ).status_code
            == 413
        )
        assert client.get("/readyz").json()["version"] == "contract"
        assert "learning_inference_seconds" in client.get("/metrics").text
