from datetime import datetime, timedelta, timezone
import pandas as pd
import pytest
from learning.artifacts import atomic_json, sha256, verify
from learning.forecast import row, FEATURES
from learning.monitor import report


def test_prediction_time_and_lags():
    target = datetime(2012, 2, 1, tzinfo=timezone.utc)
    history = {
        pd.Timestamp(target - timedelta(hours=lag)): float(lag) for lag in (1, 24, 168)
    }
    assert row(target, history)[-3:] == [1.0, 24.0, 168.0]
    with pytest.raises(ValueError):
        row(target, {})
    with pytest.raises(ValueError):
        row(target.replace(tzinfo=None), history)


def test_corruption_and_monitoring(tmp_path):
    artifact = tmp_path / "model.bin"
    artifact.write_bytes(b"trusted local artifact")
    atomic_json(
        tmp_path / "artifact.json",
        {"kind": "test", "file": artifact.name, "sha256": sha256(artifact)},
    )
    assert verify(tmp_path, "test")["kind"] == "test"
    artifact.write_bytes(b"changed")
    with pytest.raises(ValueError):
        verify(tmp_path, "test")
    metadata = {"training_summary": {name: {"mean": 0, "std": 1} for name in FEATURES}}
    result = report(metadata, pd.DataFrame([{name: 2 for name in FEATURES}]))
    assert result["mae"] is None
    assert all(value["review"] for value in result["features"].values())
