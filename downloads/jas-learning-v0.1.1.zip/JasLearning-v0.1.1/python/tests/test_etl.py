import csv
import json
import pytest
import subprocess
import sys
from learning.etl import process


def test_resume_validate_and_preserve(tmp_path):
    source = tmp_path / "input"
    source.mkdir()
    output = tmp_path / "output"
    record = {
        "order_id": "A-1",
        "customer": "Ada",
        "quantity": 2,
        "unit_price": "12.50",
    }
    first = source / "one.jsonl"
    first.write_text(json.dumps(record) + "\n")
    result = process(source, output)
    assert result["processed"] == 1
    target = output / result["files"][0]["output"]
    assert list(csv.DictReader(target.open()))[0]["total"] == "25.00"
    assert process(source, output)["skipped"] == 1
    before = target.read_bytes()
    first.write_text(json.dumps({**record, "quantity": True}) + "\n")
    with pytest.raises(ValueError):
        process(source, output)
    assert target.read_bytes() == before
    first.write_text(json.dumps(record) + "\n")
    second = source / "two.jsonl"
    second.write_text(json.dumps(record) + "\n")
    with pytest.raises(ValueError):
        process(source, output)
    second.write_text(json.dumps({**record, "order_id": "A-2"}) + "\n")
    assert process(source, output)["processed"] == 1
    with pytest.raises(ValueError):
        process(source, source)


def test_cli_error_does_not_expose_bad_record(tmp_path):
    source = tmp_path / "input"
    source.mkdir()
    (source / "bad.jsonl").write_text(
        json.dumps(
            {
                "order_id": "A",
                "customer": "Private Customer",
                "quantity": {"private": "never-log-this-marker"},
                "unit_price": "1.00",
            }
        )
        + "\n"
    )
    result = subprocess.run(
        [sys.executable, "-m", "learning.etl", str(source), str(tmp_path / "output")],
        capture_output=True,
        text=True,
        timeout=10,
    )
    assert result.returncode != 0
    assert "第 1 行无效" in result.stderr
    assert "never-log-this-marker" not in result.stderr
