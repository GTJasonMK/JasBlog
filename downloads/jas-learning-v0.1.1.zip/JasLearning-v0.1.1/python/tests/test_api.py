import os
from uuid import uuid4
import psycopg
from psycopg import sql
from fastapi.testclient import TestClient
from sqlmodel import Session, select
from learning.api import create_app, Task
from learning.migrate import upgrade


def test_postgres_auth_ownership_and_patch():
    admin_url = os.environ["PG_ADMIN_URL"]
    database = "python_test_" + uuid4().hex
    with psycopg.connect(admin_url, autocommit=True) as admin:
        admin.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(database)))
    url = (
        admin_url.rsplit("/", 1)[0].replace("postgresql://", "postgresql+psycopg://")
        + "/"
        + database
    )
    upgrade(url)
    app = create_app(url)
    headers = {"origin": "http://localhost:5173"}
    credentials = {"email": "a@example.invalid", "password": "correct-password-1234"}
    with TestClient(app) as a, TestClient(app) as b:
        assert a.get("/tasks").status_code == 401
        assert a.post("/auth/register", json=credentials).status_code == 403
        created_user = a.post("/auth/register", json=credentials, headers=headers)
        assert created_user.status_code == 201
        assert "password_hash" not in created_user.json()
        original = a.cookies.get("learning_py")
        assert (
            b.post(
                "/auth/register",
                json={**credentials, "email": "b@example.invalid"},
                headers=headers,
            ).status_code
            == 201
        )
        task = a.post("/tasks", json={"title": "  发布  "}, headers=headers)
        assert task.status_code == 201
        identifier = task.json()["id"]
        assert a.get("/tasks").json()[0]["title"] == "发布"
        for method in (b.get, b.patch, b.delete):
            kwargs = {"json": {"done": True}} if method == b.patch else {}
            assert (
                method(f"/tasks/{identifier}", headers=headers, **kwargs).status_code
                == 404
            )
        for body in (
            {},
            {"title": None},
            {"done": None},
            {"done": "false"},
            {"title": "x" * 121},
        ):
            assert (
                a.patch(f"/tasks/{identifier}", json=body, headers=headers).status_code
                == 422
            )
        for done in (True, False):
            assert (
                a.patch(
                    f"/tasks/{identifier}", json={"done": done}, headers=headers
                ).json()["done"]
                is done
            )
        assert (
            a.post(
                "/tasks",
                json={"title": "x", "owner_id": created_user.json()["id"]},
                headers=headers,
            ).status_code
            == 422
        )
        with Session(app.state.engine) as session:
            assert session.exec(select(Task)).one().done is False
        assert a.post("/auth/logout", headers=headers).status_code == 204
        assert (
            a.get("/auth/me", headers={"Cookie": f"learning_py={original}"}).status_code
            == 401
        )
        assert (
            a.post("/auth/login", json=credentials, headers=headers).status_code == 200
        )
        assert a.delete(f"/tasks/{identifier}", headers=headers).status_code == 204
        assert a.get("/readyz").status_code == 200
