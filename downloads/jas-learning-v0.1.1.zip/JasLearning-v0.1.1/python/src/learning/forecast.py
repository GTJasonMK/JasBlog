"""用过去可获得的租车量预测下一小时需求。"""

import argparse
from datetime import timedelta
import json
from pathlib import Path
import platform

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, root_mean_squared_error
from sklearn.model_selection import TimeSeriesSplit

from learning.artifacts import atomic_json, sha256, verify

ZONE = "America/New_York"
LAGS = (1, 24, 168)
FEATURES = ["hour", "weekday", "month", "lag_1", "lag_24", "lag_168"]


def row(timestamp, history):
    timestamp = pd.Timestamp(timestamp)
    if (
        timestamp.tzinfo is None
        or timestamp.minute
        or timestamp.second
        or timestamp.microsecond
    ):
        raise ValueError("目标时间必须包含时区，并精确到整小时")
    timestamp = timestamp.tz_convert("UTC")
    local = timestamp.tz_convert(ZONE)
    values = []
    for lag in LAGS:
        value = history.get(timestamp - timedelta(hours=lag))
        if value is None or not np.isfinite(value) or value < 0:
            raise ValueError(f"缺少有效的 {lag} 小时历史需求")
        values.append(float(value))
    return [local.hour, local.day_of_week, local.month, *values]


def dataset(path):
    frame = pd.read_csv(path)
    required = {"dteday", "hr", "cnt"}
    if not required <= set(frame.columns):
        raise ValueError("需求数据缺少日期、小时或目标")
    if not pd.to_numeric(frame["hr"], errors="raise").between(0, 23).all():
        raise ValueError("小时超出范围")
    index = pd.to_datetime(frame["dteday"], errors="raise") + pd.to_timedelta(
        frame["hr"], unit="h"
    )
    if index.duplicated().any():
        raise ValueError("同一当地小时出现重复记录")
    aware = (
        pd.DatetimeIndex(index)
        .tz_localize(ZONE, ambiguous="NaT", nonexistent="NaT")
        .tz_convert("UTC")
    )
    values = pd.to_numeric(frame["cnt"], errors="raise")
    if not np.isfinite(values).all() or (values < 0).any():
        raise ValueError("需求必须是有限非负数")
    valid = ~aware.isna()
    demand = pd.Series(values.to_numpy()[valid], index=aware[valid]).sort_index()
    grid = demand.reindex(
        pd.date_range(demand.index.min(), demand.index.max(), freq="h")
    )
    local = grid.index.tz_convert(ZONE)
    features = pd.DataFrame(
        {"hour": local.hour, "weekday": local.day_of_week, "month": local.month},
        index=grid.index,
    )
    for lag in LAGS:
        features[f"lag_{lag}"] = grid.shift(lag)
    joined = features.assign(target=grid).dropna()
    return (
        joined[FEATURES],
        joined["target"],
        {
            "source_rows": len(frame),
            "ambiguous_hours_excluded": int((~valid).sum()),
            "usable_rows": len(joined),
            "missing_hours": int(grid.isna().sum()),
        },
    )


def train(source, output):
    source = Path(source)
    output = Path(output)
    data_hash = sha256(source)
    if (output / "artifact.json").exists():
        metadata = verify(output, "forecast")
        if metadata["data_sha256"] != data_hash:
            raise ValueError("输入已经变化，请使用新的模型版本目录")
        return metadata
    features, target, diagnostics = dataset(source)
    cutoff = pd.Timestamp("2012-10-01", tz=ZONE)
    training = features.index < cutoff
    if training.sum() < 1000 or (~training).sum() < 100:
        raise ValueError("训练或独立测试的样本不足")
    train_x, test_x = features.loc[training], features.loc[~training]
    train_y, test_y = target.loc[training], target.loc[~training]
    reports = []
    for depth in (3, 6):
        folds = []
        for fit, validation in TimeSeriesSplit(n_splits=3, gap=1).split(train_x):
            model = HistGradientBoostingRegressor(
                loss="poisson",
                max_depth=depth,
                max_iter=100,
                early_stopping=False,
                random_state=42,
            )
            model.fit(train_x.iloc[fit], train_y.iloc[fit])
            folds.append(
                float(
                    mean_absolute_error(
                        train_y.iloc[validation],
                        model.predict(train_x.iloc[validation]),
                    )
                )
            )
        reports.append(
            {"max_depth": depth, "fold_mae": folds, "mean_mae": float(np.mean(folds))}
        )
    best = min(reports, key=lambda value: value["mean_mae"])
    model = HistGradientBoostingRegressor(
        loss="poisson",
        max_depth=best["max_depth"],
        max_iter=100,
        early_stopping=False,
        random_state=42,
    )
    model.fit(train_x, train_y)
    predicted = model.predict(test_x)
    baseline = test_x["lag_168"].to_numpy()
    metrics = {
        "mae": float(mean_absolute_error(test_y, predicted)),
        "rmse": float(root_mean_squared_error(test_y, predicted)),
        "baseline_mae": float(mean_absolute_error(test_y, baseline)),
    }
    by_hour = []
    for hour in range(24):
        mask = test_x["hour"] == hour
        if mask.any():
            by_hour.append(
                {
                    "hour": hour,
                    "count": int(mask.sum()),
                    "mae": float(mean_absolute_error(test_y[mask], predicted[mask])),
                }
            )
    output.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, output / "forecast.joblib")
    restored = joblib.load(output / "forecast.joblib")
    np.testing.assert_allclose(restored.predict(test_x.iloc[:10]), predicted[:10])
    metadata = {
        "kind": "forecast",
        "version": output.name,
        "file": "forecast.joblib",
        "sha256": sha256(output / "forecast.joblib"),
        "data_sha256": data_hash,
        "features": FEATURES,
        "timezone": ZONE,
        "python": platform.python_version(),
        "selection": reports,
        "diagnostics": diagnostics,
        "metrics": metrics,
        "by_hour": by_hour,
        "release_recommended": metrics["mae"] < metrics["baseline_mae"],
        "training_summary": {
            name: {
                "mean": float(train_x[name].mean()),
                "std": float(train_x[name].std()),
            }
            for name in FEATURES
        },
    }
    atomic_json(output / "artifact.json", metadata)
    return metadata


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    print(json.dumps(train(args.source, args.output), ensure_ascii=False, indent=2))
