"""按文件保存进度的订单 JSONL 到 CSV 转换。"""

import argparse
import csv
from decimal import Decimal
import fcntl
import hashlib
import json
import os
from pathlib import Path
import sqlite3
from tempfile import NamedTemporaryFile

from pydantic import BaseModel, ConfigDict, Field, StrictInt, field_validator


class Order(BaseModel):
    model_config = ConfigDict(extra="forbid", hide_input_in_errors=True)
    order_id: str = Field(pattern=r"^[A-Za-z0-9_-]{1,64}$")
    customer: str = Field(min_length=1, max_length=120)
    quantity: StrictInt = Field(ge=1, le=1_000_000)
    unit_price: str = Field(pattern=r"^\d{1,12}(\.\d{1,2})?$")

    @field_validator("customer")
    @classmethod
    def customer_not_blank(cls, value):
        if not value.strip():
            raise ValueError("客户名不能为空")
        return value.strip()


def digest(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()


def process(source: Path, output: Path):
    source = source.resolve(strict=True)
    output = output.resolve()
    if not source.is_dir() or output == source or output.is_relative_to(source):
        raise ValueError("输出必须是输入目录之外的独立目录")
    files = sorted(source.glob("*.jsonl"))
    if not files:
        raise ValueError("输入目录没有 JSONL 文件")
    output.mkdir(parents=True, exist_ok=True)
    report = {"processed": 0, "skipped": 0, "files": []}
    with (
        (output / ".lock").open("a") as lock,
        sqlite3.connect(output / "state.sqlite") as state,
    ):
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        state.execute(
            "CREATE TABLE IF NOT EXISTS files (source TEXT PRIMARY KEY, input_hash TEXT NOT NULL, output_hash TEXT NOT NULL, rows INTEGER NOT NULL)"
        )
        state.execute(
            "CREATE TABLE IF NOT EXISTS orders (order_id TEXT PRIMARY KEY, source TEXT NOT NULL)"
        )
        state.commit()
        for path in files:
            source_key = path.name
            fingerprint = digest(path)
            target = output / (
                hashlib.sha256(source_key.encode()).hexdigest()[:24] + ".csv"
            )
            previous = state.execute(
                "SELECT input_hash,output_hash,rows FROM files WHERE source=?",
                (source_key,),
            ).fetchone()
            if (
                previous
                and previous[0] == fingerprint
                and target.exists()
                and previous[1] == digest(target)
            ):
                report["skipped"] += 1
                report["files"].append(
                    {"source": source_key, "output": target.name, "rows": previous[2]}
                )
                continue
            temporary = None
            try:
                state.execute("BEGIN IMMEDIATE")
                state.execute("DELETE FROM orders WHERE source=?", (source_key,))
                rows = 0
                with (
                    path.open("r", encoding="utf-8") as incoming,
                    NamedTemporaryFile(
                        mode="w", encoding="utf-8", newline="", dir=output, delete=False
                    ) as outgoing,
                ):
                    temporary = Path(outgoing.name)
                    writer = csv.DictWriter(
                        outgoing, fieldnames=["order_id", "quantity", "total"]
                    )
                    writer.writeheader()
                    while line := incoming.readline(1_048_577):
                        if len(line.encode("utf-8")) > 1_048_576:
                            raise ValueError(f"{source_key} 第 {rows + 1} 行超过 1 MiB")
                        try:
                            order = Order.model_validate(json.loads(line))
                            state.execute(
                                "INSERT INTO orders(order_id,source) VALUES(?,?)",
                                (order.order_id, source_key),
                            )
                        except (ValueError, sqlite3.IntegrityError) as error:
                            raise ValueError(
                                f"{source_key} 第 {rows + 1} 行无效或订单编号重复"
                            ) from error
                        writer.writerow(
                            {
                                "order_id": order.order_id,
                                "quantity": order.quantity,
                                "total": f"{Decimal(order.unit_price) * order.quantity:.2f}",
                            }
                        )
                        rows += 1
                    outgoing.flush()
                    os.fsync(outgoing.fileno())
                if digest(path) != fingerprint:
                    raise ValueError("处理过程中输入发生变化，请保留成果并重试")
                output_hash = digest(temporary)
                state.execute(
                    "INSERT INTO files VALUES(?,?,?,?) ON CONFLICT(source) DO UPDATE SET input_hash=excluded.input_hash, output_hash=excluded.output_hash, rows=excluded.rows",
                    (source_key, fingerprint, output_hash, rows),
                )
                os.replace(temporary, target)
                directory = os.open(output, os.O_DIRECTORY)
                try:
                    os.fsync(directory)
                finally:
                    os.close(directory)
                state.commit()
            except BaseException:
                state.rollback()
                raise
            finally:
                if temporary:
                    temporary.unlink(missing_ok=True)
            report["processed"] += 1
            report["files"].append(
                {"source": source_key, "output": target.name, "rows": rows}
            )
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    print(json.dumps(process(args.source, args.output), ensure_ascii=False, indent=2))
