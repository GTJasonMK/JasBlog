import os
from learning.api import create_app

app = create_app(
    os.environ["PY_DATABASE_URL"],
    os.environ["APP_ORIGIN"],
    os.environ.get("APP_ENV") == "production",
)
