from pathlib import Path
import os
from alembic.config import Config
from alembic import command


def upgrade(url):
    config = Config(str(Path(__file__).with_name("alembic.ini")))
    config.set_main_option("sqlalchemy.url", url.replace("%", "%%"))
    command.upgrade(config, "head")


if __name__ == "__main__":
    upgrade(os.environ["PY_DATABASE_URL"])
