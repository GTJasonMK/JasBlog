import hashlib
import json
import os
from pathlib import Path
from tempfile import NamedTemporaryFile


def sha256(path):
    with Path(path).open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=path.parent, delete=False
        ) as file:
            temporary = Path(file.name)
            json.dump(value, file, ensure_ascii=False, indent=2, allow_nan=False)
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary, path)
    finally:
        if temporary:
            temporary.unlink(missing_ok=True)


def verify(directory, kind):
    directory = Path(directory)
    metadata = json.loads((directory / "artifact.json").read_text())
    if Path(metadata["file"]).name != metadata["file"]:
        raise ValueError("模型文件必须位于当前版本目录")
    if metadata["kind"] != kind or metadata["sha256"] != sha256(
        directory / metadata["file"]
    ):
        raise ValueError("模型类型或内容摘要不符")
    return metadata
