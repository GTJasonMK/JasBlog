from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
import hashlib
import json
import logging
import secrets
import time
from uuid import UUID, uuid4
from typing import Annotated

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from fastapi import Depends, FastAPI, HTTPException, Request, Response
from fastapi.exceptions import RequestValidationError
from pydantic import (
    BaseModel,
    ConfigDict,
    Field as InputField,
    StringConstraints,
    field_validator,
)
from prometheus_client import (
    CollectorRegistry,
    Histogram,
    generate_latest,
    CONTENT_TYPE_LATEST,
)
from sqlalchemy import CheckConstraint, Column, DateTime, Index, text
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from psycopg.errors import UniqueViolation
from sqlmodel import Field, Session, SQLModel, create_engine, select
from learning.http import BodyLimit


def now():
    return datetime.now(timezone.utc)


class User(SQLModel, table=True):
    __tablename__ = "app_users"
    id: UUID = Field(default_factory=uuid4, primary_key=True)
    email: str = Field(unique=True, max_length=254)
    password_hash: str


class LoginSession(SQLModel, table=True):
    __tablename__ = "login_sessions"
    token_hash: str = Field(primary_key=True, max_length=64)
    user_id: UUID = Field(foreign_key="app_users.id", index=True)
    started_at: datetime = Field(
        sa_column=Column(DateTime(timezone=True), nullable=False)
    )
    seen_at: datetime = Field(sa_column=Column(DateTime(timezone=True), nullable=False))


class Task(SQLModel, table=True):
    __tablename__ = "tasks"
    __table_args__ = (
        CheckConstraint("length(trim(title)) > 0", name="task_title_nonempty"),
        Index("ix_tasks_owner_id", "owner_id", "id"),
    )
    id: UUID = Field(default_factory=uuid4, primary_key=True)
    owner_id: UUID = Field(foreign_key="app_users.id")
    title: str = Field(max_length=120)
    done: bool = False


class AuthLimit(SQLModel, table=True):
    __tablename__ = "auth_limits"
    key: str = Field(primary_key=True, max_length=64)
    minute: datetime = Field(sa_column=Column(DateTime(timezone=True), nullable=False))
    hits: int


class Credentials(BaseModel):
    model_config = ConfigDict(extra="forbid")
    email: str = InputField(
        min_length=3, max_length=254, pattern=r"^[^\s@]+@[^\s@]+\.[^\s@]+$"
    )
    password: str = InputField(min_length=12, max_length=128)

    @field_validator("email")
    @classmethod
    def normalize(cls, value):
        return value.lower()


class PublicUser(BaseModel):
    id: UUID
    email: str


Title = Annotated[
    str, StringConstraints(strip_whitespace=True, min_length=1, max_length=120)
]


class TaskCreate(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    title: Title
    done: bool = False


class TaskUpdate(TaskCreate):
    title: Title | None = None
    done: bool | None = None


class PublicTask(BaseModel):
    id: UUID
    title: str
    done: bool


def token_hash(value):
    return hashlib.sha256(value.encode()).hexdigest()


def create_app(database_url: str, origin="http://localhost:5173", production=False):
    if not database_url.startswith("postgresql+psycopg://"):
        raise ValueError("完整工程使用 PostgreSQL + psycopg，请显式设置连接地址")
    if production and not origin.startswith("https://"):
        raise ValueError("生产来源必须为 HTTPS")
    engine = create_engine(
        database_url,
        pool_size=5,
        max_overflow=0,
        pool_pre_ping=True,
        connect_args={"connect_timeout": 3, "options": "-c statement_timeout=10000"},
    )
    hasher = PasswordHasher()
    registry = CollectorRegistry()
    latency = Histogram(
        "learning_python_http_seconds",
        "HTTP duration",
        ["method", "route", "status"],
        registry=registry,
    )

    @asynccontextmanager
    async def lifespan(_app):
        with Session(engine) as session:
            session.exec(select(Task).limit(1)).all()
        yield
        engine.dispose()

    app = FastAPI(lifespan=lifespan)
    app.add_middleware(BodyLimit, limit=16 * 1024)
    app.state.engine = engine

    @app.exception_handler(RequestValidationError)
    async def invalid_input(_request, error):
        detail = [
            {key: item[key] for key in ("loc", "msg", "type")}
            for item in error.errors()
        ]
        return Response(
            content=json.dumps({"detail": detail}),
            status_code=422,
            media_type="application/json",
        )

    @app.middleware("http")
    async def boundary(request: Request, call_next):
        request_id = uuid4().hex
        started = time.monotonic()
        if (
            request.method not in {"GET", "HEAD", "OPTIONS"}
            and request.headers.get("origin") != origin
        ):
            return Response(
                content='{"detail":"请求来源不匹配"}',
                status_code=403,
                media_type="application/json",
            )
        response = await call_next(request)
        route = getattr(request.scope.get("route"), "path", "unmatched")
        latency.labels(request.method, route, response.status_code).observe(
            time.monotonic() - started
        )
        response.headers["X-Request-Id"] = request_id
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        logging.info(
            json.dumps(
                {
                    "request_id": request_id,
                    "route": route,
                    "status": response.status_code,
                }
            )
        )
        return response

    @app.exception_handler(SQLAlchemyError)
    async def database_error(_request, error):
        logging.error("database_error type=%s", type(error).__name__)
        return Response(
            content='{"detail":"数据库暂时不可用"}',
            status_code=503,
            media_type="application/json",
        )

    def database():
        with Session(engine) as session:
            yield session

    def identity(request: Request, session: Session = Depends(database)):
        token = request.cookies.get("learning_py")
        login = (
            session.get(LoginSession, token_hash(token))
            if token and len(token) <= 128
            else None
        )
        if (
            not login
            or now() - login.started_at >= timedelta(hours=8)
            or now() - login.seen_at >= timedelta(minutes=30)
        ):
            raise HTTPException(401, "请重新登录")
        user = session.get(User, login.user_id)
        if not user:
            raise HTTPException(401, "用户不存在")
        login.seen_at = now()
        session.add(login)
        session.commit()
        return user

    def rate_limit(request: Request, session: Session):
        address = request.client.host if request.client else "unknown"
        result = session.execute(
            text("""
            INSERT INTO auth_limits(key, minute, hits) VALUES (:key, date_trunc('minute', CURRENT_TIMESTAMP), 1)
            ON CONFLICT (key) DO UPDATE SET
              hits=CASE WHEN auth_limits.minute=EXCLUDED.minute THEN auth_limits.hits+1 ELSE 1 END,
              minute=EXCLUDED.minute RETURNING hits
        """),
            {"key": token_hash(address)},
        ).scalar_one()
        session.commit()
        if result > 20:
            raise HTTPException(429, "请求过于频繁，请稍后重试")

    def establish(session, user, response):
        token = secrets.token_urlsafe(32)
        session.add(
            LoginSession(
                token_hash=token_hash(token),
                user_id=user.id,
                started_at=now(),
                seen_at=now(),
            )
        )
        session.commit()
        response.set_cookie(
            "learning_py",
            token,
            max_age=1800,
            httponly=True,
            secure=production,
            samesite="lax",
            path="/",
        )
        return PublicUser(id=user.id, email=user.email)

    @app.post("/auth/register", response_model=PublicUser, status_code=201)
    def register(
        data: Credentials,
        request: Request,
        response: Response,
        session: Session = Depends(database),
    ):
        rate_limit(request, session)
        user = User(email=data.email, password_hash=hasher.hash(data.password))
        session.add(user)
        try:
            session.flush()
            return establish(session, user, response)
        except IntegrityError as error:
            session.rollback()
            if (
                isinstance(error.orig, UniqueViolation)
                and error.orig.diag.constraint_name == "app_users_email_key"
            ):
                raise HTTPException(409, "该邮箱无法注册")
            raise

    @app.post("/auth/login", response_model=PublicUser)
    def login(
        data: Credentials,
        request: Request,
        response: Response,
        session: Session = Depends(database),
    ):
        rate_limit(request, session)
        user = session.exec(select(User).where(User.email == data.email)).first()
        if user is None:
            raise HTTPException(401, "邮箱或密码错误")
        try:
            hasher.verify(user.password_hash, data.password)
        except VerifyMismatchError:
            raise HTTPException(401, "邮箱或密码错误")
        return establish(session, user, response)

    @app.get("/auth/me", response_model=PublicUser)
    def me(user: User = Depends(identity)):
        return PublicUser(id=user.id, email=user.email)

    @app.post("/auth/logout", status_code=204)
    def logout(request: Request, session: Session = Depends(database)):
        token = request.cookies.get("learning_py")
        login = (
            session.get(LoginSession, token_hash(token))
            if token and len(token) <= 128
            else None
        )
        if login:
            session.delete(login)
            session.commit()
        response = Response(status_code=204)
        response.delete_cookie(
            "learning_py", path="/", httponly=True, secure=production, samesite="lax"
        )
        return response

    @app.post("/tasks", response_model=PublicTask, status_code=201)
    def create_task(
        data: TaskCreate,
        user: User = Depends(identity),
        session: Session = Depends(database),
    ):
        task = Task(owner_id=user.id, **data.model_dump())
        session.add(task)
        session.commit()
        session.refresh(task)
        return task

    @app.get("/tasks", response_model=list[PublicTask])
    def tasks(
        after: UUID | None = None,
        limit: int = 20,
        user: User = Depends(identity),
        session: Session = Depends(database),
    ):
        if not 1 <= limit <= 50:
            raise HTTPException(422, "limit 范围为 1 至 50")
        query = select(Task).where(Task.owner_id == user.id)
        if after:
            query = query.where(Task.id > after)
        return session.exec(query.order_by(Task.id).limit(limit)).all()

    def owned(session, user, task_id):
        task = session.exec(
            select(Task)
            .where(Task.id == task_id, Task.owner_id == user.id)
            .with_for_update()
        ).first()
        if task is None:
            raise HTTPException(404, "任务不存在")
        return task

    @app.get("/tasks/{task_id}", response_model=PublicTask)
    def task(
        task_id: UUID,
        user: User = Depends(identity),
        session: Session = Depends(database),
    ):
        return owned(session, user, task_id)

    @app.patch("/tasks/{task_id}", response_model=PublicTask)
    def update(
        task_id: UUID,
        data: TaskUpdate,
        user: User = Depends(identity),
        session: Session = Depends(database),
    ):
        changes = data.model_dump(exclude_unset=True)
        if not changes or any(value is None for value in changes.values()):
            raise HTTPException(422, "至少提供一个非空更新字段")
        task = owned(session, user, task_id)
        for key, value in changes.items():
            setattr(task, key, value)
        session.add(task)
        session.commit()
        session.refresh(task)
        return task

    @app.delete("/tasks/{task_id}", status_code=204)
    def delete(
        task_id: UUID,
        user: User = Depends(identity),
        session: Session = Depends(database),
    ):
        session.delete(owned(session, user, task_id))
        session.commit()
        return Response(status_code=204)

    @app.get("/healthz")
    def alive():
        return {"status": "alive"}

    @app.get("/readyz")
    def ready(session: Session = Depends(database)):
        session.exec(select(Task.id).limit(1)).all()
        return {"status": "ready"}

    @app.get("/metrics")
    def metrics():
        return Response(generate_latest(registry), media_type=CONTENT_TYPE_LATEST)

    return app
