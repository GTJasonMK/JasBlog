"""用同一特征合同区分输入变化与取得标签后的预测误差。"""

import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error
from learning.forecast import FEATURES


def report(metadata, frame):
    if not set(FEATURES) <= set(frame.columns) or len(frame) == 0:
        raise ValueError("缺少特征或输入为空")
    result = {"rows": len(frame), "features": {}}
    for name in FEATURES:
        values = pd.to_numeric(frame[name], errors="raise")
        if not np.isfinite(values).all():
            raise ValueError("输入包含缺失或非有限数")
        reference = metadata["training_summary"][name]
        scale = max(reference["std"], 1e-12)
        distance = float(abs(values.mean() - reference["mean"]) / scale)
        # shortcut: 单位标准差仅为教学阈值，形成业务告警前须验证误报预算。
        result["features"][name] = {
            "standardized_mean_change": distance,
            "review": distance > 1,
        }
    if {"actual", "predicted"} <= set(frame.columns):
        result["mae"] = float(mean_absolute_error(frame["actual"], frame["predicted"]))
    else:
        result["mae"] = None
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("metadata", type=Path)
    parser.add_argument("observations", type=Path)
    args = parser.parse_args()
    print(
        json.dumps(
            report(
                json.loads(args.metadata.read_text()), pd.read_csv(args.observations)
            ),
            indent=2,
        )
    )
