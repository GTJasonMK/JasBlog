from alembic import context
from sqlalchemy import engine_from_config, pool
from sqlmodel import SQLModel
from learning import api  # noqa: F401 导入模型，注册迁移所需元数据。

config = context.config
engine = engine_from_config(
    config.get_section(config.config_ini_section),
    prefix="sqlalchemy.",
    poolclass=pool.NullPool,
)
with engine.connect() as connection:
    context.configure(connection=connection, target_metadata=SQLModel.metadata)
    with context.begin_transaction():
        context.run_migrations()
engine.dispose()
