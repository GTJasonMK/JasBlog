"""任务、身份与持久化会话的初始合同。"""

from alembic import op
import sqlalchemy as sa

revision = "001"
down_revision = None


def upgrade():
    op.create_table(
        "app_users",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column("email", sa.String(254), nullable=False, unique=True),
        sa.Column("password_hash", sa.String(), nullable=False),
    )
    op.create_table(
        "login_sessions",
        sa.Column("token_hash", sa.String(64), primary_key=True),
        sa.Column("user_id", sa.Uuid(), sa.ForeignKey("app_users.id"), nullable=False),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("seen_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_login_sessions_user_id", "login_sessions", ["user_id"])
    op.create_table(
        "tasks",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column("owner_id", sa.Uuid(), sa.ForeignKey("app_users.id"), nullable=False),
        sa.Column("title", sa.String(120), nullable=False),
        sa.Column("done", sa.Boolean(), nullable=False),
        sa.CheckConstraint("length(trim(title)) > 0", name="task_title_nonempty"),
    )
    op.create_index("ix_tasks_owner_id", "tasks", ["owner_id", "id"])
    op.create_table(
        "auth_limits",
        sa.Column("key", sa.String(64), primary_key=True),
        sa.Column("minute", sa.DateTime(timezone=True), nullable=False),
        sa.Column("hits", sa.Integer(), nullable=False),
    )


def downgrade():
    for table in ("auth_limits", "tasks", "login_sessions", "app_users"):
        op.drop_table(table)
