"""用田间叶片图片训练可保存、恢复和交付的分类器。"""

import argparse
import copy
import json
import os
from pathlib import Path

import torch
from PIL import Image, ImageOps
from sklearn.metrics import classification_report, confusion_matrix, f1_score
from torch import nn
from torchvision import datasets, models, transforms

from learning.artifacts import atomic_json, sha256, verify

CLASSES = ["angular_leaf_spot", "bean_rust", "healthy"]


def transform(training=False):
    steps = (
        [transforms.RandomResizedCrop(224), transforms.RandomHorizontalFlip()]
        if training
        else [transforms.Resize(256), transforms.CenterCrop(224)]
    )
    return transforms.Compose(
        [
            *steps,
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
        ]
    )


def image_loader(path):
    with Image.open(path) as image:
        return ImageOps.exif_transpose(image).convert("RGB")


def network(pretrained=False):
    model = models.resnet18(
        weights=models.ResNet18_Weights.IMAGENET1K_V1 if pretrained else None
    )
    for parameter in model.parameters():
        parameter.requires_grad = False
    model.fc = nn.Linear(model.fc.in_features, len(CLASSES))
    return model


def evaluate(model, loader):
    model.eval()
    actual, predicted = [], []
    with torch.inference_mode():
        for images, labels in loader:
            actual.extend(labels.tolist())
            predicted.extend(model(images).argmax(1).tolist())
    return actual, predicted


def train(training, validation, testing, output, epochs=5, limit_per_class=None):
    if (
        epochs < 1
        or epochs > 100
        or (limit_per_class is not None and limit_per_class < 1)
    ):
        raise ValueError("训练轮数或样本上限无效")
    torch.set_num_threads(2)
    torch.manual_seed(42)
    output = Path(output)
    arguments = {"epochs": epochs, "limit_per_class": limit_per_class}
    collections = [
        datasets.ImageFolder(str(path), transform(index == 0), loader=image_loader)
        for index, path in enumerate((training, validation, testing))
    ]
    if any(collection.classes != CLASSES for collection in collections):
        raise ValueError("类别名称或顺序与合同不符")
    fingerprints = []
    for collection in collections:
        fingerprints.append({sha256(path) for path, _ in collection.samples})
    if any(fingerprints[a] & fingerprints[b] for a, b in ((0, 1), (0, 2), (1, 2))):
        raise ValueError("训练、验证或测试集包含相同图片")
    data_hashes = [sorted(value) for value in fingerprints]
    if (output / "artifact.json").exists():
        metadata = verify(output, "vision")
        if metadata["arguments"] != arguments or metadata["data_sha256"] != data_hashes:
            raise ValueError("训练参数或数据变化，请使用新版本目录")
        return metadata
    if limit_per_class is not None:
        subsets = []
        for collection in collections:
            chosen = []
            for label in range(len(CLASSES)):
                chosen.extend(
                    [
                        index
                        for index, target in enumerate(collection.targets)
                        if target == label
                    ][:limit_per_class]
                )
            subsets.append(torch.utils.data.Subset(collection, chosen))
    else:
        subsets = collections
    generator = torch.Generator().manual_seed(42)
    loaders = [
        torch.utils.data.DataLoader(
            collection,
            batch_size=16,
            shuffle=index == 0,
            num_workers=0,
            generator=generator,
        )
        for index, collection in enumerate(subsets)
    ]
    model = network(pretrained=True)
    optimizer = torch.optim.Adam(model.fc.parameters(), lr=0.001)
    output.mkdir(parents=True, exist_ok=True)
    checkpoint = output / "checkpoint.pth"
    start, best_score, best_weights = 0, -1.0, copy.deepcopy(model.state_dict())
    if checkpoint.exists():
        saved = torch.load(checkpoint, map_location="cpu", weights_only=True)
        if saved["arguments"] != arguments or saved["data_sha256"] != data_hashes:
            raise ValueError("未完成训练的参数不符，请使用新版本目录")
        model.load_state_dict(saved["weights"])
        optimizer.load_state_dict(saved["optimizer"])
        start, best_score, best_weights = (
            saved["epoch"],
            saved["best_score"],
            saved["best_weights"],
        )
        torch.set_rng_state(saved["random_state"])
        generator.set_state(saved["generator_state"])
    for epoch in range(start, epochs):
        model.eval()
        model.fc.train()
        for images, labels in loaders[0]:
            optimizer.zero_grad()
            loss = nn.functional.cross_entropy(model(images), labels)
            loss.backward()
            optimizer.step()
        actual, predicted = evaluate(model, loaders[1])
        score = float(f1_score(actual, predicted, average="macro", zero_division=0))
        if score > best_score:
            best_score, best_weights = score, copy.deepcopy(model.state_dict())
        temporary = output / "checkpoint.tmp"
        torch.save(
            {
                "epoch": epoch + 1,
                "weights": model.state_dict(),
                "optimizer": optimizer.state_dict(),
                "best_score": best_score,
                "best_weights": best_weights,
                "arguments": arguments,
                "data_sha256": data_hashes,
                "random_state": torch.get_rng_state(),
                "generator_state": generator.get_state(),
            },
            temporary,
        )
        os.replace(temporary, checkpoint)
        print(f"epoch={epoch + 1} validation_macro_f1={score:.4f}", flush=True)
    model.load_state_dict(best_weights)
    actual, predicted = evaluate(model, loaders[2])
    torch.save(model.state_dict(), output / "vision.pth")
    restored = network()
    restored.load_state_dict(
        torch.load(output / "vision.pth", map_location="cpu", weights_only=True)
    )
    restored.eval()
    example = next(iter(loaders[2]))[0][:1]
    with torch.inference_mode():
        torch.testing.assert_close(model(example), restored(example))
    metadata = {
        "kind": "vision",
        "version": output.name,
        "file": "vision.pth",
        "sha256": sha256(output / "vision.pth"),
        "classes": CLASSES,
        "arguments": arguments,
        "validation_macro_f1": best_score,
        "test_report": classification_report(
            actual,
            predicted,
            labels=list(range(3)),
            target_names=CLASSES,
            output_dict=True,
            zero_division=0,
        ),
        "confusion_matrix": confusion_matrix(
            actual, predicted, labels=list(range(3))
        ).tolist(),
        "smoke_only": limit_per_class is not None,
        "dataset_sizes": [len(collection) for collection in subsets],
        "data_sha256": [sorted(value) for value in fingerprints],
    }
    atomic_json(output / "artifact.json", metadata)
    return metadata


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("training", "validation", "testing", "output"):
        parser.add_argument(name, type=Path)
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--limit-per-class", type=int)
    args = parser.parse_args()
    result = train(
        args.training,
        args.validation,
        args.testing,
        args.output,
        args.epochs,
        args.limit_per_class,
    )
    print(
        json.dumps(
            {key: value for key, value in result.items() if key != "data_sha256"},
            ensure_ascii=False,
            indent=2,
        )
    )
