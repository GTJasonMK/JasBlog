from fastapi import HTTPException
from starlette.responses import JSONResponse


class BodyLimit:
    def __init__(self, app, limit):
        self.app = app
        self.limit = limit

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        headers = dict(scope["headers"])
        try:
            length = int(headers.get(b"content-length", b"0"))
        except ValueError:
            return await JSONResponse({"detail": "Content-Length 无效"}, 400)(
                scope, receive, send
            )
        if length > self.limit:
            return await JSONResponse({"detail": "请求体过大"}, 413)(
                scope, receive, send
            )
        received = 0

        async def limited_receive():
            nonlocal received
            message = await receive()
            if message["type"] == "http.request":
                received += len(message.get("body", b""))
                if received > self.limit:
                    raise HTTPException(413, "请求体过大")
            return message

        await self.app(scope, limited_receive, send)
