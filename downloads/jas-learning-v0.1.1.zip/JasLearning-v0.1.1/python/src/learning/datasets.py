"""显式下载固定来源；校验通过以后才替换正式文件。"""

import argparse
import hashlib
import json
import os
from pathlib import Path
from tempfile import NamedTemporaryFile
from urllib.request import urlopen
from zipfile import ZipFile

LOCK = Path(__file__).resolve().parents[2] / "datasets.json"


def fetch(name, destination):
    specification = json.loads(LOCK.read_text())[name]
    expected = specification["sha256"]
    if len(expected) != 64:
        raise ValueError("数据来源尚未固定 SHA256，不能作为可复现数据下载")
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    archive = destination / f"{name}.zip"
    if archive.exists():
        with archive.open("rb") as file:
            if hashlib.file_digest(file, "sha256").hexdigest() != expected:
                raise ValueError("已有数据校验失败，请保留文件并排查")
    else:
        temporary = None
        try:
            with (
                urlopen(specification["url"], timeout=60) as response,
                NamedTemporaryFile(dir=destination, delete=False) as file,
            ):
                temporary = Path(file.name)
                count = 0
                while chunk := response.read(1 << 20):
                    count += len(chunk)
                    if count > 512 << 20:
                        raise ValueError("数据包超过课程的 512 MiB 上限")
                    file.write(chunk)
            with temporary.open("rb") as file:
                if hashlib.file_digest(file, "sha256").hexdigest() != expected:
                    raise ValueError("下载摘要与固定来源不符")
            os.replace(temporary, archive)
        finally:
            if temporary:
                temporary.unlink(missing_ok=True)
    target = destination / name
    target.mkdir(exist_ok=True)
    with ZipFile(archive) as zipped:
        if sum(item.file_size for item in zipped.infolist()) > 1 << 30:
            raise ValueError("解压大小超过课程上限")
        for item in zipped.infolist():
            relative = Path(item.filename)
            if (
                relative.is_absolute()
                or ".." in relative.parts
                or (item.external_attr >> 16) & 0o170000 == 0o120000
            ):
                raise ValueError("数据包包含不允许的路径或符号链接")
        zipped.extractall(target)
    return target


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "name", choices=("bike", "beans-train", "beans-validation", "beans-test")
    )
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    print(fetch(args.name, args.destination))
