from contextlib import asynccontextmanager
import asyncio
import hmac
import time
from io import BytesIO
import os
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, UploadFile, Response
import joblib
import pandas as pd
from pydantic import AwareDatetime, BaseModel, ConfigDict, Field

from learning.artifacts import verify
from learning.forecast import FEATURES, row
from learning.http import BodyLimit
from prometheus_client import (
    CollectorRegistry,
    Histogram,
    generate_latest,
    CONTENT_TYPE_LATEST,
)


class Observation(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)
    timestamp: AwareDatetime
    count: float = Field(ge=0, le=1_000_000, strict=True)


class ForecastInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    target: AwareDatetime
    history: list[Observation] = Field(min_length=3, max_length=200)


def create_app(model_path, kind, access_token=None):
    directory = Path(model_path)
    if access_token is not None and len(access_token) < 32:
        raise ValueError("推理服务令牌至少 32 个字符")

    @asynccontextmanager
    async def lifespan(app):
        metadata = verify(directory, kind)
        app.state.metadata = metadata
        if kind == "forecast":
            if metadata["features"] != FEATURES:
                raise ValueError("特征顺序不符")
            app.state.model = joblib.load(directory / metadata["file"])
        elif kind == "vision":
            import torch
            from learning.vision import CLASSES, network

            if metadata["classes"] != CLASSES:
                raise ValueError("类别顺序不符")
            torch.set_num_threads(2)
            app.state.model = network()
            app.state.model.load_state_dict(
                torch.load(
                    directory / metadata["file"], weights_only=True, map_location="cpu"
                )
            )
            app.state.model.eval()
        else:
            raise ValueError("未知模型类型")
        yield

    app = FastAPI(lifespan=lifespan)
    app.add_middleware(BodyLimit, limit=6 * 1024 * 1024)
    capacity = asyncio.Semaphore(2)
    registry = CollectorRegistry()
    latency = Histogram(
        "learning_inference_seconds",
        "Inference latency",
        ["kind", "status"],
        registry=registry,
    )

    @app.middleware("http")
    async def admission(request, call_next):
        if request.url.path != "/predict":
            return await call_next(request)
        if access_token is not None and not hmac.compare_digest(
            request.headers.get("authorization", ""), "Bearer " + access_token
        ):
            return Response(
                content='{"detail":"服务凭据无效"}',
                status_code=401,
                media_type="application/json",
            )
        if capacity.locked():
            return Response(
                content='{"detail":"推理繁忙，请稍后重试"}',
                status_code=429,
                media_type="application/json",
            )
        async with capacity:
            started = time.monotonic()
            response = await call_next(request)
            latency.labels(kind, response.status_code).observe(
                time.monotonic() - started
            )
            return response

    @app.get("/metrics")
    def metrics():
        return Response(generate_latest(registry), media_type=CONTENT_TYPE_LATEST)

    @app.get("/healthz")
    def health():
        return {"status": "alive"}

    @app.get("/readyz")
    def ready():
        return {"version": app.state.metadata["version"], "kind": kind}

    if kind == "forecast":

        @app.post("/predict")
        def forecast(data: ForecastInput):
            if len({point.timestamp for point in data.history}) != len(data.history):
                raise HTTPException(422, "历史时间重复")
            if any(point.timestamp >= data.target for point in data.history):
                raise HTTPException(422, "历史必须早于预测目标")
            try:
                values = row(
                    data.target,
                    {
                        pd.Timestamp(point.timestamp): point.count
                        for point in data.history
                    },
                )
            except ValueError as error:
                raise HTTPException(422, str(error))
            features = pd.DataFrame([values], columns=FEATURES)
            prediction = float(app.state.model.predict(features)[0])
            return {
                "version": app.state.metadata["version"],
                "target": data.target,
                "count": prediction,
                "weekly_baseline": values[-1],
            }
    else:

        @app.post("/predict")
        def vision(file: UploadFile = File(...)):
            import torch
            from PIL import Image, ImageOps, UnidentifiedImageError
            from learning.vision import CLASSES, transform

            content = file.file.read(5 * 1024 * 1024 + 1)
            if len(content) > 5 * 1024 * 1024:
                raise HTTPException(413, "图片超过 5 MiB")
            try:
                with Image.open(BytesIO(content)) as source:
                    if source.format not in {"JPEG", "PNG"} or not all(
                        16 <= size <= 4096 for size in source.size
                    ):
                        raise HTTPException(422, "图片格式或尺寸不符")
                    image = ImageOps.exif_transpose(source).convert("RGB")
            except (UnidentifiedImageError, OSError, Image.DecompressionBombError):
                raise HTTPException(422, "图片无法解码")
            with torch.inference_mode():
                probabilities = app.state.model(
                    transform()(image).unsqueeze(0)
                ).softmax(1)[0]
            confidence, label = probabilities.max(0)
            return {
                "version": app.state.metadata["version"],
                "label": CLASSES[int(label)],
                "confidence": float(confidence),
                # shortcut: 0.8 演示人工复核入口，业务接入前须验证阈值与误判成本。
                "needs_review": float(confidence) < 0.8,
            }

    return app


def factory():
    token = os.environ.get("INFERENCE_TOKEN")
    if os.environ.get("APP_ENV") == "production" and not token:
        raise ValueError("生产推理服务必须提供 INFERENCE_TOKEN")
    return create_app(os.environ["MODEL_PATH"], os.environ["MODEL_KIND"], token)
