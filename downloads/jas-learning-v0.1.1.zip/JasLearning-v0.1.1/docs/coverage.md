# 章节与实作覆盖表

覆盖原有 192 篇文章。下表核对地址、章节结构与工程应用位置；不表示所有旧片段或所有外部专题都重新执行。基础机制保留现有讲解，完整实作和部署说明通过四套目录及新增工程文章接入。

| 章节 | 工程应用位置 | 本轮处理 |
|---|---|---|
| [数据库学习笔记：目录、实验和阅读顺序](https://blog.imggb.top/notes/database-00-learning-guide) | [database/README.md](../database/README.md) | 保留机制讲解并提供工程应用定位 |
| [数据库 01：先确认连的是谁、操作的是哪个库](https://blog.imggb.top/notes/database-01-environment) | [database/sql/00-schema.sql](../database/sql/00-schema.sql) | 保留机制讲解并提供工程应用定位 |
| [数据库 02：一条 SQL 从执行到落盘经历了什么](https://blog.imggb.top/notes/database-02-storage-execution) | [database/sql/00-schema.sql](../database/sql/00-schema.sql) | 保留机制讲解并提供工程应用定位 |
| [数据库 03：从业务事实推导表、约束和数据类型](https://blog.imggb.top/notes/database-03-modeling-types) | [database/sql/00-schema.sql](../database/sql/00-schema.sql) | 保留机制讲解并提供工程应用定位 |
| [数据库 04：把筛选、NULL 和修改范围写准确](https://blog.imggb.top/notes/database-04-sql-basics) | [database/sql/00-schema.sql](../database/sql/00-schema.sql) | 保留机制讲解并提供工程应用定位 |
| [数据库 05：关联之后，为什么金额会多算](https://blog.imggb.top/notes/database-05-joins-subqueries) | [database/sql/00-schema.sql](../database/sql/00-schema.sql) | 保留机制讲解并提供工程应用定位 |
| [数据库 06：用窗口函数做排名、累计和报表](https://blog.imggb.top/notes/database-06-windows-reports) | [database/sql/00-schema.sql](../database/sql/00-schema.sql) | 保留机制讲解并提供工程应用定位 |
| [数据库 07：快照稳定了，业务规则就一定正确吗](https://blog.imggb.top/notes/database-07-transactions-mvcc) | [database/sql/03-place-order.sql](../database/sql/03-place-order.sql) | 保留机制讲解并提供工程应用定位 |
| [数据库 08：找到谁在等谁，再处理锁和死锁](https://blog.imggb.top/notes/database-08-locks-deadlocks) | [database/sql/03-place-order.sql](../database/sql/03-place-order.sql) | 保留机制讲解并提供工程应用定位 |
| [数据库 09：让订单、库存、幂等和流水一起成立](https://blog.imggb.top/notes/database-09-orders-idempotency) | [database/sql/03-place-order.sql](../database/sql/03-place-order.sql) | 保留机制讲解并提供工程应用定位 |
| [数据库 10：事务接到应用里，还要管连接、超时和重试](https://blog.imggb.top/notes/database-10-connections-application) | [database/sql/03-place-order.sql](../database/sql/03-place-order.sql) | 保留机制讲解并提供工程应用定位 |
| [数据库 11：按查询设计索引，也把写入代价算进去](https://blog.imggb.top/notes/database-11-indexes) | [database/sql/05-performance.sql](../database/sql/05-performance.sql) | 保留机制讲解并提供工程应用定位 |
| [数据库 12：从执行计划解释查询为什么慢](https://blog.imggb.top/notes/database-12-query-plans) | [database/sql/05-performance.sql](../database/sql/05-performance.sql) | 保留机制讲解并提供工程应用定位 |
| [数据库 13：删除后文件为什么没变小，分区又能解决什么](https://blog.imggb.top/notes/database-13-vacuum-partitions) | [database/sql/05-performance.sql](../database/sql/05-performance.sql) | 保留机制讲解并提供工程应用定位 |
| [数据库 14：把连接身份、对象权限和数据安全分开检查](https://blog.imggb.top/notes/database-14-security) | [database/sql/06-security-checks.sql](../database/sql/06-security-checks.sql) | 保留机制讲解并提供工程应用定位 |
| [数据库 15：有备份文件之后，还要证明能恢复](https://blog.imggb.top/notes/database-15-backup-restore) | [database/test_postgres.py](../database/test_postgres.py) | 保留机制讲解并提供工程应用定位 |
| [数据库 16：用基础备份和连续 WAL 回到误删之前](https://blog.imggb.top/notes/database-16-wal-pitr) | [database/test_postgres.py](../database/test_postgres.py) | 保留机制讲解并提供工程应用定位 |
| [数据库 17：副本有多新，切换时怎样避免两个主库](https://blog.imggb.top/notes/database-17-replication-ha) | [docs/kubernetes.md](../docs/kubernetes.md) | 保留机制讲解并提供工程应用定位 |
| [数据库 18：从业务延迟追到资源，再算容量预算](https://blog.imggb.top/notes/database-18-monitoring-capacity) | [docs/kubernetes.md](../docs/kubernetes.md) | 保留机制讲解并提供工程应用定位 |
| [数据库 19：用等待链、计划和存储证据定位故障](https://blog.imggb.top/notes/database-19-troubleshooting) | [docs/kubernetes.md](../docs/kubernetes.md) | 保留机制讲解并提供工程应用定位 |
| [数据库 20：从调用方到历史数据，完成一次可核对的迁移](https://blog.imggb.top/notes/database-20-migrations) | [database/test_postgres.py](../database/test_postgres.py) | 保留机制讲解并提供工程应用定位 |
| [数据库 21：把 PostgreSQL 的经验迁到 MySQL 时，要重查哪些行为](https://blog.imggb.top/notes/database-21-mysql) | [database/mysql/check.py](../database/mysql/check.py) | 保留机制讲解并提供工程应用定位 |
| [数据库 22：什么时候该加缓存、分析库或分片](https://blog.imggb.top/notes/database-22-cache-distribution) | [database/README.md](../database/README.md) | 保留机制讲解并提供工程应用定位 |
| [数据库 23：33 种数据库、扩展与服务，按场景比较用途和代价](https://blog.imggb.top/notes/database-23-product-comparison) | [database/README.md](../database/README.md) | 保留机制讲解并提供工程应用定位 |
| [数据库练习参考：查询结果、并发顺序和判断依据](https://blog.imggb.top/notes/database-exercise-answers) | [database/README.md](../database/README.md) | 保留机制讲解并提供工程应用定位 |
| [数据库动手练习：从查询到恢复的 33 个问题](https://blog.imggb.top/notes/database-exercises) | [database/README.md](../database/README.md) | 保留机制讲解并提供工程应用定位 |
| [数据库术语速查：快照、日志、复制与恢复](https://blog.imggb.top/notes/database-glossary) | [database/README.md](../database/README.md) | 保留机制讲解并提供工程应用定位 |
| [数据库实验手册：启动环境与八组实验](https://blog.imggb.top/notes/database-lab-guide) | [database/test_postgres.py](../database/test_postgres.py) | 完整实作与故障流程关联 |
| [数据库实验记录：已测结果与适用范围](https://blog.imggb.top/notes/database-lab-results) | [database/test_postgres.py](../database/test_postgres.py) | 完整实作与故障流程关联 |
| [数据库学习记录模板：保存过程、输出与待验证问题](https://blog.imggb.top/notes/database-learning-template) | [database/README.md](../database/README.md) | 保留机制讲解并提供工程应用定位 |
| [订单数据库实作：下单、并发、权限与恢复](https://blog.imggb.top/notes/database-order-project) | [database/README.md](../database/README.md) | 完整实作与故障流程关联 |
| [数据库官方资料：版本、主题与产品入口](https://blog.imggb.top/notes/database-references) | [database/README.md](../database/README.md) | 保留机制讲解并提供工程应用定位 |
| [数据库操作速查：连接、等待、空间和恢复](https://blog.imggb.top/notes/database-runbooks) | [database/README.md](../database/README.md) | 保留机制讲解并提供工程应用定位 |
| [Go 学习笔记：目录与阅读路线](https://blog.imggb.top/notes/go-00-learning-guide) | [go/README.md](../go/README.md) | 保留机制讲解并提供工程应用定位 |
| [Go 01：学 Go 后端，我会先把请求走过的路径画出来](https://blog.imggb.top/notes/go-01-roadmap) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 02：Go 工具链与 Modules：先把运行环境对齐](https://blog.imggb.top/notes/go-02-toolchain) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 03：读懂 Go 程序：包、声明与入口](https://blog.imggb.top/notes/go-03-program-basics) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 04：类型与流程控制：先明确数据能取什么值](https://blog.imggb.top/notes/go-04-types-control) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 05：数组、切片、map 和字符串的边界](https://blog.imggb.top/notes/go-05-collections) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 06：函数、方法与指针接收者怎么选](https://blog.imggb.top/notes/go-06-functions-methods) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 07：结构体、接口与泛型：先表达业务关系](https://blog.imggb.top/notes/go-07-structs-interfaces) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 08：错误处理：让失败沿调用链说清楚](https://blog.imggb.top/notes/go-08-errors) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 09：包与依赖：让业务规则留在自己的位置](https://blog.imggb.top/notes/go-09-packages) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 10：goroutine 与 channel：启动之外还要负责退出](https://blog.imggb.top/notes/go-10-concurrency) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 11：锁与 context：保护状态，传递取消](https://blog.imggb.top/notes/go-11-sync-context) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 12：值、引用、逃逸与垃圾回收](https://blog.imggb.top/notes/go-12-memory) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 13：后端常用标准库：I/O、JSON、时间与 HTTP](https://blog.imggb.top/notes/go-13-stdlib) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 14：表驱动测试与 Go 开发检查](https://blog.imggb.top/notes/go-14-testing-tools) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 15：HTTP 与 REST：状态码也是接口的一部分](https://blog.imggb.top/notes/go-15-http-rest) | [go/internal/httpapi/router.go](../go/internal/httpapi/router.go) | 保留机制讲解并提供工程应用定位 |
| [Go 16：net/http：请求处理、超时与优雅关闭](https://blog.imggb.top/notes/go-16-net-http) | [go/internal/httpapi/router.go](../go/internal/httpapi/router.go) | 保留机制讲解并提供工程应用定位 |
| [Go 17：用 Gin 写接口，业务边界仍要自己划](https://blog.imggb.top/notes/go-17-gin) | [go/internal/httpapi/router.go](../go/internal/httpapi/router.go) | 保留机制讲解并提供工程应用定位 |
| [Go 18：API 合同：字段、分页和幂等键怎么约定](https://blog.imggb.top/notes/go-18-api-contracts) | [go/internal/httpapi/router.go](../go/internal/httpapi/router.go) | 保留机制讲解并提供工程应用定位 |
| [Go 19：配置、日志与服务的启动和关闭](https://blog.imggb.top/notes/go-19-config-logging) | [go/internal/httpapi/router.go](../go/internal/httpapi/router.go) | 保留机制讲解并提供工程应用定位 |
| [Go 20：认证、授权与 Web 安全的几条边界](https://blog.imggb.top/notes/go-20-security) | [go/internal/httpapi/router.go](../go/internal/httpapi/router.go) | 保留机制讲解并提供工程应用定位 |
| [Go 21：MySQL 建模与 SQL：从查询和业务状态出发](https://blog.imggb.top/notes/go-21-mysql-sql) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 22：索引与查询优化：让执行计划给出依据](https://blog.imggb.top/notes/go-22-indexes) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 23：事务、锁与连接池：并发扣库存怎么保证正确](https://blog.imggb.top/notes/go-23-transactions-locks) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 24：GORM 的作用与持久层的边界](https://blog.imggb.top/notes/go-24-gorm-repository) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 25：Redis 缓存：命中之外，还要考虑失效和恢复](https://blog.imggb.top/notes/go-25-redis-cache) | [go/internal/order/queue.go](../go/internal/order/queue.go) | 保留机制讲解并提供工程应用定位 |
| [Go 26：Redis 高并发：原子预留与跨系统事务的区别](https://blog.imggb.top/notes/go-26-redis-concurrency) | [go/internal/order/queue.go](../go/internal/order/queue.go) | 保留机制讲解并提供工程应用定位 |
| [Go 27：Kafka：顺序、offset 与重复消费](https://blog.imggb.top/notes/go-27-kafka) | [go/internal/order/queue.go](../go/internal/order/queue.go) | 保留机制讲解并提供工程应用定位 |
| [Go 28：消息可靠性：幂等、重试、Outbox 与补偿](https://blog.imggb.top/notes/go-28-message-reliability) | [go/internal/order/queue.go](../go/internal/order/queue.go) | 保留机制讲解并提供工程应用定位 |
| [Go 29：限时促销项目：先确定接口与订单状态](https://blog.imggb.top/notes/go-29-project-design) | [go/internal/order/store.go](../go/internal/order/store.go) | 完整实作与故障流程关联 |
| [Go 30：搭服务骨架：配置、依赖装配与健康检查](https://blog.imggb.top/notes/go-30-project-skeleton) | [go/internal/order/store.go](../go/internal/order/store.go) | 完整实作与故障流程关联 |
| [Go 31：商品和促销：时间、价格与资格由谁确认](https://blog.imggb.top/notes/go-31-catalog-campaign) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 32：普通下单：库存与订单要一起提交](https://blog.imggb.top/notes/go-32-order-inventory) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 33：异步抢购：从库存预留到订单落库](https://blog.imggb.top/notes/go-33-flash-sale) | [go/internal/order/queue.go](../go/internal/order/queue.go) | 保留机制讲解并提供工程应用定位 |
| [Go 34：支付回调、通知与对账：重复和迟到都要处理](https://blog.imggb.top/notes/go-34-payment-reconciliation) | [go/internal/order/store.go](../go/internal/order/store.go) | 保留机制讲解并提供工程应用定位 |
| [Go 35：项目测试：按业务风险选择验证层次](https://blog.imggb.top/notes/go-35-test-strategy) | [go/internal/order/store_test.go](../go/internal/order/store_test.go) | 保留机制讲解并提供工程应用定位 |
| [Go 36：压测与 pprof：解释吞吐和尾延迟](https://blog.imggb.top/notes/go-36-performance) | [go/internal/order/store_test.go](../go/internal/order/store_test.go) | 保留机制讲解并提供工程应用定位 |
| [Go 37：从模块化单体到微服务：先说明拆分的收益](https://blog.imggb.top/notes/go-37-microservices-grpc) | [go/README.md](../go/README.md) | 保留机制讲解并提供工程应用定位 |
| [Go 38：超时、重试、限流与熔断怎么配合](https://blog.imggb.top/notes/go-38-resilience) | [go/README.md](../go/README.md) | 保留机制讲解并提供工程应用定位 |
| [Go 39：跨服务一致性与数据扩展的代价](https://blog.imggb.top/notes/go-39-distributed-data) | [go/README.md](../go/README.md) | 保留机制讲解并提供工程应用定位 |
| [Go 40：Docker 与 Compose：把运行环境留下来](https://blog.imggb.top/notes/go-40-docker-compose) | [docs/kubernetes.md](../docs/kubernetes.md) | 保留机制讲解并提供工程应用定位 |
| [Go 41：Kubernetes 入门：Pod、Deployment 与流量入口](https://blog.imggb.top/notes/go-41-kubernetes-basics) | [docs/kubernetes.md](../docs/kubernetes.md) | 完整实作与故障流程关联 |
| [Go 42：Kubernetes 发布：资源、探针和扩缩容](https://blog.imggb.top/notes/go-42-kubernetes-production) | [docs/kubernetes.md](../docs/kubernetes.md) | 完整实作与故障流程关联 |
| [Go 43：日志、指标与 Trace：从异常找到调用链](https://blog.imggb.top/notes/go-43-observability) | [docs/kubernetes.md](../docs/kubernetes.md) | 保留机制讲解并提供工程应用定位 |
| [Go 44：CI/CD：让每次发布有可追溯的结果](https://blog.imggb.top/notes/go-44-cicd) | [docs/kubernetes.md](../docs/kubernetes.md) | 完整实作与故障流程关联 |
| [Go 45：生产排障：先确认影响，再定位原因](https://blog.imggb.top/notes/go-45-operations) | [docs/kubernetes.md](../docs/kubernetes.md) | 完整实作与故障流程关联 |
| [Go 专题 01：Elasticsearch：把搜索当作可重建的投影](https://blog.imggb.top/notes/go-advanced-01-elasticsearch) | [go/README.md](../go/README.md) | 保留机制讲解并提供工程应用定位 |
| [Go 专题 02：RabbitMQ 与 Kafka：从消息要怎么用来选型](https://blog.imggb.top/notes/go-advanced-02-messaging-choice) | [go/README.md](../go/README.md) | 保留机制讲解并提供工程应用定位 |
| [Go 专题 03：读写分离与分片：扩展数据库之前先看约束](https://blog.imggb.top/notes/go-advanced-03-database-scaling) | [go/README.md](../go/README.md) | 保留机制讲解并提供工程应用定位 |
| [Go 专题 04：配置中心和服务网格：先确认平台还缺什么](https://blog.imggb.top/notes/go-advanced-04-service-discovery-mesh) | [go/README.md](../go/README.md) | 保留机制讲解并提供工程应用定位 |
| [Go 专题 05：比较 MySQL 与 PostgreSQL，我会看哪些问题](https://blog.imggb.top/notes/go-advanced-05-postgresql) | [go/README.md](../go/README.md) | 保留机制讲解并提供工程应用定位 |
| [Go 专题 06：请求慢在哪里：DNS、TCP、TLS 与 Linux 网络](https://blog.imggb.top/notes/go-advanced-06-networking-linux) | [go/README.md](../go/README.md) | 保留机制讲解并提供工程应用定位 |
| [Go 后端资料索引与术语](https://blog.imggb.top/notes/go-reference) | [go/README.md](../go/README.md) | 保留机制讲解并提供工程应用定位 |
| [Python 学习笔记：目录与阅读路线](https://blog.imggb.top/notes/python-00-learning-guide) | [python/README.md](../python/README.md) | 保留机制讲解并提供工程应用定位 |
| [Python 01：先把解释器和运行方式弄清楚](https://blog.imggb.top/notes/python-01-environment) | [python/src/learning/etl.py](../python/src/learning/etl.py) | 保留机制讲解并提供工程应用定位 |
| [Python 02：变量、对象与赋值：改的是名字，还是对象](https://blog.imggb.top/notes/python-02-objects) | [python/src/learning/etl.py](../python/src/learning/etl.py) | 保留机制讲解并提供工程应用定位 |
| [Python 03：数字、真假值与类型转换](https://blog.imggb.top/notes/python-03-basic-types) | [python/src/learning/etl.py](../python/src/learning/etl.py) | 保留机制讲解并提供工程应用定位 |
| [Python 04：字符串：从切片到编码和格式化](https://blog.imggb.top/notes/python-04-strings) | [python/src/learning/etl.py](../python/src/learning/etl.py) | 保留机制讲解并提供工程应用定位 |
| [Python 05：列表、元组和解包该怎么选](https://blog.imggb.top/notes/python-05-sequences) | [python/src/learning/etl.py](../python/src/learning/etl.py) | 保留机制讲解并提供工程应用定位 |
| [Python 06：字典与集合：查找、去重和成员判断](https://blog.imggb.top/notes/python-06-mappings-sets) | [python/src/learning/etl.py](../python/src/learning/etl.py) | 保留机制讲解并提供工程应用定位 |
| [Python 07：条件、循环与推导式：把处理过程写清楚](https://blog.imggb.top/notes/python-07-control-flow) | [python/src/learning/etl.py](../python/src/learning/etl.py) | 保留机制讲解并提供工程应用定位 |
| [Python 08：函数、返回值与作用域](https://blog.imggb.top/notes/python-08-functions) | [python/src/learning/etl.py](../python/src/learning/etl.py) | 保留机制讲解并提供工程应用定位 |
| [Python 09：参数、闭包与函数式工具](https://blog.imggb.top/notes/python-09-functions-advanced) | [python/src/learning/etl.py](../python/src/learning/etl.py) | 保留机制讲解并提供工程应用定位 |
| [Python 10：异常处理：在哪里接住失败](https://blog.imggb.top/notes/python-10-exceptions) | [python/src/learning/etl.py](../python/src/learning/etl.py) | 保留机制讲解并提供工程应用定位 |
| [Python 11：文件、路径与编码：先确认读写的对象](https://blog.imggb.top/notes/python-11-files-paths) | [python/src/learning/etl.py](../python/src/learning/etl.py) | 保留机制讲解并提供工程应用定位 |
| [Python 12：JSON、CSV 与序列化边界](https://blog.imggb.top/notes/python-12-data-formats) | [python/src/learning/etl.py](../python/src/learning/etl.py) | 保留机制讲解并提供工程应用定位 |
| [Python 13：模块、导入与程序入口](https://blog.imggb.top/notes/python-13-modules-imports) | [python/src/learning/etl.py](../python/src/learning/etl.py) | 保留机制讲解并提供工程应用定位 |
| [Python 14：类、属性与数据类：什么时候需要一个对象](https://blog.imggb.top/notes/python-14-classes) | [python/src/learning/api.py](../python/src/learning/api.py) | 保留机制讲解并提供工程应用定位 |
| [Python 15：组合、继承与协议：依赖需要的行为](https://blog.imggb.top/notes/python-15-composition-inheritance) | [python/src/learning/api.py](../python/src/learning/api.py) | 保留机制讲解并提供工程应用定位 |
| [Python 16：迭代器与生成器：数据不必一次准备好](https://blog.imggb.top/notes/python-16-iterators-generators) | [python/src/learning/api.py](../python/src/learning/api.py) | 保留机制讲解并提供工程应用定位 |
| [Python 17：装饰器与上下文管理器：把公共动作放在合适的位置](https://blog.imggb.top/notes/python-17-decorators-context) | [python/src/learning/api.py](../python/src/learning/api.py) | 保留机制讲解并提供工程应用定位 |
| [Python 18：常用标准库：先看操作，再选工具](https://blog.imggb.top/notes/python-18-standard-library) | [python/src/learning/datasets.py](../python/src/learning/datasets.py) | 保留机制讲解并提供工程应用定位 |
| [Python 19：正则、日期与时间：格式之外还有语义](https://blog.imggb.top/notes/python-19-regex-datetime) | [python/src/learning/datasets.py](../python/src/learning/datasets.py) | 保留机制讲解并提供工程应用定位 |
| [Python 20：命令行、子进程和 HTTP：处理外部输入](https://blog.imggb.top/notes/python-20-cli-http) | [python/src/learning/datasets.py](../python/src/learning/datasets.py) | 保留机制讲解并提供工程应用定位 |
| [Python 21：虚拟环境与项目结构：让依赖跟着项目走](https://blog.imggb.top/notes/python-21-environments-projects) | [python/pyproject.toml](../python/pyproject.toml) | 完整实作与故障流程关联 |
| [Python 22：类型标注能检查什么，又不能检查什么](https://blog.imggb.top/notes/python-22-typing) | [python/pyproject.toml](../python/pyproject.toml) | 保留机制讲解并提供工程应用定位 |
| [Python 23：用 pytest 把预期行为留下来](https://blog.imggb.top/notes/python-23-testing) | [python/pyproject.toml](../python/pyproject.toml) | 保留机制讲解并提供工程应用定位 |
| [Python 24：调试、日志与配置：留下能解释问题的信息](https://blog.imggb.top/notes/python-24-debugging-logging) | [python/pyproject.toml](../python/pyproject.toml) | 保留机制讲解并提供工程应用定位 |
| [Python 25：用 pyproject.toml 把项目变成可安装的包](https://blog.imggb.top/notes/python-25-packaging) | [python/pyproject.toml](../python/pyproject.toml) | 保留机制讲解并提供工程应用定位 |
| [Python 26：Git、依赖与安全：守住几条输入边界](https://blog.imggb.top/notes/python-26-git-security) | [python/pyproject.toml](../python/pyproject.toml) | 保留机制讲解并提供工程应用定位 |
| [Python 27：浅拷贝与深拷贝：到底复制到了哪一层](https://blog.imggb.top/notes/python-27-references-copy) | [python/src/learning/inference.py](../python/src/learning/inference.py) | 保留机制讲解并提供工程应用定位 |
| [Python 28：特殊方法：让自定义对象用起来像 Python 对象](https://blog.imggb.top/notes/python-28-data-model) | [python/src/learning/inference.py](../python/src/learning/inference.py) | 保留机制讲解并提供工程应用定位 |
| [Python 29：描述符与元类：先看它们介入了哪一步](https://blog.imggb.top/notes/python-29-descriptors-metaclasses) | [python/src/learning/inference.py](../python/src/learning/inference.py) | 保留机制讲解并提供工程应用定位 |
| [Python 30：性能与内存：先找到真正耗时的地方](https://blog.imggb.top/notes/python-30-performance) | [python/src/learning/inference.py](../python/src/learning/inference.py) | 保留机制讲解并提供工程应用定位 |
| [Python 31：线程、进程与 GIL：从任务在等什么说起](https://blog.imggb.top/notes/python-31-concurrency) | [python/src/learning/inference.py](../python/src/learning/inference.py) | 保留机制讲解并提供工程应用定位 |
| [Python 32：asyncio：await 在什么地方让出执行权](https://blog.imggb.top/notes/python-32-asyncio) | [python/src/learning/inference.py](../python/src/learning/inference.py) | 保留机制讲解并提供工程应用定位 |
| [Python 33：自动化脚本：先让任务能安全重跑](https://blog.imggb.top/notes/python-33-automation) | [python/src/learning/etl.py](../python/src/learning/etl.py) | 保留机制讲解并提供工程应用定位 |
| [Python 34：写一个订单 ETL 工具：读取、校验、转换和输出](https://blog.imggb.top/notes/python-34-etl-project) | [python/src/learning/etl.py](../python/src/learning/etl.py) | 完整实作与故障流程关联 |
| [Python 35：NumPy、pandas 与图表：从数据形状开始分析](https://blog.imggb.top/notes/python-35-data-analysis) | [python/src/learning/etl.py](../python/src/learning/etl.py) | 保留机制讲解并提供工程应用定位 |
| [Python 36：把订单 CSV 整理成能重跑的销售分析](https://blog.imggb.top/notes/python-36-analysis-project) | [python/src/learning/etl.py](../python/src/learning/etl.py) | 完整实作与故障流程关联 |
| [Python 37：机器学习流程：先分数据，再比较模型](https://blog.imggb.top/notes/python-37-machine-learning) | [python/src/learning/forecast.py](../python/src/learning/forecast.py) | 保留机制讲解并提供工程应用定位 |
| [Python 38：用 Iris 数据走一遍训练、评估和模型保存](https://blog.imggb.top/notes/python-38-ml-project) | [python/src/learning/forecast.py](../python/src/learning/forecast.py) | 完整实作与故障流程关联 |
| [Python 39：PyTorch：张量、梯度和训练循环怎么连起来](https://blog.imggb.top/notes/python-39-pytorch) | [python/src/learning/vision.py](../python/src/learning/vision.py) | 保留机制讲解并提供工程应用定位 |
| [Python 40：用 PyTorch 训练一个手写数字分类器](https://blog.imggb.top/notes/python-40-dl-project) | [python/src/learning/vision.py](../python/src/learning/vision.py) | 完整实作与故障流程关联 |
| [Python 41：FastAPI：一次请求如何经过校验和业务处理](https://blog.imggb.top/notes/python-41-backend) | [python/src/learning/api.py](../python/src/learning/api.py) | 保留机制讲解并提供工程应用定位 |
| [Python 42：用 FastAPI 和 SQLite 做一个任务 API](https://blog.imggb.top/notes/python-42-backend-project) | [python/src/learning/api.py](../python/src/learning/api.py) | 完整实作与故障流程关联 |
| [Python 43：采集、办公、GUI 与科学计算：Python 的几条延伸方向](https://blog.imggb.top/notes/python-43-other-domains) | [python/README.md](../python/README.md) | 保留机制讲解并提供工程应用定位 |
| [Python 资料索引与常用工具](https://blog.imggb.top/notes/python-reference) | [python/README.md](../python/README.md) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 学习笔记：目录与阅读路线](https://blog.imggb.top/notes/typescript-00-learning-guide) | [typescript/apps/web/src/main.tsx](../typescript/apps/web/src/main.tsx) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 01：从 Python 转向 TypeScript，先分清运行环境](https://blog.imggb.top/notes/typescript-01-learning-route) | [typescript/apps/web/src/main.tsx](../typescript/apps/web/src/main.tsx) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 02：浏览器、API 与数据库之间发生了什么](https://blog.imggb.top/notes/typescript-02-web-architecture) | [typescript/apps/web/src/main.tsx](../typescript/apps/web/src/main.tsx) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 03：HTML、CSS 与 DOM：React 下面仍然是浏览器](https://blog.imggb.top/notes/typescript-03-html-css-dom) | [typescript/apps/web/src/main.tsx](../typescript/apps/web/src/main.tsx) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 04：读懂一次 HTTP 请求和 JSON 响应](https://blog.imggb.top/notes/typescript-04-http-json-api) | [typescript/apps/web/src/main.tsx](../typescript/apps/web/src/main.tsx) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 05：JavaScript 变量：const 限制的到底是什么](https://blog.imggb.top/notes/typescript-05-values-and-variables) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 06：判断、循环与默认值：0 和空字符串怎么办](https://blog.imggb.top/notes/typescript-06-control-flow) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 07：数组与对象：选择、转换和浅拷贝](https://blog.imggb.top/notes/typescript-07-arrays-objects) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 08：函数与闭包：函数记住了什么](https://blog.imggb.top/notes/typescript-08-functions-scope) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 09：对象、原型与 class 的关系](https://blog.imggb.top/notes/typescript-09-object-model) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 10：模块、Node.js 与 npm：让文件和依赖各归其位](https://blog.imggb.top/notes/typescript-10-modules-node-npm) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 11：Promise 与事件循环：等待不等于阻塞线程](https://blog.imggb.top/notes/typescript-11-promises-event-loop) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 12：fetch 的失败：网络、HTTP 和业务要分开处理](https://blog.imggb.top/notes/typescript-12-fetch-errors) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 13：调试时，先找实际数据第一次变错的位置](https://blog.imggb.top/notes/typescript-13-debugging) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 14：TypeScript 的检查发生在什么时候](https://blog.imggb.top/notes/typescript-14-typescript-compiler) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 15：类型推断、unknown、any 与函数边界](https://blog.imggb.top/notes/typescript-15-basic-types) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 16：数组、元组和对象类型怎样表达约束](https://blog.imggb.top/notes/typescript-16-object-types) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 17：函数类型：回调的输入、输出和异步性](https://blog.imggb.top/notes/typescript-17-function-types) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 18：type、interface 与联合类型怎么配合](https://blog.imggb.top/notes/typescript-18-alias-interface-unions) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 19：类型收窄：检查怎样影响后面的代码](https://blog.imggb.top/notes/typescript-19-narrowing) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 20：类型守卫与穷尽检查：把状态处理完整](https://blog.imggb.top/notes/typescript-20-type-guards) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 21：泛型：保留输入与输出之间的关系](https://blog.imggb.top/notes/typescript-21-generics) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 22：typeof、keyof 与索引访问：从现有声明推导类型](https://blog.imggb.top/notes/typescript-22-type-queries) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 23：映射类型与条件类型：类型也可以按规则变换](https://blog.imggb.top/notes/typescript-23-mapped-conditional-types) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 24：工具类型、模板字面量与 satisfies](https://blog.imggb.top/notes/typescript-24-template-utility-types) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 25：TypeScript 类：接口、抽象类与私有字段](https://blog.imggb.top/notes/typescript-25-typescript-classes) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 26：声明文件：编译器从哪里认识一个 JavaScript 包](https://blog.imggb.top/notes/typescript-26-declarations) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 27：tsconfig 与 strict：每个检查选项在管什么](https://blog.imggb.top/notes/typescript-27-tsconfig-strict) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 28：模块解析：编译通过之后为什么还会导入失败](https://blog.imggb.top/notes/typescript-28-module-resolution) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 29：用 Zod 守住运行时输入边界](https://blog.imggb.top/notes/typescript-29-runtime-validation) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 30：类型放在哪里：领域、API 与页面的区别](https://blog.imggb.top/notes/typescript-30-type-organization) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 31：格式、Lint、类型检查和构建分别能证明什么](https://blog.imggb.top/notes/typescript-31-quality-tooling) | [typescript/packages/shared/src/index.ts](../typescript/packages/shared/src/index.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 32：建立 React 与 TypeScript 项目](https://blog.imggb.top/notes/typescript-32-react-project) | [typescript/apps/web/src/main.tsx](../typescript/apps/web/src/main.tsx) | 完整实作与故障流程关联 |
| [TypeScript 33：组件、Props 与组合：把输入和事件说清楚](https://blog.imggb.top/notes/typescript-33-components-props) | [typescript/apps/web/src/main.tsx](../typescript/apps/web/src/main.tsx) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 34：React 状态与列表更新](https://blog.imggb.top/notes/typescript-34-state-events) | [typescript/apps/web/src/main.tsx](../typescript/apps/web/src/main.tsx) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 35：Hooks：同步外部系统与复用组件逻辑](https://blog.imggb.top/notes/typescript-35-hooks) | [typescript/apps/web/src/main.tsx](../typescript/apps/web/src/main.tsx) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 36：把表单做完整：输入、错误、提交和键盘](https://blog.imggb.top/notes/typescript-36-forms-accessibility) | [typescript/apps/web/src/main.tsx](../typescript/apps/web/src/main.tsx) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 37：路由与页面：URL 怎样对应到组件](https://blog.imggb.top/notes/typescript-37-routing) | [typescript/apps/web/src/main.tsx](../typescript/apps/web/src/main.tsx) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 38：请求状态：空列表和加载失败不能混在一起](https://blog.imggb.top/notes/typescript-38-api-requests) | [typescript/apps/web/src/main.tsx](../typescript/apps/web/src/main.tsx) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 39：前端状态与缓存：谁拥有数据，何时更新](https://blog.imggb.top/notes/typescript-39-state-cache) | [typescript/apps/web/src/main.tsx](../typescript/apps/web/src/main.tsx) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 40：登录页面与受保护路由](https://blog.imggb.top/notes/typescript-40-auth-ui) | [typescript/apps/web/src/main.tsx](../typescript/apps/web/src/main.tsx) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 41：Node.js 服务：配置、入口与进程生命周期](https://blog.imggb.top/notes/typescript-41-node-runtime) | [typescript/apps/api/src/app.ts](../typescript/apps/api/src/app.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 42：Express 中间件：请求沿什么顺序被处理](https://blog.imggb.top/notes/typescript-42-express) | [typescript/apps/api/src/app.ts](../typescript/apps/api/src/app.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 43：把任务操作设计成 REST API](https://blog.imggb.top/notes/typescript-43-rest-api) | [typescript/apps/api/src/app.ts](../typescript/apps/api/src/app.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 44：输入校验与错误响应：在边界拒绝无效数据](https://blog.imggb.top/notes/typescript-44-validation-errors) | [typescript/apps/api/src/app.ts](../typescript/apps/api/src/app.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 45：日志与环境配置：启动就把问题暴露出来](https://blog.imggb.top/notes/typescript-45-logging-config) | [typescript/apps/api/src/app.ts](../typescript/apps/api/src/app.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 46：关系数据库与 SQL：从持久化到关联查询](https://blog.imggb.top/notes/typescript-46-sql) | [typescript/apps/api/prisma/schema.prisma](../typescript/apps/api/prisma/schema.prisma) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 47：用户与任务的数据关系怎么设计](https://blog.imggb.top/notes/typescript-47-data-modeling) | [typescript/apps/api/prisma/schema.prisma](../typescript/apps/api/prisma/schema.prisma) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 48：Prisma 建模与查询：类型之外仍有访问规则](https://blog.imggb.top/notes/typescript-48-prisma) | [typescript/apps/api/prisma/schema.prisma](../typescript/apps/api/prisma/schema.prisma) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 49：迁移、种子数据与事务：让数据变更能重现](https://blog.imggb.top/notes/typescript-49-migrations-transactions) | [typescript/apps/api/prisma/schema.prisma](../typescript/apps/api/prisma/schema.prisma) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 50：认证与授权：保护任务属于谁这件事](https://blog.imggb.top/notes/typescript-50-auth-security) | [typescript/apps/api/src/app.ts](../typescript/apps/api/src/app.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 51：npm workspaces：组织前端、API 和共享包](https://blog.imggb.top/notes/typescript-51-workspaces) | [typescript/apps/api/src/app.ts](../typescript/apps/api/src/app.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 52：共享 Schema：让前后端使用同一份接口规则](https://blog.imggb.top/notes/typescript-52-shared-contracts) | [typescript/apps/api/src/app.ts](../typescript/apps/api/src/app.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 53：任务 API：把会话、校验和持久化连起来](https://blog.imggb.top/notes/typescript-53-task-api) | [typescript/apps/api/src/app.ts](../typescript/apps/api/src/app.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 54：注册、登录、刷新与退出的完整流程](https://blog.imggb.top/notes/typescript-54-auth-integration) | [typescript/apps/api/src/app.ts](../typescript/apps/api/src/app.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 55：单元和组件测试：把用户能观察到的行为写下来](https://blog.imggb.top/notes/typescript-55-unit-component-tests) | [typescript/browser/tasks.spec.ts](../typescript/browser/tasks.spec.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 56：API 与端到端测试：确认整条路径能走通](https://blog.imggb.top/notes/typescript-56-api-e2e-tests) | [typescript/browser/tasks.spec.ts](../typescript/browser/tasks.spec.ts) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 57：构建与部署：把本机能跑变成可重复交付](https://blog.imggb.top/notes/typescript-57-deployment-capstone) | [docs/kubernetes.md](../docs/kubernetes.md) | 完整实作与故障流程关联 |
| [TypeScript 练习参考：57 个问题的实现思路](https://blog.imggb.top/notes/typescript-exercise-answers) | [typescript/README.md](../typescript/README.md) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 与全栈开发术语速查](https://blog.imggb.top/notes/typescript-glossary) | [typescript/README.md](../typescript/README.md) | 保留机制讲解并提供工程应用定位 |
| [TypeScript 任务管理项目：功能、接口与数据约定](https://blog.imggb.top/notes/typescript-task-project) | [typescript/apps/api/src/app.ts](../typescript/apps/api/src/app.ts) | 完整实作与故障流程关联 |

运行证据与未验证范围见 verification.md；新工程教程由 scripts/package.py 从同一份 README 与讲解生成到博客，不能在生成副本上另行维护实现。
