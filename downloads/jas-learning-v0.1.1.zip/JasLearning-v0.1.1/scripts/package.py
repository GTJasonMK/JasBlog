"""从已提交源码生成固定版本包，拒绝覆盖外部修改或已有不同版本制品。"""

import argparse
from io import BytesIO
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import tomllib
from tempfile import NamedTemporaryFile
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
LESSONS = [
    (
        "database/README.md",
        "database-production-lab",
        "数据库完整实作：并发、权限、迁移与恢复",
        "database-labs",
        "数据库",
        "database-00-learning-guide",
    ),
    (
        "typescript/README.md",
        "typescript-production-lab",
        "TypeScript 完整实作：多用户任务系统与交付",
        "typescript-12-delivery",
        "TypeScript",
        "typescript-00-learning-guide",
    ),
    (
        "go/README.md",
        "go-production-lab",
        "Go 完整实作：事务订单、异步受理与消息重放",
        "go-part4",
        "Go",
        "go-00-learning-guide",
    ),
    (
        "python/README.md",
        "python-production-lab",
        "Python 完整实作：安全重跑与多用户服务",
        "python-part5",
        "Python",
        "python-00-learning-guide",
    ),
    (
        "docs/models.md",
        "python-model-production-lab",
        "Python 模型交付：数据、评估、推理与回滚",
        "python-part5",
        "Python",
        "python-00-learning-guide",
    ),
    (
        "docs/kubernetes.md",
        "go-kubernetes-lab",
        "Kubernetes 教学实作：配置作用与发布恢复",
        "go-part6",
        "Go",
        "go-00-learning-guide",
    ),
]


def digest(value):
    return hashlib.sha256(value).hexdigest()


def safe_members(names):
    result = []
    forbidden = {
        ".git",
        ".venv",
        ".local",
        ".run",
        "node_modules",
        "__pycache__",
        "test-results",
        "build",
    }
    for name in names:
        path = PurePosixPath(name)
        if (
            path.is_absolute()
            or ".." in path.parts
            or forbidden.intersection(path.parts)
            or (path.name.startswith(".env") and path.name != ".env.example")
            or path.suffix in {".pem", ".key", ".joblib", ".pth", ".pt", ".dump", ".db"}
        ):
            raise ValueError(f"禁止进入源码包的路径: {name}")
        result.append(name)
    return sorted(result)


def archive(prefix, entries):
    buffer = BytesIO()
    with ZipFile(buffer, "w", compression=ZIP_DEFLATED, compresslevel=9) as zipped:
        for name, content in sorted(entries.items()):
            info = ZipInfo(f"{prefix}/{name}", date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            zipped.writestr(info, content)
    return buffer.getvalue()


def atomic_write(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with NamedTemporaryFile(dir=path.parent, delete=False) as file:
            temporary = Path(file.name)
            file.write(content)
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary, path)
    finally:
        if temporary:
            temporary.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--destination", type=Path, required=True)
    parser.add_argument("--notes", type=Path)
    args = parser.parse_args()
    status = subprocess.check_output(
        ["git", "status", "--porcelain"], cwd=ROOT, text=True
    )
    if status:
        raise RuntimeError("先提交并验证学习仓库，再生成固定版本，不能打包未提交状态")
    version = (ROOT / "VERSION").read_text().strip()
    components = {
        "typescript": json.loads((ROOT / "typescript/package.json").read_text())[
            "version"
        ],
        "python": tomllib.loads((ROOT / "python/pyproject.toml").read_text())[
            "project"
        ]["version"],
    }
    if not version or any(character not in "0123456789." for character in version):
        raise ValueError("VERSION 只允许数字与点")
    commit = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
    ).strip()
    names = safe_members(
        subprocess.check_output(["git", "ls-files"], cwd=ROOT, text=True).splitlines()
    )
    entries = {}
    for name in names:
        path = ROOT / name
        if path.is_symlink():
            raise ValueError(f"源码不包含符号链接: {name}")
        entries[name] = path.read_bytes()
    release = {
        "version": version,
        "components": components,
        "commit": commit,
        "files": {name: digest(content) for name, content in entries.items()},
    }
    entries["RELEASE.json"] = (
        json.dumps(release, ensure_ascii=False, indent=2) + "\n"
    ).encode()
    outputs = {}
    source_name = f"jas-learning-v{version}.zip"
    outputs[source_name] = (
        args.destination / source_name,
        archive(f"JasLearning-v{version}", entries),
    )
    standalone = {
        name.removeprefix("database/"): content
        for name, content in entries.items()
        if name.startswith("database/sql/")
        or name
        in {
            "database/compose.yaml",
            "database/compose.recovery.yaml",
            "database/.gitignore",
        }
    }
    standalone["README.md"] = (ROOT / "database/standalone.md").read_bytes()
    outputs["database-labs.zip"] = (
        args.destination / "database-labs.zip",
        archive("database-labs", standalone),
    )
    for name, content in standalone.items():
        outputs[f"database-labs/{name}"] = (
            args.destination / "database-labs" / name,
            content,
        )
    if args.notes:
        for source, slug, title, category, family, directory in LESSONS:
            body = (ROOT / source).read_text().split("\n", 1)[1].lstrip()
            metadata = f'---\ntitle: {json.dumps(title, ensure_ascii=False)}\ndate: "2026-11-15"\nexcerpt: "沿固定版本完整工程解释业务边界、失败处理与验证，区分本地实测、配置检查和待运行场景。"\ntags: [{json.dumps(family)}, "工程实践"]\ncategory: "{category}"\npublication: "published"\ndisplay: {{ "toc": true }}\npublishedAt: "2026-11-15"\n---\n\n'
            entry = f"[下载 {version} 版完整源码](/downloads/{source_name})，解压后从项目根目录按步骤运行。[版本与校验信息](/downloads/jas-learning-v{version}.json)。\n\n"
            links = [f"[系列目录](/notes/{directory})"]
            if slug == "python-production-lab":
                links.append("[模型交付](/notes/python-model-production-lab)")
            if slug != "go-kubernetes-lab":
                links.append("[Kubernetes 配置](/notes/go-kubernetes-lab)")
            navigation = "\n\n" + " · ".join(links) + "\n"
            outputs[f"notes/{slug}.md"] = (
                args.notes / f"{slug}.md",
                (metadata + entry + body + navigation).encode(),
            )
    current = args.destination / "jas-learning-current.json"
    previous = json.loads(current.read_text()) if current.exists() else {"outputs": {}}
    original = json.loads((ROOT / "database/published-original.json").read_text())
    for name, (path, content) in outputs.items():
        if not path.exists() or path.read_bytes() == content:
            continue
        existing = digest(path.read_bytes())
        if name == source_name or existing not in {
            previous["outputs"].get(name),
            original.get(name),
        }:
            raise RuntimeError(f"目标有外部修改或固定制品已存在: {path}")
    manifest = {
        "version": version,
        "commit": commit,
        "components": components,
        "outputs": {name: digest(content) for name, (_, content) in outputs.items()},
    }
    serialized = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode()
    version_manifest = args.destination / f"jas-learning-v{version}.json"
    if version_manifest.exists() and version_manifest.read_bytes() != serialized:
        raise RuntimeError("固定版本清单已经存在，不能覆盖另一份内容")
    for path, content in outputs.values():
        atomic_write(path, content)
    atomic_write(version_manifest, serialized)
    atomic_write(current, serialized)
    print(
        json.dumps(
            {
                "version": version,
                "commit": commit,
                "source_zip_sha256": manifest["outputs"][source_name],
                "outputs": len(outputs),
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
