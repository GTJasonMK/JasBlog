import importlib.util
from io import BytesIO
from pathlib import Path
import unittest
from zipfile import ZipFile

specification = importlib.util.spec_from_file_location(
    "learning_package", Path(__file__).with_name("package.py")
)
package = importlib.util.module_from_spec(specification)
specification.loader.exec_module(package)


class PackagingTest(unittest.TestCase):
    def test_reproducible_archive_and_exact_bytes(self):
        entries = {"README.md": "教学源码".encode(), "src/main.py": b"print('ok')\n"}
        first = package.archive("course", entries)
        self.assertEqual(
            first, package.archive("course", dict(reversed(list(entries.items()))))
        )
        with ZipFile(BytesIO(first)) as archive:
            self.assertEqual(archive.read("course/src/main.py"), entries["src/main.py"])

    def test_private_runtime_files_and_traversal_are_rejected(self):
        for path in (
            ".env",
            "python/.local/passwords.json",
            "../outside",
            "/root/file",
            "model.pth",
            "node_modules/package.json",
        ):
            with self.assertRaises(ValueError):
                package.safe_members([path])
        self.assertEqual(
            package.safe_members([".env.example", "src/main.py"]),
            [".env.example", "src/main.py"],
        )


if __name__ == "__main__":
    unittest.main()
