"""只验证渲染结果与 Kubernetes Schema，不把静态检查记录成已部署。"""

from decimal import Decimal
from pathlib import Path
import json
import shutil
import subprocess
import yaml

ROOT = Path(__file__).resolve().parents[1]
OVERLAYS = (
    "database",
    "typescript/deploy",
    "go/deploy",
    "python/deploy/api",
    "python/deploy/forecast",
    "python/deploy/vision",
)


def quantity(value):
    value = str(value)
    for suffix, scale in (
        ("Gi", 1024**3),
        ("Mi", 1024**2),
        ("Ki", 1024),
        ("m", Decimal("0.001")),
    ):
        if value.endswith(suffix):
            return Decimal(value[: -len(suffix)]) * scale
    return Decimal(value)


def inspect(documents):
    identities = set()
    pods = []
    for document in documents:
        identity = (
            document["kind"],
            document["metadata"].get("namespace"),
            document["metadata"]["name"],
        )
        assert identity not in identities, f"重复资源 {identity}"
        identities.add(identity)
        if document["kind"] in {"Deployment", "StatefulSet"}:
            spec = document["spec"]
            labels = spec["template"]["metadata"]["labels"]
            assert all(
                labels.get(key) == value
                for key, value in spec["selector"]["matchLabels"].items()
            )
            pods.append(spec["template"])
        elif document["kind"] == "Job":
            pods.append(document["spec"]["template"])
        if document["kind"] == "Secret":
            raise ValueError("教学发布物不能包含实际 Secret")
    for pod in pods:
        for container in pod["spec"]["containers"]:
            assert ":latest" not in container["image"]
            assert ":" in container["image"] or "@sha256:" in container["image"]
            for resource in ("cpu", "memory"):
                assert quantity(
                    container["resources"]["requests"][resource]
                ) <= quantity(container["resources"]["limits"][resource])
    for service in (value for value in documents if value["kind"] == "Service"):
        selector = service["spec"].get("selector", {})
        matches = [
            pod
            for pod in pods
            if all(
                pod.get("metadata", {}).get("labels", {}).get(key) == value
                for key, value in selector.items()
            )
        ]
        assert matches, f"Service 无匹配工作负载: {service['metadata']['name']}"
        for port in service["spec"]["ports"]:
            target = port.get("targetPort", port["port"])
            assert any(
                any(
                    target == item.get("name") or target == item["containerPort"]
                    for container in pod["spec"]["containers"]
                    for item in container.get("ports", [])
                )
                for pod in matches
            )


def main():
    tools = {}
    for name in ("kustomize", "kubeconform"):
        local = ROOT / ".local/bin" / name
        tools[name] = str(local) if local.exists() else shutil.which(name)
        if not tools[name]:
            raise RuntimeError(f"缺少 {name}，按 docs/kubernetes.md 安装固定版本")
    output = ROOT / ".local/rendered"
    output.mkdir(parents=True, exist_ok=True)
    reports = []
    for overlay in OVERLAYS:
        rendered = subprocess.check_output(
            [tools["kustomize"], "build", str(ROOT / overlay)], text=True
        )
        documents = list(yaml.safe_load_all(rendered))
        inspect(documents)
        path = output / (overlay.replace("/", "-") + ".yaml")
        path.write_text(rendered)
        subprocess.run(
            [
                tools["kubeconform"],
                "-strict",
                "-summary",
                "-kubernetes-version",
                "1.35.0",
                str(path),
            ],
            check=True,
        )
        reports.append(
            {
                "overlay": overlay,
                "resources": len(documents),
                "schema_checked": True,
                "deployed": False,
            }
        )
    cron = ROOT / "python/deploy/etl.yaml"
    subprocess.run(
        [
            tools["kubeconform"],
            "-strict",
            "-summary",
            "-kubernetes-version",
            "1.35.0",
            str(cron),
        ],
        check=True,
    )
    (output / "results.json").write_text(json.dumps(reports, indent=2))
    print(json.dumps(reports, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    assert quantity("1Gi") == quantity("1024Mi")
    assert quantity("100m") < quantity("1")
    main()
