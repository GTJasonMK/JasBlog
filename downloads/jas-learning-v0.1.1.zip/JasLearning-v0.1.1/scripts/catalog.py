"""为原有四个系列生成章节到完整工程的映射，不把结构检查冒充示例实测。"""

import argparse
import hashlib
import json
from pathlib import Path
import re
import yaml

ROOT = Path(__file__).resolve().parents[1]
GENERATED = {
    "database-production-lab",
    "typescript-production-lab",
    "go-production-lab",
    "python-production-lab",
    "python-model-production-lab",
    "go-kubernetes-lab",
}
ROUTES = {
    "python": [
        (0, 0, "python/README.md"),
        (1, 13, "python/src/learning/etl.py"),
        (14, 17, "python/src/learning/api.py"),
        (18, 20, "python/src/learning/datasets.py"),
        (21, 26, "python/pyproject.toml"),
        (27, 32, "python/src/learning/inference.py"),
        (33, 36, "python/src/learning/etl.py"),
        (37, 38, "python/src/learning/forecast.py"),
        (39, 40, "python/src/learning/vision.py"),
        (41, 42, "python/src/learning/api.py"),
        (43, 43, "python/README.md"),
    ],
    "go": [
        (0, 0, "go/README.md"),
        (1, 14, "go/internal/order/store.go"),
        (15, 20, "go/internal/httpapi/router.go"),
        (21, 24, "go/internal/order/store.go"),
        (25, 28, "go/internal/order/queue.go"),
        (29, 32, "go/internal/order/store.go"),
        (33, 33, "go/internal/order/queue.go"),
        (34, 34, "go/internal/order/store.go"),
        (35, 36, "go/internal/order/store_test.go"),
        (37, 39, "go/README.md"),
        (40, 45, "docs/kubernetes.md"),
    ],
    "typescript": [
        (0, 4, "typescript/apps/web/src/main.tsx"),
        (5, 31, "typescript/packages/shared/src/index.ts"),
        (32, 40, "typescript/apps/web/src/main.tsx"),
        (41, 45, "typescript/apps/api/src/app.ts"),
        (46, 49, "typescript/apps/api/prisma/schema.prisma"),
        (50, 54, "typescript/apps/api/src/app.ts"),
        (55, 56, "typescript/browser/tasks.spec.ts"),
        (57, 57, "docs/kubernetes.md"),
    ],
    "database": [
        (0, 0, "database/README.md"),
        (1, 6, "database/sql/00-schema.sql"),
        (7, 10, "database/sql/03-place-order.sql"),
        (11, 13, "database/sql/05-performance.sql"),
        (14, 14, "database/sql/06-security-checks.sql"),
        (15, 16, "database/test_postgres.py"),
        (17, 19, "docs/kubernetes.md"),
        (20, 20, "database/test_postgres.py"),
        (21, 21, "database/mysql/check.py"),
        (22, 23, "database/README.md"),
    ],
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--notes", type=Path, required=True)
    args = parser.parse_args()
    entries = []
    for path in sorted(args.notes.glob("*.md")):
        family = path.stem.split("-", 1)[0]
        if family not in ROUTES or path.stem in GENERATED:
            continue
        raw = path.read_text()
        metadata = yaml.safe_load(raw.split("---", 2)[1])
        chapter = re.match(r"^[a-z]+-(\d{2})-", path.stem)
        source = f"{family}/README.md"
        if chapter:
            number = int(chapter.group(1))
            source = next(
                value for start, end, value in ROUTES[family] if start <= number <= end
            )
        elif family == "go" and "advanced" in path.stem:
            source = "go/README.md"
        elif family == "database" and "lab" in path.stem:
            source = "database/test_postgres.py"
        elif family == "typescript" and "task-project" in path.stem:
            source = "typescript/apps/api/src/app.ts"
        assert (ROOT / source).is_file(), source
        project = any(
            word in path.stem
            for word in (
                "project",
                "deployment",
                "lab",
                "operations",
                "cicd",
                "kubernetes",
            )
        )
        entries.append(
            {
                "slug": path.stem,
                "title": metadata["title"],
                "family": family,
                "source": source,
                "source_sha256": hashlib.sha256(raw.encode()).hexdigest(),
                "treatment": "完整实作与故障流程关联"
                if project
                else "保留机制讲解并提供工程应用定位",
                "verification": "章节结构与源码定位已检查；运行范围以工程验证记录为准",
            }
        )
    counts = {
        family: sum(value["family"] == family for value in entries) for family in ROUTES
    }
    if counts != {"python": 45, "go": 53, "typescript": 61, "database": 33}:
        raise ValueError(f"原资料集合变化，需要审查新增或删除文章: {counts}")
    (ROOT / "docs/chapter-map.json").write_text(
        json.dumps(
            {"version": "0.1.0", "counts": counts, "chapters": entries},
            ensure_ascii=False,
            indent=2,
        )
        + "\n"
    )
    lines = [
        "# 章节与实作覆盖表",
        "",
        "覆盖原有 192 篇文章。下表核对地址、章节结构与工程应用位置；不表示所有旧片段或所有外部专题都重新执行。基础机制保留现有讲解，完整实作和部署说明通过四套目录及新增工程文章接入。",
        "",
        "| 章节 | 工程应用位置 | 本轮处理 |",
        "|---|---|---|",
    ]
    for value in entries:
        lines.append(
            f"| [{value['title']}](https://blog.imggb.top/notes/{value['slug']}) | [{value['source']}](../{value['source']}) | {value['treatment']} |"
        )
    lines += [
        "",
        "运行证据与未验证范围见 verification.md；新工程教程由 scripts/package.py 从同一份 README 与讲解生成到博客，不能在生成副本上另行维护实现。",
        "",
    ]
    (ROOT / "docs/coverage.md").write_text("\n".join(lines))
    print(json.dumps({"chapters": len(entries), "counts": counts}, ensure_ascii=False))


if __name__ == "__main__":
    main()
