"""只管理本仓库的本机依赖；默认停止保留数据卷。"""

import argparse
import json
import os
from pathlib import Path
import secrets
import subprocess

ROOT = Path(__file__).resolve().parents[1]
STATE = ROOT / ".local/services.json"


def environment():
    if not STATE.exists():
        raise RuntimeError("请先运行 python scripts/services.py start postgres")
    values = json.loads(STATE.read_text())
    return {**os.environ, **values}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("start", "stop", "status", "run"))
    parser.add_argument("arguments", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if args.action == "start" and not STATE.exists():
        STATE.parent.mkdir(parents=True, exist_ok=True)
        password = secrets.token_urlsafe(24)
        values = {
            "LAB_PASSWORD": password,
            "PG_ADMIN_URL": f"postgresql://learning:{password}@127.0.0.1:55433/postgres",
            "DATABASE_URL": f"postgresql://learning:{password}@127.0.0.1:55433/learning_ts",
            "PY_DATABASE_URL": f"postgresql+psycopg://learning:{password}@127.0.0.1:55433/learning_python",
            "MYSQL_DSN": f"root:{password}@tcp(127.0.0.1:53306)/learning_go?parseTime=true&multiStatements=true",
            "REDIS_URL": f"redis://:{password}@127.0.0.1:56379/0",
            "KAFKA_BROKERS": "127.0.0.1:59092",
            "SESSION_SECRET": secrets.token_urlsafe(48),
            "APP_ORIGIN": "http://localhost:5173",
            "MOCK_PAYMENT_SECRET": secrets.token_urlsafe(32),
        }
        descriptor = os.open(STATE, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, "w") as file:
            json.dump(values, file, indent=2)
    env = environment()
    if args.action == "start":
        values = json.loads(STATE.read_text())
        changed = False
        for key in ("JWT_SECRET", "DEMO_PASSWORD"):
            if key not in values:
                values[key] = secrets.token_urlsafe(32)
                changed = True
        if changed:
            with STATE.open("w") as file:
                json.dump(values, file, indent=2)
            env = {**os.environ, **values}
    arguments = args.arguments
    if arguments[:1] == ["--"]:
        arguments = arguments[1:]
    if args.action == "run":
        if not arguments:
            parser.error("run -- 后需要命令")
        raise SystemExit(subprocess.call(arguments, env=env))
    if not set(arguments) <= {"postgres", "mysql", "redis", "kafka"}:
        parser.error("只能管理 postgres、mysql、redis、kafka")
    command = ["docker", "compose", "-f", str(ROOT / "compose.yaml")]
    if args.action == "start":
        if not arguments:
            parser.error("start 后显式选择服务，避免一次启动全部依赖")
        subprocess.run(
            command + ["up", "-d", "--wait", "--wait-timeout", "180"] + arguments,
            env=env,
            check=True,
        )
        if "postgres" in arguments:
            for database in ("learning_ts", "learning_python"):
                query = f"SELECT 1 FROM pg_database WHERE datname = '{database}'"
                exists = subprocess.check_output(
                    command
                    + [
                        "exec",
                        "-T",
                        "postgres",
                        "psql",
                        "-U",
                        "learning",
                        "-d",
                        "postgres",
                        "-tAc",
                        query,
                    ],
                    env=env,
                    text=True,
                ).strip()
                if not exists:
                    subprocess.run(
                        command
                        + [
                            "exec",
                            "-T",
                            "postgres",
                            "createdb",
                            "-U",
                            "learning",
                            database,
                        ],
                        env=env,
                        check=True,
                    )
    else:
        subprocess.run(
            command + (["ps"] if args.action == "status" else ["stop"]) + arguments,
            env=env,
            check=True,
        )


if __name__ == "__main__":
    main()
