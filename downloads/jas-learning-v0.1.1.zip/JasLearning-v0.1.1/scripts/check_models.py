"""加载已训练的真实数据模型，验证 HTTP 推理、拒绝路径和重载一致性。"""

from pathlib import Path
import json
import secrets
import statistics
import time

from fastapi.testclient import TestClient
import joblib
import numpy as np
from learning.forecast import dataset
from learning.inference import create_app

ROOT = Path(__file__).resolve().parents[1]


def main():
    reports = []
    token = secrets.token_urlsafe(32)
    headers = {"authorization": "Bearer " + token}
    features, _, _ = dataset(ROOT / ".local/data/bike/hour.csv")
    timestamp = features.index[-1]
    values = features.iloc[-1]
    payload = {
        "target": timestamp.isoformat(),
        "history": [
            {
                "timestamp": (
                    timestamp - __import__("datetime").timedelta(hours=lag)
                ).isoformat(),
                "count": float(values[f"lag_{lag}"]),
            }
            for lag in (1, 24, 168)
        ],
    }
    directory = ROOT / ".local/models/forecast-v1"
    with TestClient(create_app(directory, "forecast", token)) as client:
        durations = []
        for _ in range(5):
            started = time.perf_counter()
            response = client.post("/predict", json=payload, headers=headers)
            durations.append(1000 * (time.perf_counter() - started))
            assert response.status_code == 200, response.text
        model = joblib.load(directory / "forecast.joblib")
        np.testing.assert_allclose(
            response.json()["count"], model.predict(features.iloc[-1:])[0]
        )
        assert client.post("/predict", json=payload).status_code == 401
        reports.append(
            {
                "kind": "forecast",
                "version": response.json()["version"],
                "five_request_ms": durations,
                "median_ms": statistics.median(durations),
                "count": response.json()["count"],
            }
        )
    directory = ROOT / ".local/models/vision-v1"
    image = next((ROOT / ".local/data/beans-test/test/healthy").glob("*.jpg"))
    with TestClient(create_app(directory, "vision", token)) as client:
        durations = []
        for _ in range(5):
            started = time.perf_counter()
            response = client.post(
                "/predict",
                files={"file": (image.name, image.read_bytes(), "image/jpeg")},
                headers=headers,
            )
            durations.append(1000 * (time.perf_counter() - started))
            assert response.status_code == 200, response.text
        assert response.json()["label"] in {"angular_leaf_spot", "bean_rust", "healthy"}
        assert (
            client.post(
                "/predict",
                files={"file": ("invalid.jpg", b"not an image", "image/jpeg")},
                headers=headers,
            ).status_code
            == 422
        )
        reports.append(
            {
                "kind": "vision",
                "version": response.json()["version"],
                "five_request_ms": durations,
                "median_ms": statistics.median(durations),
                "prediction": response.json(),
            }
        )
    destination = ROOT / ".local/verification"
    destination.mkdir(parents=True, exist_ok=True)
    (destination / "models.json").write_text(json.dumps(reports, indent=2))
    print(json.dumps(reports, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
