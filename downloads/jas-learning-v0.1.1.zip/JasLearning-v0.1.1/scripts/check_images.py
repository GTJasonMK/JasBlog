"""在隔离数据库中验证镜像迁移、非 root 启动和模型 HTTP 推理。"""

import json
import os
import secrets
from pathlib import Path
import subprocess
import time
from urllib.error import URLError
from urllib.parse import urlsplit, urlunsplit
from urllib.request import Request, urlopen
from uuid import uuid4

import psycopg
from psycopg import sql
import pymysql
from services import environment

ROOT = Path(__file__).resolve().parents[1]


def main():
    values = environment()
    prefix = "image_" + uuid4().hex[:12]
    pg_names = [prefix + "_ts", prefix + "_py"]
    with psycopg.connect(values["PG_ADMIN_URL"], autocommit=True) as connection:
        for name in pg_names:
            connection.execute(
                sql.SQL("CREATE DATABASE {}").format(sql.Identifier(name))
            )
    with (
        pymysql.connect(
            host="127.0.0.1",
            port=53306,
            user="root",
            password=values["LAB_PASSWORD"],
            autocommit=True,
        ) as connection,
        connection.cursor() as cursor,
    ):
        cursor.execute(f"CREATE DATABASE `{prefix}_go`")
    parsed = urlsplit(values["PG_ADMIN_URL"])
    authority = parsed.netloc.rsplit("@", 1)[0] + "@postgres:5432"
    pg_urls = [
        urlunsplit(("postgresql", authority, "/" + name, "", "")) for name in pg_names
    ]
    common = {
        **values,
        "DATABASE_URL": pg_urls[0],
        "PY_DATABASE_URL": pg_urls[1].replace("postgresql://", "postgresql+psycopg://"),
        "MYSQL_DSN": f"root:{values['LAB_PASSWORD']}@tcp(mysql:3306)/{prefix}_go?parseTime=true&multiStatements=true",
        "REDIS_URL": values["REDIS_URL"].replace("127.0.0.1:56379", "redis:6379"),
        "KAFKA_BROKERS": "kafka:9092",
        "QUEUE_PREFIX": prefix,
        "APP_ORIGIN": "https://tasks.example.invalid",
        "APP_ENV": "production",
        "NODE_ENV": "production",
        "INFERENCE_TOKEN": secrets.token_urlsafe(32),
    }
    report = []
    logs = ROOT / ".local/verification"
    logs.mkdir(parents=True, exist_ok=True)
    base = ["docker", "run", "--rm", "--network", "jas-learning_default"]

    def environment_flags(names):
        return [part for name in names for part in ("--env", name)]

    migrations = [
        ("jaslearning/typescript-migrate:0.1.0", ["DATABASE_URL"], []),
        (
            "jaslearning/python-api:0.1.0",
            ["PY_DATABASE_URL"],
            ["python", "-m", "learning.migrate"],
        ),
        ("jaslearning/go-orders:0.1.0", ["MYSQL_DSN"], ["migrate"]),
    ]
    for image, keys, command in migrations:
        with (logs / (image.split("/")[1].replace(":", "-") + "-migration.log")).open(
            "w"
        ) as file:
            subprocess.run(
                base + environment_flags(keys) + [image] + command,
                env={**os.environ, **common},
                stdout=file,
                stderr=file,
                check=True,
                timeout=120,
            )
        report.append({"image": image, "migration": "passed"})
    specifications = [
        (
            "typescript-api",
            "0.1.0",
            ["DATABASE_URL", "SESSION_SECRET", "APP_ORIGIN", "NODE_ENV"],
            "/readyz",
        ),
        ("typescript-web", "0.1.0", [], "/"),
        (
            "python-api",
            "0.1.0",
            ["PY_DATABASE_URL", "APP_ORIGIN", "APP_ENV"],
            "/readyz",
        ),
        (
            "go-orders",
            "0.1.0",
            ["MYSQL_DSN", "REDIS_URL", "KAFKA_BROKERS", "QUEUE_PREFIX", "JWT_SECRET"],
            "/readyz",
        ),
        (
            "forecast",
            "0.1.0-forecast-v1",
            ["MODEL_KIND", "APP_ENV", "INFERENCE_TOKEN"],
            "/readyz",
        ),
        (
            "vision",
            "0.1.0-vision-v1",
            ["MODEL_KIND", "APP_ENV", "INFERENCE_TOKEN"],
            "/readyz",
        ),
    ]
    for index, (name, version, keys, health) in enumerate(specifications):
        image = f"jaslearning/{name}:{version}"
        identity = json.loads(
            subprocess.check_output(["docker", "image", "inspect", image], text=True)
        )[0]
        assert identity["Config"]["User"] not in {"", "0", "root"}
        local = {**common, "MODEL_KIND": name}
        container = prefix + "-" + name
        port = 18200 + index
        subprocess.run(
            base[:2]
            + ["-d", "--name", container]
            + base[2:]
            + ["-p", f"127.0.0.1:{port}:8080", "--memory", "1536m", "--cpus", "2"]
            + environment_flags(keys)
            + [image],
            env={**os.environ, **local},
            stdout=subprocess.DEVNULL,
            check=True,
        )
        try:
            deadline = time.monotonic() + 30
            while True:
                try:
                    with urlopen(
                        f"http://127.0.0.1:{port}{health}", timeout=2
                    ) as response:
                        assert response.status == 200
                        break
                except (URLError, TimeoutError, ConnectionResetError):
                    if time.monotonic() >= deadline:
                        raise RuntimeError(f"{name} 未就绪，请查看本地镜像日志")
                    time.sleep(0.1)
            if name == "forecast":
                payload = {
                    "target": "2012-01-08T00:00:00Z",
                    "history": [
                        {"timestamp": stamp, "count": 10}
                        for stamp in (
                            "2012-01-07T23:00:00Z",
                            "2012-01-07T00:00:00Z",
                            "2012-01-01T00:00:00Z",
                        )
                    ],
                }
                request = Request(
                    f"http://127.0.0.1:{port}/predict",
                    data=json.dumps(payload).encode(),
                    headers={
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + common["INFERENCE_TOKEN"],
                    },
                )
                with urlopen(request, timeout=5) as response:
                    assert json.load(response)["version"] == "forecast-v1"
            elif name == "vision":
                image_file = next(
                    (ROOT / ".local/data/beans-test/test/healthy").glob("*.jpg")
                )
                boundary = "learning" + uuid4().hex
                content = (
                    f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="sample.jpg"\r\nContent-Type: image/jpeg\r\n\r\n'.encode()
                    + image_file.read_bytes()
                    + f"\r\n--{boundary}--\r\n".encode()
                )
                request = Request(
                    f"http://127.0.0.1:{port}/predict",
                    data=content,
                    headers={
                        "Content-Type": f"multipart/form-data; boundary={boundary}",
                        "Authorization": "Bearer " + common["INFERENCE_TOKEN"],
                    },
                )
                with urlopen(request, timeout=10) as response:
                    predicted = json.load(response)
                    assert predicted["version"] == "vision-v1"
                    assert predicted["label"] in {
                        "angular_leaf_spot",
                        "bean_rust",
                        "healthy",
                    }
            report.append(
                {
                    "image": image,
                    "id": identity["Id"],
                    "user": identity["Config"]["User"],
                    "health": "passed",
                }
            )
        finally:
            with (logs / (name + "-container.log")).open("w") as file:
                subprocess.run(
                    ["docker", "logs", container], stdout=file, stderr=file, check=True
                )
            subprocess.run(
                ["docker", "stop", "--time", "25", container],
                stdout=subprocess.DEVNULL,
                check=True,
            )
    (logs / "images.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
