"""验证一个明确阶段后打标签；不自动提交，也不覆盖已有标签。"""

import argparse
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
STAGES = {
    "database": [
        "python3",
        "scripts/services.py",
        "run",
        "--",
        ".venv/bin/python",
        "database/test_postgres.py",
    ],
    "typescript": [
        "python3",
        "scripts/services.py",
        "run",
        "--",
        "npm",
        "--prefix",
        "typescript",
        "test",
    ],
    "go": [
        "python3",
        "scripts/services.py",
        "run",
        "--",
        "env",
        "LEARNING_INTEGRATION=1",
        "go",
        "-C",
        "go",
        "test",
        "-race",
        "-timeout",
        "60s",
        "./...",
    ],
    "python": [
        "python3",
        "scripts/services.py",
        "run",
        "--",
        ".venv/bin/python",
        "-m",
        "pytest",
        "python/tests",
        "-q",
    ],
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("course", choices=STAGES)
    args = parser.parse_args()
    if subprocess.check_output(["git", "status", "--porcelain"], cwd=ROOT, text=True):
        raise RuntimeError("工作区有未提交修改，阶段检查与标签必须对应同一提交")
    subprocess.run(STAGES[args.course], cwd=ROOT, check=True)
    version = (ROOT / "VERSION").read_text().strip()
    subprocess.run(
        [
            "git",
            "tag",
            "-a",
            f"{args.course}-v{version}",
            "-m",
            f"{args.course} 已验证阶段 {version}",
        ],
        cwd=ROOT,
        check=True,
    )


if __name__ == "__main__":
    main()
