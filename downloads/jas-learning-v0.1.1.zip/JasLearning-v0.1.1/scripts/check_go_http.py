"""通过真正的 API 与 worker 验证 JWT、受理查询和订单持久化。"""

import json
from pathlib import Path
import signal
import subprocess
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from uuid import uuid4
import pymysql
from services import environment

ROOT = Path(__file__).resolve().parents[1]


def main():
    values = environment()
    name = "learning_http_" + uuid4().hex[:12]
    with pymysql.connect(
        host="127.0.0.1",
        port=53306,
        user="root",
        password=values["LAB_PASSWORD"],
        autocommit=True,
    ) as connection:
        with connection.cursor() as cursor:
            cursor.execute(f"CREATE DATABASE `{name}`")
    values["MYSQL_DSN"] = values["MYSQL_DSN"].replace("/learning_go?", f"/{name}?")
    values["PORT"] = "18080"
    values["QUEUE_PREFIX"] = name
    values["GIN_MODE"] = "release"
    binary = ROOT / ".local/bin"
    binary.mkdir(parents=True, exist_ok=True)
    log_path = ROOT / ".local/verification"
    log_path.mkdir(parents=True, exist_ok=True)
    processes = []
    with (log_path / "go-http.log").open("w") as log:
        for target in ("api", "worker"):
            subprocess.run(
                [
                    "go",
                    "build",
                    "-o",
                    str(binary / f"orders-{target}"),
                    f"./cmd/{target}",
                ],
                cwd=ROOT / "go",
                env=values,
                check=True,
            )
        for command in ("migrate", "seed", "topics"):
            subprocess.run(
                [str(binary / "orders-api"), command],
                cwd=ROOT,
                env=values,
                stdout=log,
                stderr=log,
                check=True,
            )
        try:
            for target in ("api", "worker"):
                processes.append(
                    subprocess.Popen(
                        [str(binary / f"orders-{target}")],
                        cwd=ROOT,
                        env=values,
                        stdout=log,
                        stderr=log,
                    )
                )

            def request(path, payload=None, token=None, key=None, method=None):
                headers = {"Content-Type": "application/json"}
                if token:
                    headers["Authorization"] = "Bearer " + token
                if key:
                    headers["Idempotency-Key"] = key
                data = json.dumps(payload).encode() if payload is not None else None
                query = Request(
                    "http://127.0.0.1:18080" + path,
                    data=data,
                    headers=headers,
                    method=method,
                )
                try:
                    with urlopen(query, timeout=5) as response:
                        content = response.read()
                        return response.status, json.loads(content) if content else None
                except HTTPError as error:
                    return error.code, json.loads(error.read())

            deadline = time.monotonic() + 15
            while True:
                try:
                    if request("/readyz")[0] == 200:
                        break
                except URLError:
                    if time.monotonic() >= deadline:
                        raise RuntimeError("API 未能就绪，检查受控本地日志")
                    time.sleep(0.1)
            assert request("/api/v1/orders/unknown")[0] == 401
            status, result = request(
                "/api/v1/auth/login",
                {"email": "a@example.invalid", "password": values["DEMO_PASSWORD"]},
            )
            assert status == 200
            token = result["access_token"]
            assert (
                request(
                    "/api/v1/orders",
                    {"product_id": 1, "quantity": 1, "user_id": 2},
                    token,
                    "forged",
                )[0]
                == 400
            )
            assert (
                request(
                    "/api/v1/orders", {"product_id": 1, "quantity": 1}, token, "../bad"
                )[0]
                == 400
            )
            normal = {"product_id": 1, "quantity": 1}
            status, order = request("/api/v1/orders", normal, token, "normal")
            assert status == 201
            assert (
                request("/api/v1/orders", normal, token, "normal")[1]["id"]
                == order["id"]
            )
            status, accepted = request(
                "/api/v1/campaigns/1/claims", normal, token, "async"
            )
            assert status == 202
            deadline = time.monotonic() + 30
            while True:
                status, final = request(accepted["status_url"], token=token)
                assert status == 200
                if final["status"] == "done":
                    break
                if time.monotonic() >= deadline:
                    raise RuntimeError("异步请求未完成，保留状态和日志供排查")
                time.sleep(0.1)
            assert request("/api/v1/orders/" + final["order_id"], token=token)[0] == 200
            with (
                pymysql.connect(
                    host="127.0.0.1",
                    port=53306,
                    user="root",
                    password=values["LAB_PASSWORD"],
                    database=name,
                ) as connection,
                connection.cursor() as cursor,
            ):
                cursor.execute("SELECT stock FROM products WHERE id=1")
                assert cursor.fetchone()[0] == 98
                cursor.execute("SELECT count(*) FROM orders")
                assert cursor.fetchone()[0] == 2
            print(
                json.dumps(
                    {
                        "database": name,
                        "http_and_worker": "passed",
                        "unauthenticated": 401,
                        "forged_identity": 400,
                        "normal_and_async_orders": 2,
                        "final_stock": 98,
                    }
                )
            )
        finally:
            for process in processes:
                process.send_signal(signal.SIGTERM)
            for process in processes:
                try:
                    process.wait(timeout=25)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
                    raise RuntimeError("本次创建的进程关闭超时，已保存日志")


if __name__ == "__main__":
    main()
