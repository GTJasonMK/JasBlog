import { defineConfig } from "@playwright/test";
export default defineConfig({
  testDir: "browser",
  timeout: 60_000,
  workers: 1,
  use: {
    baseURL: "http://localhost:5173",
    timezoneId: "Asia/Shanghai",
    trace: "retain-on-failure",
    launchOptions: { executablePath: process.env.CHROME_PATH },
  },
  webServer: [
    {
      command: "node apps/api/dist/server.js",
      url: "http://localhost:3001/readyz",
      reuseExistingServer: false,
    },
    {
      command: "npm run dev -w @learning/web",
      url: "http://localhost:5173",
      reuseExistingServer: false,
    },
  ],
});
