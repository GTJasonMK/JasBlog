import test from "node:test";
import assert from "node:assert/strict";
import { CreateTask, UpdateTask } from "../src/index.js";

test("创建归一化标题，归属与未知状态不能由外部输入", () => {
  assert.equal(
    CreateTask.parse({ title: "  准备发布  ", status: "todo" }).title,
    "准备发布",
  );
  for (const input of [
    { title: " ", status: "todo" },
    { title: "x", status: "unknown" },
    { title: "x", status: "todo", ownerId: "other" },
  ]) {
    assert.equal(CreateTask.safeParse(input).success, false);
  }
});
test("PATCH 区分保留与清除，拒绝空操作和必填字段的 null", () => {
  assert.deepEqual(UpdateTask.parse({ description: null }), {
    description: null,
  });
  assert.equal(UpdateTask.safeParse({}).success, false);
  assert.equal(UpdateTask.safeParse({ title: null }).success, false);
});
