import { z } from "zod";

export const Status = z.enum(["todo", "in_progress", "done"]);
const title = z.string().trim().min(1).max(120);
const fields = {
  title,
  description: z.string().max(4000).nullable().optional(),
  status: Status,
  dueAt: z.iso.datetime({ offset: true }).nullable().optional(),
};
export const CreateTask = z.object(fields).strict();
export const UpdateTask = z
  .object(fields)
  .partial()
  .strict()
  .refine((value) => Object.keys(value).length > 0, "至少修改一个字段");
export const Credentials = z
  .object({
    email: z
      .email()
      .max(254)
      .transform((value) => value.toLowerCase()),
    password: z.string().min(12).max(128),
  })
  .strict();
export const Task = z.object({
  id: z.uuid(),
  title,
  description: z.string().nullable(),
  status: Status,
  dueAt: z.iso.datetime({ offset: true }).nullable(),
  createdAt: z.iso.datetime({ offset: true }),
  updatedAt: z.iso.datetime({ offset: true }),
});
export const User = z.object({ id: z.uuid(), email: z.email() });
export const TaskPage = z.object({
  items: z.array(Task),
  nextCursor: z.string().nullable(),
});
export const ApiError = z.object({
  error: z.object({
    code: z.string(),
    message: z.string(),
    requestId: z.string().optional(),
  }),
});
export type TaskData = z.infer<typeof Task>;
export type UserData = z.infer<typeof User>;
