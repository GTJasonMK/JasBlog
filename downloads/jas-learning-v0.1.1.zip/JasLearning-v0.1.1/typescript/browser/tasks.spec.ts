import { test, expect } from "@playwright/test";
test("注册、创建、刷新、编辑、失败草稿、删除与退出", async ({ page }) => {
  const password = "browser-test-password-1234";
  await page.goto("/");
  await page.getByRole("button", { name: "还没有账户？注册" }).click();
  await page.getByLabel("邮箱").fill(`browser-${Date.now()}@example.invalid`);
  await page.getByLabel("密码", { exact: true }).fill(password);
  await page.getByRole("button", { name: "创建账户", exact: true }).click();
  await expect(page.getByRole("heading", { name: "我的任务" })).toBeVisible();
  await page.getByRole("button", { name: "新增任务", exact: true }).click();
  await page.getByLabel("标题", { exact: true }).fill("核对发布清单");
  await page.getByRole("button", { name: "保存任务", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "核对发布清单" }),
  ).toBeVisible();
  const tasks = await (await page.request.get("/api/tasks")).json();
  const identifier = tasks.items[0].id;
  const originalDue = "2026-12-01T18:24:35.123Z";
  expect(
    (
      await page.request.patch(`/api/tasks/${identifier}`, {
        headers: { Origin: "http://localhost:5173" },
        data: { dueAt: originalDue },
      })
    ).status(),
  ).toBe(200);
  await page.reload();
  await expect(
    page.getByRole("heading", { name: "核对发布清单" }),
  ).toBeVisible();
  await expect(page.locator("time")).toContainText("2026年12月2日 02:24");
  await page.getByRole("button", { name: "编辑 核对发布清单" }).click();
  await page
    .getByRole("combobox", { name: "状态", exact: true })
    .selectOption("done");
  await page.route("**/api/tasks/*", (route) =>
    route.request().method() === "PATCH"
      ? route.fulfill({
          status: 503,
          contentType: "application/json",
          body: JSON.stringify({
            error: { code: "UNAVAILABLE", message: "暂时无法保存" },
          }),
        })
      : route.continue(),
  );
  await page.getByRole("button", { name: "保存任务", exact: true }).click();
  await expect(page.getByRole("alert")).toContainText("暂时无法保存");
  await expect(page.getByLabel("标题", { exact: true })).toHaveValue(
    "核对发布清单",
  );
  await page.unroute("**/api/tasks/*");
  await page.getByRole("button", { name: "保存任务", exact: true }).click();
  await expect(page.locator(".status-done")).toContainText("已完成");
  expect(
    (await (await page.request.get(`/api/tasks/${identifier}`)).json()).dueAt,
  ).toBe(originalDue);
  await page.getByRole("button", { name: "编辑 核对发布清单" }).click();
  await page
    .getByRole("textbox", { name: "描述", exact: true })
    .fill("会话恢复后保留这份草稿");
  await page.request.post("/api/auth/logout", {
    headers: { Origin: "http://localhost:5173" },
  });
  await page.getByRole("button", { name: "保存任务", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "继续你的工作。" }),
  ).toBeVisible();
  await page.getByLabel("密码", { exact: true }).fill(password);
  await page.getByRole("button", { name: "登录", exact: true }).click();
  await expect(
    page.getByRole("textbox", { name: "描述", exact: true }),
  ).toHaveValue("会话恢复后保留这份草稿");
  await page.getByRole("button", { name: "保存任务", exact: true }).click();
  await expect(
    page
      .getByRole("list", { name: "任务列表" })
      .getByText("会话恢复后保留这份草稿", { exact: true }),
  ).toBeVisible();
  for (const width of [390, 1024, 1440]) {
    await page.setViewportSize({ width, height: 900 });
    expect(
      await page.evaluate(
        () =>
          document.documentElement.scrollWidth -
          document.documentElement.clientWidth,
      ),
    ).toBe(0);
    await page.screenshot({
      path: `test-results/tasks-${width}.png`,
      fullPage: true,
    });
  }
  page.once("dialog", (dialog) => dialog.accept());
  await page.getByRole("button", { name: "删除 核对发布清单" }).click();
  await expect(
    page.getByRole("heading", { name: "为下一步留个位置。" }),
  ).toBeVisible();
  await page.getByRole("button", { name: "退出", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "继续你的工作。" }),
  ).toBeVisible();
});
