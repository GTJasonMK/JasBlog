import { after, before, test } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { readFile } from "node:fs/promises";
import pg from "pg";
import request from "supertest";
import { createApp } from "../src/app.js";

const origin = "http://localhost:5173";
const sessionSecret = randomUUID();
let runtime: Awaited<ReturnType<typeof createApp>>;
let databaseUrl: string;
let name: string;
before(async () => {
  const adminUrl = process.env.PG_ADMIN_URL;
  assert.ok(adminUrl, "通过 scripts/services.py run 执行，不能跳过数据库测试");
  name = `ts_test_${randomUUID().replaceAll("-", "")}`;
  const admin = new pg.Client({ connectionString: adminUrl });
  await admin.connect();
  await admin.query(`CREATE DATABASE "${name}"`);
  await admin.end();
  const url = new URL(adminUrl);
  url.pathname = `/${name}`;
  databaseUrl = url.toString();
  const connection = new pg.Client({ connectionString: databaseUrl });
  await connection.connect();
  await connection.query(
    await readFile(
      new URL(
        "../prisma/migrations/202611150001_init/migration.sql",
        import.meta.url,
      ),
      "utf8",
    ),
  );
  await connection.end();
  runtime = await createApp({
    databaseUrl,
    sessionSecret,
    origin,
    production: false,
  });
});
after(async () => {
  if (runtime) await runtime.close();
});

test("真实数据库、持久化会话、资源隔离和拒绝写入", async () => {
  const a = request.agent(runtime.app);
  const b = request.agent(runtime.app);
  const credentials = {
    email: "a@example.invalid",
    password: "correct-horse-battery-staple",
  };
  assert.equal((await a.get("/api/tasks")).status, 401);
  assert.equal(
    (await a.post("/api/auth/register").send(credentials)).status,
    403,
  );
  const registered = await a
    .post("/api/auth/register")
    .set("Origin", origin)
    .send(credentials);
  assert.equal(registered.status, 201);
  assert.equal(registered.body.passwordHash, undefined);
  assert.equal(
    (
      await request(runtime.app)
        .post("/api/auth/register")
        .set("Origin", origin)
        .send(credentials)
    ).status,
    409,
  );
  assert.equal(
    (
      await request(runtime.app)
        .post("/api/auth/register")
        .set("Origin", origin)
        .send({ email: "x".repeat(17000), password: "test-password-1234" })
    ).status,
    413,
  );
  const cookie = registered.headers["set-cookie"][0].split(";")[0];
  assert.match(registered.headers["set-cookie"][0], /HttpOnly/);
  const replica = await createApp({ databaseUrl, sessionSecret, origin, production: false });
  assert.equal((await request(replica.app).get("/api/auth/me").set("Cookie", cookie)).status, 200);
  await replica.close();
  assert.equal((await request(replica.app).get("/readyz")).status, 503);
  assert.equal(
    (
      await b
        .post("/api/auth/register")
        .set("Origin", origin)
        .send({ ...credentials, email: "b@example.invalid" })
    ).status,
    201,
  );
  const created = await a
    .post("/api/tasks")
    .set("Origin", origin)
    .send({ title: "  准备发布  ", status: "todo" });
  assert.equal(created.status, 201);
  assert.equal(created.body.title, "准备发布");
  const id = created.body.id;
  assert.equal((await a.get(`/api/tasks/${id}`)).status, 200);
  for (const method of ["get", "patch", "delete"] as const) {
    const response = await b[method](`/api/tasks/${id}`)
      .set("Origin", origin)
      .send(method === "patch" ? { title: "越权" } : undefined);
    assert.equal(response.status, 404);
  }
  assert.equal(
    (await runtime.prisma.task.findUniqueOrThrow({ where: { id } })).title,
    "准备发布",
  );
  assert.equal((await b.get("/api/tasks")).body.items.length, 0);
  for (const input of [
    { title: " ", status: "todo" },
    { title: "x", status: "bad" },
    { title: "x", status: "todo", ownerId: registered.body.id },
  ]) {
    assert.equal(
      (await a.post("/api/tasks").set("Origin", origin).send(input)).status,
      400,
    );
  }
  assert.equal(
    (await a.patch(`/api/tasks/${id}`).set("Origin", origin).send({})).status,
    400,
  );
  assert.equal(
    (
      await a
        .patch(`/api/tasks/${id}`)
        .set("Origin", origin)
        .send({ status: "done", description: null })
    ).status,
    200,
  );
  assert.equal(
    (await a.get("/api/tasks?limit=1")).body.items[0].status,
    "done",
  );
  assert.equal((await a.get("/api/tasks?limit=NaN")).status, 400);
  assert.equal(
    (await a.post("/api/auth/logout").set("Origin", origin)).status,
    204,
  );
  assert.equal(
    (await request(runtime.app).get("/api/auth/me").set("Cookie", cookie))
      .status,
    401,
  );
  assert.equal(
    (await a.post("/api/auth/login").set("Origin", origin).send(credentials))
      .status,
    200,
  );
  assert.equal(
    (await a.delete(`/api/tasks/${id}`).set("Origin", origin)).status,
    204,
  );
  assert.equal(await runtime.prisma.task.count(), 0);
  assert.equal((await request(runtime.app).get("/readyz")).status, 200);
});
