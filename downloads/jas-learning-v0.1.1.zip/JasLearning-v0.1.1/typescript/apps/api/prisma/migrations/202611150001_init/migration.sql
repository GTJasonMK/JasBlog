CREATE TYPE "TaskStatus" AS ENUM ('todo', 'in_progress', 'done');
CREATE TABLE "User" (
  id uuid PRIMARY KEY, email varchar(254) NOT NULL UNIQUE,
  "passwordHash" text NOT NULL, "createdAt" timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE "Task" (
  id uuid PRIMARY KEY, "ownerId" uuid NOT NULL REFERENCES "User"(id) ON DELETE CASCADE,
  title varchar(120) NOT NULL CHECK (length(trim(title)) > 0), description text,
  status "TaskStatus" NOT NULL DEFAULT 'todo', "dueAt" timestamptz,
  "createdAt" timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" timestamptz NOT NULL
);
CREATE INDEX "Task_ownerId_createdAt_id_idx" ON "Task"("ownerId", "createdAt" DESC, id DESC);
CREATE TABLE "Session" (sid varchar PRIMARY KEY, sess json NOT NULL, expire timestamp(6) NOT NULL);
CREATE INDEX "Session_expire_idx" ON "Session"(expire);
