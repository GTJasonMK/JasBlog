import { randomUUID } from "node:crypto";
import express, {
  type Request,
  type Response,
  type NextFunction,
} from "express";
import session from "express-session";
import pgSession from "connect-pg-simple";
import pg from "pg";
import helmet from "helmet";
import { rateLimit } from "express-rate-limit";
import { hash, verify, argon2id } from "argon2";
import { PrismaClient, Prisma } from "./generated/prisma/client.js";
import { PrismaPg } from "@prisma/adapter-pg";
import {
  CreateTask,
  UpdateTask,
  Credentials,
  TaskPage,
  User,
  type TaskData,
} from "@learning/shared";
import { z } from "zod";
import { Registry, Histogram } from "@prometheus-io/client";

declare module "express-session" {
  interface SessionData {
    userId?: string;
    startedAt?: number;
  }
}
export interface Config {
  databaseUrl: string;
  sessionSecret: string;
  origin: string;
  production: boolean;
  trustProxy?: string;
  sessionLifetimeMs?: number;
}
const publicTask = {
  id: true,
  title: true,
  description: true,
  status: true,
  dueAt: true,
  createdAt: true,
  updatedAt: true,
} as const;
function taskResponse(
  task: Prisma.TaskGetPayload<{ select: typeof publicTask }>,
): TaskData {
  return {
    ...task,
    dueAt: task.dueAt?.toISOString() ?? null,
    createdAt: task.createdAt.toISOString(),
    updatedAt: task.updatedAt.toISOString(),
  };
}
const uuid = z.uuid();
const Query = z
  .object({
    limit: z.coerce.number().int().min(1).max(50).default(20),
    cursor: uuid.optional(),
  })
  .strict();
const EmailUniqueFailure = z.object({
  modelName: z.literal("User"),
  driverAdapterError: z.object({
    cause: z.object({
      kind: z.literal("UniqueConstraintViolation"),
      constraint: z.object({ index: z.literal("User_email_key") }),
    }),
  }),
});

export async function createApp(config: Config) {
  if (
    config.sessionSecret.length < 32 ||
    new URL(config.origin).origin !== config.origin
  )
    throw new Error("会话密钥或 APP_ORIGIN 无效");
  if (config.production && !config.origin.startsWith("https://"))
    throw new Error("生产 APP_ORIGIN 必须使用 HTTPS");
  const prisma = new PrismaClient({
    adapter: new PrismaPg({
      connectionString: config.databaseUrl,
      max: 5,
      connectionTimeoutMillis: 3000,
    }),
  });
  const pool = new pg.Pool({
    connectionString: config.databaseUrl,
    max: 5,
    connectionTimeoutMillis: 3000,
  });
  const store = new (pgSession(session))({
    pool,
    tableName: "Session",
    createTableIfMissing: false,
  });
  const close = async () => {
    store.close();
    await Promise.all([pool.end(), prisma.$disconnect()]);
  };
  try {
    await prisma.task.count();
    await pool.query('SELECT sid FROM "Session" LIMIT 1');
  } catch (error) {
    await close();
    throw error;
  }
  const app = express();
  app.disable("x-powered-by");
  if (config.trustProxy) app.set("trust proxy", config.trustProxy);
  app.use(helmet());
  app.use(express.json({ limit: "16kb" }));
  const registry = new Registry();
  const duration = new Histogram({
    name: "learning_http_seconds",
    help: "HTTP duration",
    labelNames: ["method", "route", "status"],
    registers: [registry],
  });
  app.use((request, response, next) => {
    response.locals.requestId = randomUUID();
    response.setHeader("X-Request-Id", response.locals.requestId);
    const stop = duration.startTimer();
    response.on("finish", () => {
      const route = request.route?.path ?? "unmatched";
      stop({
        method: request.method,
        route,
        status: String(response.statusCode),
      });
      console.log(
        JSON.stringify({
          requestId: response.locals.requestId,
          method: request.method,
          route,
          status: response.statusCode,
        }),
      );
    });
    next();
  });
  app.get("/healthz", (_request, response) =>
    response.json({ status: "alive" }),
  );
  app.get("/readyz", async (_request, response) => {
    try {
      await pool.query("SELECT 1");
      response.json({ status: "ready" });
    } catch {
      response
        .status(503)
        .json({ error: { code: "NOT_READY", message: "数据库不可用" } });
    }
  });
  app.get("/metrics", async (_request, response) => {
    response.type(registry.contentType).send(await registry.metrics());
  });
  app.use("/api", (request, response, next) => {
    response.setHeader("Cache-Control", "no-store");
    if (
      !["GET", "HEAD", "OPTIONS"].includes(request.method) &&
      request.get("Origin") !== config.origin
    ) {
      response.status(403).json({
        error: { code: "ORIGIN_REJECTED", message: "请求来源不匹配" },
      });
      return;
    }
    next();
  });
  const cookie = {
    httpOnly: true,
    secure: config.production,
    sameSite: "lax" as const,
    path: "/",
    maxAge: 30 * 60 * 1000,
  };
  app.use(
    session({
      name: "learning.sid",
      store,
      secret: config.sessionSecret,
      resave: false,
      saveUninitialized: false,
      rolling: true,
      cookie,
    }),
  );
  app.use(
    "/api/auth",
    rateLimit({
      windowMs: 60_000,
      limit: 20,
      standardHeaders: "draft-8",
      legacyHeaders: false,
      message: {
        error: { code: "RATE_LIMITED", message: "请求过于频繁，请稍后重试" },
      },
    }),
  );
  const login = async (request: Request, userId: string) => {
    await new Promise<void>((resolve, reject) =>
      request.session.regenerate((error) =>
        error ? reject(error) : resolve(),
      ),
    );
    request.session.userId = userId;
    request.session.startedAt = Date.now();
    await new Promise<void>((resolve, reject) =>
      request.session.save((error) => (error ? reject(error) : resolve())),
    );
  };
  app.post("/api/auth/register", async (request, response) => {
    const input = Credentials.parse(request.body);
    const passwordHash = await hash(input.password, { type: argon2id });
    const user = await prisma.user.create({
      data: { email: input.email, passwordHash },
      select: { id: true, email: true },
    });
    await login(request, user.id);
    response.status(201).json(User.parse(user));
  });
  app.post("/api/auth/login", async (request, response) => {
    const input = Credentials.parse(request.body);
    const user = await prisma.user.findUnique({
      where: { email: input.email },
    });
    if (!user || !(await verify(user.passwordHash, input.password))) {
      response
        .status(401)
        .json({ error: { code: "LOGIN_FAILED", message: "邮箱或密码错误" } });
      return;
    }
    await login(request, user.id);
    response.json(User.parse(user));
  });
  app.post("/api/auth/logout", async (request, response) => {
    await new Promise<void>((resolve, reject) =>
      request.session.destroy((error) => (error ? reject(error) : resolve())),
    );
    response.clearCookie("learning.sid", { ...cookie, maxAge: undefined });
    response.sendStatus(204);
  });
  app.use("/api", (request, response, next) => {
    if (
      !request.session.userId ||
      !request.session.startedAt ||
      Date.now() - request.session.startedAt >
        (config.sessionLifetimeMs ?? 8 * 60 * 60 * 1000)
    ) {
      response
        .status(401)
        .json({ error: { code: "UNAUTHENTICATED", message: "请重新登录" } });
      return;
    }
    next();
  });
  app.get("/api/auth/me", async (request, response) => {
    const user = await prisma.user.findUnique({
      where: { id: request.session.userId! },
      select: { id: true, email: true },
    });
    if (!user) {
      response
        .status(401)
        .json({ error: { code: "UNAUTHENTICATED", message: "用户不存在" } });
      return;
    }
    response.json(User.parse(user));
  });
  app.get("/api/tasks", async (request, response) => {
    const { limit, cursor } = Query.parse(request.query);
    const ownerId = request.session.userId!;
    const anchor = cursor
      ? await prisma.task.findFirst({ where: { id: cursor, ownerId } })
      : null;
    if (cursor && !anchor) {
      response.status(400).json({
        error: {
          code: "INVALID_CURSOR",
          message: "分页位置无效，请刷新列表",
        },
      });
      return;
    }
    const items = await prisma.task.findMany({
      where: {
        ownerId,
        ...(anchor
          ? {
              OR: [
                { createdAt: { lt: anchor.createdAt } },
                { createdAt: anchor.createdAt, id: { lt: anchor.id } },
              ],
            }
          : {}),
      },
      select: publicTask,
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: limit + 1,
    });
    const hasMore = items.length > limit;
    response.json(
      TaskPage.parse({
        items: items.slice(0, limit).map(taskResponse),
        nextCursor: hasMore ? items[limit - 1].id : null,
      }),
    );
  });
  app.post("/api/tasks", async (request, response) => {
    const input = CreateTask.parse(request.body);
    const task = await prisma.task.create({
      data: { ...input, ownerId: request.session.userId! },
      select: publicTask,
    });
    response.status(201).json(taskResponse(task));
  });
  app.get("/api/tasks/:id", async (request, response) => {
    const task = await prisma.task.findFirst({
      where: {
        id: uuid.parse(request.params.id),
        ownerId: request.session.userId!,
      },
      select: publicTask,
    });
    if (!task) {
      notFound(response);
      return;
    }
    response.json(taskResponse(task));
  });
  app.patch("/api/tasks/:id", async (request, response) => {
    const id = uuid.parse(request.params.id);
    const input = UpdateTask.parse(request.body);
    const result = await prisma.$transaction(async (transaction) => {
      const changed = await transaction.task.updateMany({
        where: { id, ownerId: request.session.userId! },
        data: input,
      });
      return changed.count
        ? transaction.task.findUniqueOrThrow({
            where: { id },
            select: publicTask,
          })
        : null;
    });
    if (!result) {
      notFound(response);
      return;
    }
    response.json(taskResponse(result));
  });
  app.delete("/api/tasks/:id", async (request, response) => {
    const result = await prisma.task.deleteMany({
      where: {
        id: uuid.parse(request.params.id),
        ownerId: request.session.userId!,
      },
    });
    if (!result.count) {
      notFound(response);
      return;
    }
    response.sendStatus(204);
  });
  app.use((_request, response) => notFound(response));
  app.use(
    (
      error: unknown,
      _request: Request,
      response: Response,
      _next: NextFunction,
    ) => {
      if (
        typeof error === "object" &&
        error !== null &&
        "type" in error &&
        error.type === "entity.too.large"
      ) {
        response.status(413).json({
          error: { code: "PAYLOAD_TOO_LARGE", message: "请求内容过大" },
        });
        return;
      }
      if (error instanceof z.ZodError || error instanceof SyntaxError) {
        response.status(400).json({
          error: {
            code: "INVALID_INPUT",
            message: "输入格式不正确，请检查字段",
          },
        });
        return;
      }
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        error.code === "P2002" &&
        EmailUniqueFailure.safeParse(error.meta).success
      ) {
        response
          .status(409)
          .json({ error: { code: "EMAIL_TAKEN", message: "该邮箱无法注册" } });
        return;
      }
      console.error(
        JSON.stringify({
          requestId: response.locals.requestId,
          errorType: error instanceof Error ? error.name : "UnknownError",
        }),
      );
      response.status(500).json({
        error: {
          code: "INTERNAL_ERROR",
          message: "服务暂时不可用",
          requestId: response.locals.requestId,
        },
      });
    },
  );
  return { app, close, prisma };
}

function notFound(response: Response) {
  response
    .status(404)
    .json({ error: { code: "TASK_NOT_FOUND", message: "任务不存在" } });
}
