import { createApp } from "./app.js";

function required(name: string) {
  const value = process.env[name];
  if (!value) throw new Error(`缺少 ${name}`);
  return value;
}
const port = Number(process.env.PORT ?? 3001);
if (!Number.isInteger(port) || port < 1 || port > 65535)
  throw new Error("PORT 无效");
const runtime = await createApp({
  databaseUrl: required("DATABASE_URL"),
  sessionSecret: required("SESSION_SECRET"),
  origin: required("APP_ORIGIN"),
  production: process.env.NODE_ENV === "production",
  trustProxy: process.env.TRUST_PROXY_CIDR,
});
const server = runtime.app.listen(port, "0.0.0.0", () =>
  console.log(`API listening ${port}`),
);
for (const signal of ["SIGINT", "SIGTERM"] as const)
  process.once(signal, () => {
    const deadline = setTimeout(() => {
      console.error("关闭超时");
      process.exitCode = 1;
      server.closeAllConnections();
    }, 25_000).unref();
    server.close(async (error) => {
      clearTimeout(deadline);
      await runtime.close();
      if (error) process.exitCode = 1;
    });
  });
