import { test } from "node:test";
import assert from "node:assert/strict";
import { dueAt, localTime } from "../src/datetime.js";

test("未改动本地时间时保留原有秒和毫秒，清除与修改分别处理", () => {
  const previous = "2026-12-01T13:24:35.123Z";
  assert.equal(dueAt(localTime(previous), previous), previous);
  assert.equal(dueAt("", previous), null);
  assert.equal(localTime(dueAt("2026-12-02T09:30")!), "2026-12-02T09:30");
});
