import { StrictMode, useEffect, useRef, useState, type FormEvent } from "react";
import { createRoot } from "react-dom/client";
import {
  ApiError,
  CreateTask,
  Task,
  TaskPage,
  User,
  type TaskData,
  type UserData,
} from "@learning/shared";
import "./style.css";
import { dueAt, localTime, displayTime } from "./datetime.js";

const labels = {
  todo: "待处理",
  in_progress: "进行中",
  done: "已完成",
} as const;
async function api(path: string, init: RequestInit = {}) {
  const response = await fetch(`/api${path}`, {
    ...init,
    headers: { "Content-Type": "application/json", ...init.headers },
    signal: AbortSignal.timeout(15_000),
  });
  if (response.status === 204) return undefined;
  const body: unknown = await response.json();
  if (!response.ok) {
    if (response.status === 401)
      window.dispatchEvent(new Event("session-expired"));
    throw new Error(ApiError.parse(body).error.message);
  }
  return body;
}
function App() {
  const [user, setUser] = useState<UserData | null>(null);
  const [starting, setStarting] = useState(true);
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [tasks, setTasks] = useState<TaskData[]>([]);
  const [loading, setLoading] = useState(false);
  const [listError, setListError] = useState("");
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [cursors, setCursors] = useState<(string | undefined)[]>([undefined]);
  const [editor, setEditor] = useState<{ task?: TaskData } | null>(null);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState<TaskData["status"]>("todo");
  const [due, setDue] = useState("");
  const dialog = useRef<HTMLDialogElement>(null);
  const sequence = useRef(0);
  const expiredUser = useRef<string | null>(null);
  useEffect(() => {
    const expire = () => {
      if (!user) return;
      expiredUser.current = user.id;
      ++sequence.current;
      setUser(null);
      setMode("login");
      setEmail(user.email);
      setLoading(false);
      setError("登录已过期，请重新登录。");
    };
    window.addEventListener("session-expired", expire);
    return () => window.removeEventListener("session-expired", expire);
  }, [user]);
  useEffect(() => {
    let active = true;
    fetch("/api/auth/me")
      .then(async (response) => {
        if (response.status === 401) return null;
        if (!response.ok) throw new Error("暂时无法读取登录状态，请刷新重试");
        return User.parse(await response.json());
      })
      .then((value) => {
        if (active) setUser(value);
      })
      .catch((cause: Error) => {
        if (active) setError(cause.message);
      })
      .finally(() => {
        if (active) setStarting(false);
      });
    return () => {
      active = false;
    };
  }, []);
  async function load(cursor = cursors.at(-1)) {
    const current = ++sequence.current;
    setLoading(true);
    setListError("");
    try {
      const page = TaskPage.parse(
        await api(
          `/tasks?limit=10${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`,
        ),
      );
      if (sequence.current === current) {
        setTasks(page.items);
        setNextCursor(page.nextCursor);
      }
    } catch (cause) {
      if (sequence.current === current) setListError((cause as Error).message);
    } finally {
      if (sequence.current === current) setLoading(false);
    }
  }
  useEffect(() => {
    if (user) void load();
  }, [user, cursors]);
  useEffect(() => {
    if (editor && user) {
      dialog.current?.showModal();
      dialog.current?.querySelector("input")?.focus();
    }
  }, [editor, user]);
  async function authenticate(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const authenticated = User.parse(
        await api(`/auth/${mode}`, {
          method: "POST",
          body: JSON.stringify({ email, password }),
        }),
      );
      if (expiredUser.current && expiredUser.current !== authenticated.id) {
        setEditor(null);
        setTitle("");
        setDescription("");
      }
      expiredUser.current = null;
      setUser(authenticated);
      setPassword("");
      setCursors([undefined]);
    } catch (cause) {
      setError((cause as Error).message);
    } finally {
      setBusy(false);
    }
  }
  function open(task?: TaskData) {
    setTitle(task?.title ?? "");
    setDescription(task?.description ?? "");
    setStatus(task?.status ?? "todo");
    setDue(localTime(task?.dueAt));
    setError("");
    setEditor({ task });
  }
  async function save(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const input = CreateTask.parse({
        title,
        description: description || null,
        status,
        dueAt: dueAt(due, editor?.task?.dueAt),
      });
      Task.parse(
        await api(editor?.task ? `/tasks/${editor.task.id}` : "/tasks", {
          method: editor?.task ? "PATCH" : "POST",
          body: JSON.stringify(input),
        }),
      );
      dialog.current?.close();
      setEditor(null);
      setCursors([undefined]);
      await load(undefined);
    } catch (cause) {
      setError((cause as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function remove(task: TaskData) {
    if (!window.confirm(`删除“${task.title}”？`)) return;
    setBusy(true);
    setError("");
    try {
      await api(`/tasks/${task.id}`, { method: "DELETE" });
      setCursors([undefined]);
      await load(undefined);
    } catch (cause) {
      setError((cause as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function logout() {
    setBusy(true);
    setError("");
    try {
      await api("/auth/logout", { method: "POST" });
      ++sequence.current;
      setTasks([]);
      setUser(null);
    } catch (cause) {
      setError((cause as Error).message);
    } finally {
      setBusy(false);
    }
  }
  if (starting)
    return (
      <main className="auth">
        <p role="status">正在读取工作清单…</p>
      </main>
    );
  if (!user)
    return (
      <main className="auth">
        <p className="brand">工作清单</p>
        <h1>{mode === "login" ? "继续你的工作。" : "开始整理下一步。"}</h1>
        <p className="muted">把待办、进度和截止日期放在一起。</p>
        <form onSubmit={authenticate}>
          <label>
            邮箱
            <input
              type="email"
              autoComplete="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              required
              maxLength={254}
            />
          </label>
          <label>
            密码
            <input
              type="password"
              autoComplete={
                mode === "login" ? "current-password" : "new-password"
              }
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              minLength={12}
              maxLength={128}
              required
              aria-describedby="password-hint"
            />
          </label>
          <p id="password-hint" className="hint">
            至少 12 个字符。
          </p>
          {error && (
            <p role="alert" className="error">
              {error}
            </p>
          )}
          <button className="primary" disabled={busy}>
            {busy ? "正在提交…" : mode === "login" ? "登录" : "创建账户"}
          </button>
        </form>
        <button
          className="text-button"
          disabled={busy}
          onClick={() => {
            setMode(mode === "login" ? "register" : "login");
            setError("");
          }}
        >
          {mode === "login" ? "还没有账户？注册" : "已有账户？登录"}
        </button>
      </main>
    );
  return (
    <>
      <header>
        <a className="brand" href="/">
          工作清单
        </a>
        <div className="account">
          <span>{user.email}</span>
          <button onClick={logout} disabled={busy}>
            退出
          </button>
        </div>
      </header>
      <main className="workspace">
        <div className="page-heading">
          <h1>我的任务</h1>
          <button className="primary" onClick={() => open()} disabled={busy}>
            新增任务
          </button>
        </div>
        {error && !editor && (
          <p role="alert" className="error">
            {error}
          </p>
        )}
        <div className="list-heading">
          <span aria-live="polite">
            {loading ? "正在更新…" : `当前页 ${tasks.length} 项`}
          </span>
        </div>
        {listError && (
          <div className="error" role="alert">
            <p>{listError}</p>
            <button onClick={() => void load()}>重试</button>
          </div>
        )}
        {!loading && !listError && tasks.length === 0 && (
          <div className="empty">
            <h2>为下一步留个位置。</h2>
            <p>用“新增任务”记下要做的事。</p>
          </div>
        )}
        <ul className="tasks" aria-label="任务列表" aria-busy={loading}>
          {tasks.map((task) => (
            <li key={task.id}>
              <div className={`status status-${task.status}`}>
                {labels[task.status]}
              </div>
              <div className="task-content">
                <h3>{task.title}</h3>
                {task.description && <p>{task.description}</p>}
                {task.dueAt && (
                  <time dateTime={task.dueAt}>
                    截止 {displayTime(task.dueAt)}
                  </time>
                )}
              </div>
              <div className="task-actions">
                <button
                  onClick={() => open(task)}
                  disabled={busy}
                  aria-label={`编辑 ${task.title}`}
                >
                  编辑
                </button>
                <button
                  className="destructive"
                  onClick={() => void remove(task)}
                  disabled={busy}
                  aria-label={`删除 ${task.title}`}
                >
                  删除
                </button>
              </div>
            </li>
          ))}
        </ul>
        <nav className="pagination" aria-label="任务分页">
          <button
            disabled={loading || cursors.length === 1}
            onClick={() => setCursors(cursors.slice(0, -1))}
          >
            上一页
          </button>
          <span>第 {cursors.length} 页</span>
          <button
            disabled={loading || !nextCursor}
            onClick={() => setCursors([...cursors, nextCursor!])}
          >
            下一页
          </button>
        </nav>
      </main>
      <dialog
        ref={dialog}
        onClose={() => setEditor(null)}
        onCancel={(event) => {
          if (busy) event.preventDefault();
        }}
        aria-labelledby="editor-title"
      >
        <form onSubmit={save}>
          <div className="dialog-heading">
            <h2 id="editor-title">{editor?.task ? "编辑任务" : "新增任务"}</h2>
            <button
              type="button"
              aria-label="关闭"
              onClick={() => dialog.current?.close()}
              disabled={busy}
            >
              关闭
            </button>
          </div>
          <label>
            标题
            <input
              autoFocus
              value={title}
              onChange={(event) => setTitle(event.target.value)}
              required
              maxLength={120}
            />
          </label>
          <label>
            描述
            <textarea
              value={description}
              onChange={(event) => setDescription(event.target.value)}
              maxLength={4000}
              rows={3}
            />
          </label>
          <div className="form-row">
            <label>
              状态
              <select
                value={status}
                onChange={(event) =>
                  setStatus(event.target.value as TaskData["status"])
                }
              >
                {Object.entries(labels).map(([value, label]) => (
                  <option key={value} value={value}>
                    {label}
                  </option>
                ))}
              </select>
            </label>
            <label>
              截止时间
              <input
                type="datetime-local"
                value={due}
                onChange={(event) => setDue(event.target.value)}
              />
            </label>
          </div>
          {error && (
            <p role="alert" className="error">
              {error}
            </p>
          )}
          <button className="primary" disabled={busy || !title.trim()}>
            {busy ? "正在保存…" : "保存任务"}
          </button>
        </form>
      </dialog>
    </>
  );
}
createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
