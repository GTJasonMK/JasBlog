export function localTime(value: string | null | undefined): string {
  if (!value) return "";
  const date = new Date(value);
  return new Date(date.getTime() - date.getTimezoneOffset() * 60_000)
    .toISOString()
    .slice(0, 16);
}

const displayFormatter = new Intl.DateTimeFormat("zh-CN", {
  dateStyle: "medium",
  timeStyle: "short",
});
export function displayTime(value: string): string {
  return displayFormatter.format(new Date(value));
}

export function dueAt(value: string, previous?: string | null): string | null {
  if (!value) return null;
  if (previous && localTime(previous) === value) return previous;
  const result = new Date(value).toISOString();
  if (localTime(result) !== value)
    throw new Error("该时区不存在这个本地时间，请重新选择");
  return result;
}
