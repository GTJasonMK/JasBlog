package main

import (
	"context"
	"errors"
	"fmt"
	"jaslearning/orders/internal/config"
	"jaslearning/orders/internal/httpapi"
	"jaslearning/orders/internal/order"
	"jaslearning/orders/internal/telemetry"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"
)

func main() {
	if err := run(); err != nil {
		log.Fatal(err)
	}
}
func run() error {
	names, err := config.LoadQueueNames()
	if err != nil {
		return err
	}
	shutdownTracing, err := telemetry.Start("learning-orders-api")
	if err != nil {
		return err
	}
	defer func() {
		ctx, done := context.WithTimeout(context.Background(), 5*time.Second)
		defer done()
		if err := shutdownTracing(ctx); err != nil {
			log.Printf("trace shutdown failed: %T", err)
		}
	}()
	if len(os.Args) > 1 && os.Args[1] == "topics" {
		settings, err := config.LoadKafka()
		if err != nil {
			return err
		}
		defer settings.Transport.CloseIdleConnections()
		ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()
		for _, topic := range []string{names.Claims, names.Events} {
			if err := order.EnsureTopic(ctx, settings.Dialer, settings.Brokers, topic); err != nil {
				return err
			}
		}
		return nil
	}
	store, err := order.Open(os.Getenv("MYSQL_DSN"))
	if err != nil {
		return err
	}
	defer store.Close()
	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()
	if len(os.Args) > 1 {
		switch os.Args[1] {
		case "migrate":
			return store.Migrate(ctx)
		case "seed":
			return store.Seed(ctx, os.Getenv("DEMO_PASSWORD"))
		default:
			return errors.New("unknown command")
		}
	}
	if err := store.DB.WithContext(ctx).Select("id", "user_id", "product_id", "product_name", "unit_price_cents", "fingerprint", "status", "created_at").Limit(1).Find(&[]order.Order{}).Error; err != nil {
		return fmt.Errorf("schema verification failed: %w", err)
	}
	cache, err := order.RedisClient(os.Getenv("REDIS_URL"))
	if err != nil {
		return err
	}
	defer cache.Close()
	if err := cache.Ping(ctx).Err(); err != nil {
		return err
	}
	settings, err := config.LoadKafka()
	if err != nil {
		return err
	}
	defer settings.Transport.CloseIdleConnections()
	writer := settings.Writer(names.Claims)
	defer writer.Close()
	queue := &order.Queue{Store: store, Redis: cache, Writer: writer, Prefix: names.Prefix}
	proxies := strings.FieldsFunc(os.Getenv("TRUSTED_PROXY_CIDRS"), func(character rune) bool { return character == ',' })
	handler, err := httpapi.Router(store, queue, httpapi.Config{JWTSecret: os.Getenv("JWT_SECRET"), MockPaymentSecret: os.Getenv("MOCK_PAYMENT_SECRET"), AllowMockPayment: os.Getenv("ALLOW_MOCK_PAYMENT") == "true", TrustedProxies: proxies})
	if err != nil {
		return err
	}
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}
	server := &http.Server{Addr: ":" + port, Handler: handler, ReadHeaderTimeout: 3 * time.Second, ReadTimeout: 10 * time.Second, WriteTimeout: 10 * time.Second, IdleTimeout: 60 * time.Second}
	failures := make(chan error, 1)
	go func() { failures <- server.ListenAndServe() }()
	select {
	case <-ctx.Done():
	case err := <-failures:
		if !errors.Is(err, http.ErrServerClosed) {
			return err
		}
	}
	shutdown, done := context.WithTimeout(context.Background(), 20*time.Second)
	defer done()
	fmt.Println("stopping HTTP before dependencies")
	return server.Shutdown(shutdown)
}
