package main

import (
	"context"
	"jaslearning/orders/internal/config"
	"jaslearning/orders/internal/order"
	"jaslearning/orders/internal/telemetry"
	"log"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"
)

func main() {
	if err := run(); err != nil {
		log.Fatal(err)
	}
}
func run() error {
	names, err := config.LoadQueueNames()
	if err != nil {
		return err
	}
	shutdownTracing, err := telemetry.Start("learning-orders-worker")
	if err != nil {
		return err
	}
	defer func() {
		ctx, done := context.WithTimeout(context.Background(), 5*time.Second)
		defer done()
		if err := shutdownTracing(ctx); err != nil {
			log.Printf("trace shutdown failed: %T", err)
		}
	}()
	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()
	store, err := order.Open(os.Getenv("MYSQL_DSN"))
	if err != nil {
		return err
	}
	defer store.Close()
	cache, err := order.RedisClient(os.Getenv("REDIS_URL"))
	if err != nil {
		return err
	}
	defer cache.Close()
	settings, err := config.LoadKafka()
	if err != nil {
		return err
	}
	defer settings.Transport.CloseIdleConnections()
	writer := settings.Writer(names.Claims)
	defer writer.Close()
	events := settings.Writer(names.Events)
	defer events.Close()
	reader := settings.Reader(names.Claims, names.Group)
	defer func() {
		if err := reader.Close(); err != nil {
			log.Printf("reader close failed: %T", err)
		}
	}()
	queue := &order.Queue{Store: store, Redis: cache, Writer: writer, Prefix: names.Prefix}
	var workers sync.WaitGroup
	workers.Add(1)
	go func() {
		defer workers.Done()
		for ctx.Err() == nil {
			var campaigns []order.Campaign
			if err := store.DB.WithContext(ctx).Find(&campaigns).Error; err != nil {
				log.Printf("relay database error: %T", err)
			} else {
				for _, campaign := range campaigns {
					if err := queue.Relay(ctx, campaign.ID, nil); err != nil && ctx.Err() == nil {
						log.Printf("relay error: %T", err)
					}
				}
			}
			if err := queue.PublishOutbox(ctx, events); err != nil && ctx.Err() == nil {
				log.Printf("outbox error: %T", err)
			}
			select {
			case <-ctx.Done():
				return
			case <-time.After(time.Second):
			}
		}
	}()
	for ctx.Err() == nil {
		if err := queue.Consume(ctx, reader); err != nil && ctx.Err() == nil {
			log.Printf("consumer error, retained for retry: %T", err)
			// FetchMessage 已推进本地位置，重建 reader 从最后提交位置重放。
			if closeErr := reader.Close(); closeErr != nil {
				cancel()
				workers.Wait()
				return closeErr
			}
			reader = settings.Reader(names.Claims, names.Group)
			select {
			case <-ctx.Done():
			case <-time.After(time.Second):
			}
		}
	}
	workers.Wait()
	return nil
}
