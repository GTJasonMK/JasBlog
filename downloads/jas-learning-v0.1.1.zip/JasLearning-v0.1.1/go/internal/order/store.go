package order

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	_ "embed"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/codes"
	"strings"
	"time"
	"unicode"

	"golang.org/x/crypto/bcrypt"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
	"gorm.io/gorm/logger"
)

//go:embed schema.sql
var schema string
var ErrInput = errors.New("invalid input")
var ErrConflict = errors.New("request conflict")
var ErrSoldOut = errors.New("sold out")
var ErrNotFound = errors.New("not found")

type Store struct{ DB *gorm.DB }
type User struct {
	ID           int64
	Email        string
	PasswordHash string
}
type Product struct {
	ID         int64  `json:"id"`
	Name       string `json:"name"`
	PriceCents int64  `json:"price_cents"`
	Stock      int    `json:"stock"`
}
type Campaign struct {
	ID        int64     `json:"id"`
	ProductID int64     `json:"product_id"`
	StartsAt  time.Time `json:"starts_at"`
	EndsAt    time.Time `json:"ends_at"`
}
type Input struct {
	ProductID  int64  `json:"product_id"`
	Quantity   int    `json:"quantity"`
	CampaignID *int64 `json:"campaign_id,omitempty"`
}
type Order struct {
	ID             string    `json:"id"`
	UserID         int64     `json:"-"`
	ProductID      int64     `json:"product_id"`
	CampaignID     *int64    `json:"campaign_id,omitempty"`
	RequestKey     string    `json:"-"`
	Fingerprint    string    `json:"-"`
	Quantity       int       `json:"quantity"`
	ProductName    string    `json:"product_name"`
	UnitPriceCents int64     `json:"unit_price_cents"`
	TotalCents     int64     `json:"total_cents"`
	Status         string    `json:"status"`
	CreatedAt      time.Time `json:"created_at"`
}
type Event struct {
	ID          string    `json:"id"`
	UserID      int64     `json:"user_id"`
	Key         string    `json:"key"`
	Input       Input     `json:"input"`
	AcceptedAt  time.Time `json:"accepted_at"`
	TraceParent string    `json:"traceparent,omitempty"`
}
type Outbox struct {
	ID          string
	OrderID     string
	EventType   string
	Payload     string
	PublishedAt *time.Time
	LeaseUntil  *time.Time
	Attempts    int
}

func (Outbox) TableName() string { return "outbox" }

func Open(dsn string) (*Store, error) {
	if dsn == "" {
		return nil, errors.New("MYSQL_DSN required")
	}
	db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{Logger: logger.Default.LogMode(logger.Silent)})
	if err != nil {
		return nil, err
	}
	pool, err := db.DB()
	if err != nil {
		return nil, err
	}
	pool.SetMaxOpenConns(10)
	pool.SetMaxIdleConns(5)
	pool.SetConnMaxLifetime(5 * time.Minute)
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	if err := pool.PingContext(ctx); err != nil {
		_ = pool.Close()
		return nil, err
	}
	return &Store{db}, nil
}
func (s *Store) Close() error {
	pool, err := s.DB.DB()
	if err != nil {
		return err
	}
	return pool.Close()
}
func (s *Store) Migrate(ctx context.Context) error { return s.DB.WithContext(ctx).Exec(schema).Error }
func (s *Store) Seed(ctx context.Context, password string) error {
	if len(password) < 12 || len(password) > 72 {
		return ErrInput
	}
	digest, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return err
	}
	return s.DB.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		for _, email := range []string{"a@example.invalid", "b@example.invalid"} {
			if err := tx.Clauses(clause.OnConflict{DoNothing: true}).Create(&User{Email: email, PasswordHash: string(digest)}).Error; err != nil {
				return err
			}
		}
		if err := tx.Clauses(clause.OnConflict{DoNothing: true}).Create(&Product{ID: 1, Name: "学习商品", PriceCents: 1990, Stock: 100}).Error; err != nil {
			return err
		}
		return tx.Clauses(clause.OnConflict{DoNothing: true}).Create(&Campaign{ID: 1, ProductID: 1, StartsAt: time.Date(2020, 1, 1, 0, 0, 0, 0, time.UTC), EndsAt: time.Date(2035, 1, 1, 0, 0, 0, 0, time.UTC)}).Error
	})
}
func (input Input) Validate(key string) error {
	if input.ProductID <= 0 || input.Quantity < 1 || input.Quantity > 1000 || len(key) < 1 || len(key) > 128 || strings.TrimSpace(key) != key {
		return ErrInput
	}
	if strings.IndexFunc(key, func(character rune) bool {
		return character > unicode.MaxASCII || !(character >= 'a' && character <= 'z' || character >= 'A' && character <= 'Z' || character >= '0' && character <= '9' || character == '-' || character == '_')
	}) >= 0 {
		return ErrInput
	}
	if input.CampaignID != nil && *input.CampaignID <= 0 {
		return ErrInput
	}
	return nil
}
func (input Input) Fingerprint() string {
	body, _ := json.Marshal(input)
	sum := sha256.Sum256(body)
	return hex.EncodeToString(sum[:])
}

func (s *Store) Create(ctx context.Context, userID int64, key string, input Input) (Order, error) {
	ctx, span := otel.Tracer("learning-orders").Start(ctx, "order.create")
	defer span.End()
	var result Order
	if userID <= 0 {
		return result, ErrInput
	}
	if err := input.Validate(key); err != nil {
		return result, err
	}
	err := s.DB.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		// shortcut: 同一用户写入串行，实测成为瓶颈后再改为细粒度请求锁。
		var user User
		if err := tx.Clauses(clause.Locking{Strength: "UPDATE"}).First(&user, userID).Error; err != nil {
			return err
		}
		existing := tx.Where("user_id=? AND request_key=?", userID, key).First(&result)
		if existing.Error == nil {
			if result.Fingerprint != input.Fingerprint() {
				return ErrConflict
			}
			return nil
		}
		if !errors.Is(existing.Error, gorm.ErrRecordNotFound) {
			return existing.Error
		}
		if input.CampaignID != nil {
			var count int64
			if err := tx.Model(&Order{}).Where("user_id=? AND campaign_id=?", userID, *input.CampaignID).Count(&count).Error; err != nil {
				return err
			}
			if count > 0 {
				return ErrConflict
			}
		}
		var product Product
		if err := tx.First(&product, input.ProductID).Error; err != nil {
			if errors.Is(err, gorm.ErrRecordNotFound) {
				return ErrNotFound
			}
			return err
		}
		changed := tx.Model(&Product{}).Where("id=? AND stock>=?", input.ProductID, input.Quantity).Update("stock", gorm.Expr("stock-?", input.Quantity))
		if changed.Error != nil {
			return changed.Error
		}
		if changed.RowsAffected != 1 {
			return ErrSoldOut
		}
		result = Order{ID: rand.Text(), UserID: userID, ProductID: input.ProductID, CampaignID: input.CampaignID, RequestKey: key, Fingerprint: input.Fingerprint(), Quantity: input.Quantity, ProductName: product.Name, UnitPriceCents: product.PriceCents, TotalCents: product.PriceCents * int64(input.Quantity), Status: "pending_payment", CreatedAt: time.Now().UTC()}
		if err := tx.Create(&result).Error; err != nil {
			return err
		}
		if err := tx.Exec("INSERT INTO stock_movements(order_id,product_id,delta) VALUES(?,?,?)", result.ID, input.ProductID, -input.Quantity).Error; err != nil {
			return err
		}
		payload, err := json.Marshal(map[string]string{"order_id": result.ID})
		if err != nil {
			return err
		}
		return tx.Create(&Outbox{ID: rand.Text(), OrderID: result.ID, EventType: "order.created", Payload: string(payload)}).Error
	})
	if err != nil {
		span.SetStatus(codes.Error, "order transaction failed")
	}
	return result, err
}
func (s *Store) Find(ctx context.Context, userID int64, id string) (Order, error) {
	var result Order
	err := s.DB.WithContext(ctx).Where("id=? AND user_id=?", id, userID).First(&result).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		err = ErrNotFound
	}
	return result, err
}
func (s *Store) Pay(ctx context.Context, id, reference string, amount int64) error {
	if len(reference) < 1 || len(reference) > 128 || len(id) > 64 || amount <= 0 {
		return ErrInput
	}
	return s.DB.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		var order Order
		if err := tx.Clauses(clause.Locking{Strength: "UPDATE"}).First(&order, "id=?", id).Error; err != nil {
			return err
		}
		var previous struct {
			OrderID     string
			AmountCents int64
		}
		found := tx.Table("payments").Where("provider_ref=?", reference).Take(&previous)
		if found.Error == nil {
			if previous.OrderID != id || previous.AmountCents != amount {
				return ErrConflict
			}
			return nil
		}
		if !errors.Is(found.Error, gorm.ErrRecordNotFound) {
			return found.Error
		}
		if order.Status != "pending_payment" || order.TotalCents != amount {
			return ErrConflict
		}
		if err := tx.Exec("INSERT INTO payments(provider_ref,order_id,amount_cents) VALUES(?,?,?)", reference, id, amount).Error; err != nil {
			return err
		}
		if err := tx.Model(&Order{}).Where("id=? AND status='pending_payment'", id).Update("status", "paid").Error; err != nil {
			return err
		}
		payload, _ := json.Marshal(map[string]string{"order_id": id})
		return tx.Create(&Outbox{ID: rand.Text(), OrderID: id, EventType: "order.paid", Payload: string(payload)}).Error
	})
}
func (s *Store) DeadLetter(ctx context.Context, id, reason string, payload []byte) error {
	if !json.Valid(payload) {
		value, err := json.Marshal(map[string]string{"invalid_payload_sha256": fmt.Sprintf("%x", sha256.Sum256(payload))})
		if err != nil {
			return err
		}
		payload = value
	}
	return s.DB.WithContext(ctx).Exec("INSERT INTO dead_letters(event_id,reason,payload,created_at) VALUES(?,?,?,UTC_TIMESTAMP(6)) ON DUPLICATE KEY UPDATE event_id=event_id", id, reason, string(payload)).Error
}
