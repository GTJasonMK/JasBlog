package order

import (
	"context"
	"crypto/rand"
	"encoding/json"
	"errors"
	mysqlDriver "github.com/go-sql-driver/mysql"
	"github.com/redis/go-redis/v9"
	"github.com/segmentio/kafka-go"
	"os"
	"strings"
	"sync"
	"testing"
	"time"
)

func TestInput(t *testing.T) {
	for _, input := range []Input{{ProductID: 0, Quantity: 1}, {ProductID: 1, Quantity: 0}, {ProductID: 1, Quantity: 1001}} {
		if input.Validate("key") == nil {
			t.Fatal(input)
		}
	}
	input := Input{ProductID: 1, Quantity: 2}
	if input.Validate("key") != nil {
		t.Fatal("valid rejected")
	}
	if input.Fingerprint() == (Input{ProductID: 1, Quantity: 3}).Fingerprint() {
		t.Fatal("fingerprint collision")
	}
}
func TestIntegration(t *testing.T) {
	if os.Getenv("LEARNING_INTEGRATION") != "1" {
		t.Skip("显式运行 LEARNING_INTEGRATION=1 go test -timeout 60s ./...")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 50*time.Second)
	defer cancel()
	configuration, err := mysqlDriver.ParseDSN(os.Getenv("MYSQL_DSN"))
	if err != nil {
		t.Fatal(err)
	}
	configuration.DBName = ""
	admin, err := Open(configuration.FormatDSN())
	if err != nil {
		t.Fatal(err)
	}
	name := "learning_go_test_" + strings.ToLower(rand.Text())
	if err = admin.DB.Exec("CREATE DATABASE `" + name + "`").Error; err != nil {
		t.Fatal(err)
	}
	if err = admin.Close(); err != nil {
		t.Fatal(err)
	}
	configuration.DBName = name
	store, err := Open(configuration.FormatDSN())
	if err != nil {
		t.Fatal(err)
	}
	defer store.Close()
	if err = store.Migrate(ctx); err != nil {
		t.Fatal(err)
	}
	var foreignKeys int64
	if err = store.DB.Raw("SELECT count(*) FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA=DATABASE() AND REFERENCED_TABLE_NAME IS NOT NULL").Scan(&foreignKeys).Error; err != nil || foreignKeys < 8 {
		t.Fatalf("foreign keys=%d error=%v", foreignKeys, err)
	}
	suffix := strings.ToLower(rand.Text())
	user := User{Email: suffix + "@example.invalid", PasswordHash: "not-for-login"}
	if err = store.DB.Create(&user).Error; err != nil {
		t.Fatal(err)
	}
	secondUser := User{Email: "second-" + suffix + "@example.invalid", PasswordHash: "not-for-login"}
	if err = store.DB.Create(&secondUser).Error; err != nil {
		t.Fatal(err)
	}
	product := Product{Name: suffix, PriceCents: 1990, Stock: 1}
	if err = store.DB.Create(&product).Error; err != nil {
		t.Fatal(err)
	}
	input := Input{ProductID: product.ID, Quantity: 1}
	start := make(chan struct{})
	results := make(chan error, 2)
	var wg sync.WaitGroup
	for index, userID := range []int64{user.ID, secondUser.ID} {
		wg.Add(1)
		go func(userID int64, key string) {
			defer wg.Done()
			<-start
			_, err := store.Create(ctx, userID, key, input)
			results <- err
		}(userID, []string{"race-a", "race-b"}[index])
	}
	close(start)
	wg.Wait()
	close(results)
	success, soldOut := 0, 0
	for err := range results {
		if err == nil {
			success++
		} else if errors.Is(err, ErrSoldOut) {
			soldOut++
		} else {
			t.Fatal(err)
		}
	}
	if success != 1 || soldOut != 1 {
		t.Fatalf("success=%d soldout=%d", success, soldOut)
	}
	var created Order
	if err = store.DB.Where("product_id=?", product.ID).First(&created).Error; err != nil {
		t.Fatal(err)
	}
	replay, err := store.Create(ctx, created.UserID, created.RequestKey, input)
	if err != nil || replay.ID != created.ID {
		t.Fatalf("replay %v", err)
	}
	if _, err = store.Create(ctx, created.UserID, created.RequestKey, Input{ProductID: product.ID, Quantity: 2}); !errors.Is(err, ErrConflict) {
		t.Fatal(err)
	}
	if err = store.Pay(ctx, created.ID, "payment-"+suffix, created.TotalCents); err != nil {
		t.Fatal(err)
	}
	if err = store.Pay(ctx, created.ID, "payment-"+suffix, created.TotalCents); err != nil {
		t.Fatal(err)
	}
	if err = store.Pay(ctx, created.ID, "payment-"+suffix, created.TotalCents+1); !errors.Is(err, ErrConflict) {
		t.Fatal(err)
	}
	other := user.ID
	if created.UserID == user.ID {
		other = secondUser.ID
	}
	if _, err = store.Find(ctx, other, created.ID); !errors.Is(err, ErrNotFound) {
		t.Fatal(err)
	}
	var count int64
	store.DB.Table("stock_movements").Where("order_id=?", created.ID).Count(&count)
	if count != 1 {
		t.Fatal("duplicate debit")
	}
	t.Run("rollback after inventory and order writes", func(t *testing.T) {
		rollbackProduct := Product{Name: "rollback-" + suffix, PriceCents: 100, Stock: 1}
		if err = store.DB.Create(&rollbackProduct).Error; err != nil {
			t.Fatal(err)
		}
		if err = store.DB.Exec("CREATE TRIGGER reject_outbox BEFORE INSERT ON outbox FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='injected failure'").Error; err != nil {
			t.Fatal(err)
		}
		defer func() {
			if err := store.DB.Exec("DROP TRIGGER reject_outbox").Error; err != nil {
				t.Error(err)
			}
		}()
		if _, err = store.Create(ctx, user.ID, "rollback", Input{ProductID: rollbackProduct.ID, Quantity: 1}); err == nil {
			t.Fatal("failure injection not reached")
		}
		if err = store.DB.First(&rollbackProduct, rollbackProduct.ID).Error; err != nil || rollbackProduct.Stock != 1 {
			t.Fatal("inventory not rolled back", err)
		}
		store.DB.Model(&Order{}).Where("product_id=?", rollbackProduct.ID).Count(&count)
		if count != 0 {
			t.Fatal("partial order")
		}
	})
	t.Run("Redis reservation, Kafka redelivery and compensation", func(t *testing.T) {
		cache, err := RedisClient(os.Getenv("REDIS_URL"))
		if err != nil {
			t.Fatal(err)
		}
		defer cache.Close()
		topic := "learning-test-" + suffix
		if err = EnsureTopic(ctx, &kafka.Dialer{Timeout: 5 * time.Second}, strings.Split(os.Getenv("KAFKA_BROKERS"), ","), topic); err != nil {
			t.Fatal(err)
		}
		writer := &kafka.Writer{Addr: kafka.TCP(strings.Split(os.Getenv("KAFKA_BROKERS"), ",")...), Topic: topic, RequiredAcks: kafka.RequireAll, AllowAutoTopicCreation: true}
		defer writer.Close()
		queue := &Queue{Store: store, Redis: cache, Writer: writer, Prefix: "test-" + suffix}
		stock := Product{Name: "async-" + suffix, PriceCents: 100, Stock: 1}
		if err = store.DB.Create(&stock).Error; err != nil {
			t.Fatal(err)
		}
		campaign := Campaign{ProductID: stock.ID, StartsAt: time.Now().UTC().Add(-time.Hour), EndsAt: time.Now().UTC().Add(time.Hour)}
		if err = store.DB.Create(&campaign).Error; err != nil {
			t.Fatal(err)
		}
		request := Input{ProductID: stock.ID, Quantity: 1}
		id, err := queue.Claim(ctx, user.ID, campaign.ID, "async-key", request)
		if err != nil {
			t.Fatal(err)
		}
		same, err := queue.Claim(ctx, user.ID, campaign.ID, "async-key", request)
		if err != nil || same != id {
			t.Fatal(err)
		}
		if _, err = queue.Claim(ctx, user.ID, campaign.ID, "other-key", request); !errors.Is(err, ErrSoldOut) {
			t.Fatal(err)
		}
		if err = queue.Relay(ctx, campaign.ID, func() error { return errors.New("simulated crash after broker ack") }); err == nil {
			t.Fatal("crash injection did not run")
		}
		_, _, stream := queue.keys(campaign.ID, user.ID, "")
		pending, err := cache.XPendingExt(ctx, &redis.XPendingExtArgs{Stream: stream, Group: "relay", Start: "-", End: "+", Count: 10}).Result()
		if err != nil || len(pending) != 1 {
			t.Fatalf("pending %v %v", pending, err)
		}
		if err = cache.Do(ctx, "XCLAIM", stream, "relay", "crashed", 0, pending[0].ID, "IDLE", 31000).Err(); err != nil {
			t.Fatal(err)
		}
		if err = queue.Relay(ctx, campaign.ID, nil); err != nil {
			t.Fatal(err)
		}
		reader := kafka.NewReader(kafka.ReaderConfig{Brokers: strings.Split(os.Getenv("KAFKA_BROKERS"), ","), Topic: topic, Partition: 0, MinBytes: 1, MaxBytes: 1 << 20})
		defer reader.Close()
		message, err := reader.ReadMessage(ctx)
		if err != nil {
			t.Fatal(err)
		}
		var event Event
		if err = json.Unmarshal(message.Value, &event); err != nil {
			t.Fatal(err)
		}
		if err = queue.Complete(ctx, event); err != nil {
			t.Fatal(err)
		}
		duplicate, err := reader.ReadMessage(ctx)
		if err != nil {
			t.Fatal(err)
		}
		var repeated Event
		if err = json.Unmarshal(duplicate.Value, &repeated); err != nil || repeated.ID != event.ID {
			t.Fatal("event identity changed", err)
		}
		if err = queue.Complete(ctx, repeated); err != nil {
			t.Fatal(err)
		}
		state, err := queue.Status(ctx, user.ID, campaign.ID, "async-key")
		if err != nil || state["status"] != "done" {
			t.Fatalf("%v %v", state, err)
		}
		store.DB.Model(&Order{}).Where("user_id=? AND campaign_id=?", user.ID, campaign.ID).Count(&count)
		if count != 1 {
			t.Fatal("duplicate async order")
		}
		failedUser := User{Email: "failed-" + suffix + "@example.invalid", PasswordHash: "not-for-login"}
		if err = store.DB.Create(&failedUser).Error; err != nil {
			t.Fatal(err)
		}
		stockKey, _, _ := queue.keys(campaign.ID, user.ID, "")
		if err = cache.Set(ctx, stockKey, 1, 0).Err(); err != nil {
			t.Fatal(err)
		}
		if _, err = queue.Claim(ctx, failedUser.ID, campaign.ID, "fails", request); err != nil {
			t.Fatal(err)
		}
		_, record, _ := queue.keys(campaign.ID, failedUser.ID, "fails")
		payload, err := cache.HGet(ctx, record, "event").Result()
		if err != nil {
			t.Fatal(err)
		}
		if err = json.Unmarshal([]byte(payload), &event); err != nil {
			t.Fatal(err)
		}
		for range 2 {
			if err = queue.Complete(ctx, event); err != nil {
				t.Fatal(err)
			}
		}
		remaining, err := cache.Get(ctx, stockKey).Int()
		if err != nil || remaining != 1 {
			t.Fatalf("compensated twice %d %v", remaining, err)
		}
	})
}
func BenchmarkFingerprint(b *testing.B) {
	input := Input{ProductID: 1, Quantity: 1}
	for b.Loop() {
		_ = input.Fingerprint()
	}
}
