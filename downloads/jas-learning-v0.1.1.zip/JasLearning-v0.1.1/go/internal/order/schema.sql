CREATE TABLE IF NOT EXISTS users (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, email VARCHAR(254) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL
);
CREATE TABLE IF NOT EXISTS products (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(120) NOT NULL,
 price_cents BIGINT NOT NULL CHECK(price_cents BETWEEN 1 AND 100000000), stock INT NOT NULL CHECK(stock >= 0)
);
CREATE TABLE IF NOT EXISTS campaigns (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, product_id BIGINT NOT NULL,
 starts_at DATETIME(6) NOT NULL, ends_at DATETIME(6) NOT NULL, CHECK(starts_at < ends_at),
 CONSTRAINT campaigns_product_fk FOREIGN KEY(product_id) REFERENCES products(id)
);
CREATE TABLE IF NOT EXISTS orders (
 id VARCHAR(64) PRIMARY KEY, user_id BIGINT NOT NULL,
 product_id BIGINT NOT NULL, campaign_id BIGINT NULL,
 product_name VARCHAR(120) NOT NULL, unit_price_cents BIGINT NOT NULL CHECK(unit_price_cents BETWEEN 1 AND 100000000),
 request_key VARCHAR(128) NOT NULL, fingerprint CHAR(64) NOT NULL,
 quantity INT NOT NULL CHECK(quantity BETWEEN 1 AND 1000), total_cents BIGINT NOT NULL CHECK(total_cents > 0),
 status VARCHAR(32) NOT NULL CHECK(status IN ('pending_payment','paid','cancelled')),
 created_at DATETIME(6) NOT NULL,
 UNIQUE KEY orders_user_key(user_id,request_key), UNIQUE KEY orders_campaign_user(campaign_id,user_id),
 CONSTRAINT orders_user_fk FOREIGN KEY(user_id) REFERENCES users(id),
 CONSTRAINT orders_product_fk FOREIGN KEY(product_id) REFERENCES products(id),
 CONSTRAINT orders_campaign_fk FOREIGN KEY(campaign_id) REFERENCES campaigns(id)
);
CREATE TABLE IF NOT EXISTS stock_movements (
 order_id VARCHAR(64) PRIMARY KEY, product_id BIGINT NOT NULL,
 delta INT NOT NULL, CHECK(delta < 0),
 CONSTRAINT movements_order_fk FOREIGN KEY(order_id) REFERENCES orders(id),
 CONSTRAINT movements_product_fk FOREIGN KEY(product_id) REFERENCES products(id)
);
CREATE TABLE IF NOT EXISTS outbox (
 id VARCHAR(64) PRIMARY KEY, order_id VARCHAR(64) NOT NULL,
 event_type VARCHAR(64) NOT NULL, payload JSON NOT NULL,
 published_at DATETIME(6), lease_until DATETIME(6), attempts INT NOT NULL DEFAULT 0,
 UNIQUE KEY outbox_order_event(order_id,event_type),
 CONSTRAINT outbox_order_fk FOREIGN KEY(order_id) REFERENCES orders(id)
);
CREATE TABLE IF NOT EXISTS payments (
 provider_ref VARCHAR(128) PRIMARY KEY, order_id VARCHAR(64) NOT NULL UNIQUE, amount_cents BIGINT NOT NULL,
 CONSTRAINT payments_order_fk FOREIGN KEY(order_id) REFERENCES orders(id)
);
CREATE TABLE IF NOT EXISTS dead_letters (
 event_id VARCHAR(128) PRIMARY KEY, reason VARCHAR(64) NOT NULL, payload JSON NOT NULL, created_at DATETIME(6) NOT NULL
);
