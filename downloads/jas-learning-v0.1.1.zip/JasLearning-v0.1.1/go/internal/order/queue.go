package order

import (
	"context"
	"crypto/rand"
	"encoding/json"
	"errors"
	"fmt"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/propagation"
	"strconv"
	"strings"
	"time"

	"github.com/redis/go-redis/v9"
	"github.com/segmentio/kafka-go"
)

const reserve = `
local stockType=redis.call('TYPE',KEYS[1]).ok
local requestType=redis.call('TYPE',KEYS[2]).ok
local streamType=redis.call('TYPE',KEYS[3]).ok
if stockType ~= 'string' or (requestType ~= 'none' and requestType ~= 'hash') or (streamType ~= 'none' and streamType ~= 'stream') then return redis.error_reply('INVALID_KEY_TYPES') end
if redis.call('EXISTS', KEYS[2]) == 1 then
 if redis.call('HGET', KEYS[2], 'fingerprint') ~= ARGV[1] then return redis.error_reply('REQUEST_CONFLICT') end
 return redis.call('HGET', KEYS[2], 'id')
end
local stock = tonumber(redis.call('GET', KEYS[1]))
if not stock then return redis.error_reply('STOCK_NOT_INITIALIZED') end
-- shortcut: 每活动保留上限一万条，持续运行前按终态与审计窗口设计归档。
if streamType == 'stream' and redis.call('XLEN',KEYS[3]) >= 10000 then return redis.error_reply('QUEUE_FULL') end
if stock < tonumber(ARGV[2]) then return redis.error_reply('SOLD_OUT') end
redis.call('DECRBY', KEYS[1], ARGV[2])
redis.call('HSET', KEYS[2], 'id', ARGV[3], 'fingerprint', ARGV[1], 'status', 'pending', 'event', ARGV[4], 'quantity', ARGV[2])
redis.call('XADD', KEYS[3], '*', 'event', ARGV[4], 'request_key', KEYS[2])
return ARGV[3]
`
const finish = `
local status = redis.call('HGET', KEYS[2], 'status')
if not status then return redis.error_reply('REQUEST_MISSING') end
if status == 'done' or status == 'failed' then return status end
if ARGV[1] == 'failed' then redis.call('INCRBY', KEYS[1], redis.call('HGET', KEYS[2], 'quantity')) end
redis.call('HSET', KEYS[2], 'status', ARGV[1], 'order_id', ARGV[2])
return ARGV[1]
`

type Queue struct {
	Store  *Store
	Redis  *redis.Client
	Writer *kafka.Writer
	Prefix string
}

func RedisClient(url string) (*redis.Client, error) {
	options, err := redis.ParseURL(url)
	if err != nil {
		return nil, err
	}
	return redis.NewClient(options), nil
}
func EnsureTopic(ctx context.Context, dialer *kafka.Dialer, brokers []string, topic string) error {
	connection, err := dialer.DialContext(ctx, "tcp", brokers[0])
	if err != nil {
		return err
	}
	defer connection.Close()
	controller, err := connection.Controller()
	if err != nil {
		return err
	}
	leader, err := dialer.DialContext(ctx, "tcp", fmt.Sprintf("%s:%d", controller.Host, controller.Port))
	if err != nil {
		return err
	}
	defer leader.Close()
	if err = leader.CreateTopics(kafka.TopicConfig{Topic: topic, NumPartitions: 1, ReplicationFactor: 1}); err != nil {
		return err
	}
	deadline := time.NewTimer(5 * time.Second)
	defer deadline.Stop()
	for {
		partitions, err := connection.ReadPartitions(topic)
		if err == nil && len(partitions) > 0 {
			return nil
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-deadline.C:
			return errors.New("topic readiness timeout")
		case <-time.After(100 * time.Millisecond):
		}
	}
}
func (q *Queue) keys(campaign, user int64, key string) (string, string, string) {
	tag := fmt.Sprintf("%s{%d}", q.Prefix, campaign)
	return tag + ":stock", fmt.Sprintf("%s:request:%d:%s", tag, user, key), tag + ":events"
}
func (q *Queue) Claim(ctx context.Context, userID, campaignID int64, key string, input Input) (string, error) {
	input.CampaignID = &campaignID
	if err := input.Validate(key); err != nil {
		return "", err
	}
	var campaign Campaign
	if err := q.Store.DB.WithContext(ctx).First(&campaign, campaignID).Error; err != nil {
		return "", err
	}
	now := time.Now().UTC()
	if now.Before(campaign.StartsAt) || !now.Before(campaign.EndsAt) || input.ProductID != campaign.ProductID {
		return "", ErrInput
	}
	stock, record, stream := q.keys(campaignID, userID, key)
	var product Product
	if err := q.Store.DB.WithContext(ctx).First(&product, campaign.ProductID).Error; err != nil {
		return "", err
	}
	if err := q.Redis.SetNX(ctx, stock, product.Stock, 0).Err(); err != nil {
		return "", err
	}
	carrier := propagation.MapCarrier{}
	otel.GetTextMapPropagator().Inject(ctx, carrier)
	event := Event{ID: rand.Text(), UserID: userID, Key: key, Input: input, AcceptedAt: now, TraceParent: carrier.Get("traceparent")}
	payload, err := json.Marshal(event)
	if err != nil {
		return "", err
	}
	id, err := q.Redis.Eval(ctx, reserve, []string{stock, record, stream}, input.Fingerprint(), input.Quantity, event.ID, string(payload)).Text()
	if err != nil {
		if strings.Contains(err.Error(), "SOLD_OUT") {
			return "", ErrSoldOut
		}
		if strings.Contains(err.Error(), "REQUEST_CONFLICT") {
			return "", ErrConflict
		}
	}
	return id, err
}
func (q *Queue) Status(ctx context.Context, userID, campaignID int64, key string) (map[string]string, error) {
	_, record, _ := q.keys(campaignID, userID, key)
	values, err := q.Redis.HGetAll(ctx, record).Result()
	if err != nil {
		return nil, err
	}
	if len(values) == 0 {
		return nil, ErrNotFound
	}
	delete(values, "event")
	delete(values, "fingerprint")
	return values, nil
}
func (q *Queue) Complete(ctx context.Context, event Event) error {
	ctx = otel.GetTextMapPropagator().Extract(ctx, propagation.MapCarrier{"traceparent": event.TraceParent})
	ctx, span := otel.Tracer("learning-orders").Start(ctx, "order.consume")
	defer span.End()
	if event.Input.CampaignID == nil {
		return ErrInput
	}
	if err := event.Input.Validate(event.Key); err != nil {
		return err
	}
	stock, record, _ := q.keys(*event.Input.CampaignID, event.UserID, event.Key)
	saved, err := q.Redis.HGetAll(ctx, record).Result()
	if err != nil {
		return err
	}
	if saved["id"] != event.ID || saved["fingerprint"] != event.Input.Fingerprint() {
		return ErrConflict
	}
	if saved["status"] == "failed" || saved["status"] == "done" || saved["status"] == "needs_review" {
		return nil
	}
	result, err := q.Store.Create(ctx, event.UserID, event.Key, event.Input)
	state := "done"
	if err != nil {
		if !errors.Is(err, ErrSoldOut) && !errors.Is(err, ErrConflict) && !errors.Is(err, ErrInput) && !errors.Is(err, ErrNotFound) {
			return err
		}
		state = "failed"
	}
	return q.Redis.Eval(ctx, finish, []string{stock, record}, state, result.ID).Err()
}
func (q *Queue) Relay(ctx context.Context, campaignID int64, afterPublish func() error) error {
	_, _, stream := q.keys(campaignID, 0, "")
	if err := q.Redis.XGroupCreateMkStream(ctx, stream, "relay", "0").Err(); err != nil && !strings.Contains(err.Error(), "BUSYGROUP") {
		return err
	}
	messages, _, err := q.Redis.XAutoClaim(ctx, &redis.XAutoClaimArgs{Stream: stream, Group: "relay", Consumer: "relay-" + q.Prefix, MinIdle: 30 * time.Second, Start: "0-0", Count: 10}).Result()
	if err != nil {
		return err
	}
	if len(messages) == 0 {
		groups, readErr := q.Redis.XReadGroup(ctx, &redis.XReadGroupArgs{Group: "relay", Consumer: "relay-" + q.Prefix, Streams: []string{stream, ">"}, Count: 10, Block: time.Second}).Result()
		if errors.Is(readErr, redis.Nil) {
			return nil
		}
		if readErr != nil {
			return readErr
		}
		for _, group := range groups {
			messages = append(messages, group.Messages...)
		}
	}
	for _, message := range messages {
		payload, ok := message.Values["event"].(string)
		if !ok {
			return errors.New("stream payload missing")
		}
		var event Event
		if err := json.Unmarshal([]byte(payload), &event); err != nil {
			return err
		}
		if err := q.Writer.WriteMessages(ctx, kafka.Message{Key: []byte(event.ID), Value: []byte(payload)}); err != nil {
			return err
		}
		if afterPublish != nil {
			if err := afterPublish(); err != nil {
				return err
			}
		}
		if err := q.Redis.XAck(ctx, stream, "relay", message.ID).Err(); err != nil {
			return err
		}
	}
	return nil
}
func (q *Queue) Consume(ctx context.Context, reader *kafka.Reader) error {
	message, err := reader.FetchMessage(ctx)
	if err != nil {
		return err
	}
	var event Event
	parseErr := json.Unmarshal(message.Value, &event)
	if parseErr != nil || event.Input.CampaignID == nil || event.UserID <= 0 || len(event.ID) < 16 || len(event.ID) > 64 || event.Input.Validate(event.Key) != nil {
		id := fmt.Sprintf("%s:%d:%d", message.Topic, message.Partition, message.Offset)
		if err := q.Store.DeadLetter(ctx, id, "invalid_event", message.Value); err != nil {
			return err
		}
	} else {
		for {
			completeErr := q.Complete(ctx, event)
			if completeErr == nil {
				break
			}
			if errors.Is(completeErr, ErrConflict) || errors.Is(completeErr, ErrInput) {
				id := fmt.Sprintf("%s:%d:%d", message.Topic, message.Partition, message.Offset)
				if err := q.Store.DeadLetter(ctx, id, "invalid_reservation", message.Value); err != nil {
					return err
				}
				break
			}
			retries, redisErr := q.Redis.HIncrBy(ctx, q.Prefix+":attempts", event.ID, 1).Result()
			if redisErr != nil {
				return redisErr
			}
			if retries >= 5 {
				if deadErr := q.Store.DeadLetter(ctx, event.ID, "needs_reconciliation", message.Value); deadErr != nil {
					return deadErr
				}
				_, record, _ := q.keys(*event.Input.CampaignID, event.UserID, event.Key)
				if markErr := q.Redis.HSet(ctx, record, "status", "needs_review").Err(); markErr != nil {
					return markErr
				}
				break
			}
			select {
			case <-ctx.Done():
				return ctx.Err()
			case <-time.After(time.Duration(retries) * 200 * time.Millisecond):
			}
		}
	}
	return reader.CommitMessages(ctx, message)
}
func (q *Queue) PublishOutbox(ctx context.Context, writer *kafka.Writer) error {
	var entries []Outbox
	if err := q.Store.DB.WithContext(ctx).Where("published_at IS NULL AND attempts < 5 AND (lease_until IS NULL OR lease_until < UTC_TIMESTAMP(6))").Limit(10).Find(&entries).Error; err != nil {
		return err
	}
	for _, entry := range entries {
		changed := q.Store.DB.WithContext(ctx).Model(&Outbox{}).Where("id=? AND published_at IS NULL AND (lease_until IS NULL OR lease_until < UTC_TIMESTAMP(6))", entry.ID).Updates(map[string]any{"lease_until": time.Now().UTC().Add(30 * time.Second), "attempts": entry.Attempts + 1})
		if changed.Error != nil {
			return changed.Error
		}
		if changed.RowsAffected == 0 {
			continue
		}
		if err := writer.WriteMessages(ctx, kafka.Message{Key: []byte(entry.ID), Value: []byte(entry.Payload), Headers: []kafka.Header{{Key: "event_id", Value: []byte(entry.ID)}, {Key: "event_type", Value: []byte(entry.EventType)}}}); err != nil {
			return err
		}
		if err := q.Store.DB.WithContext(ctx).Model(&Outbox{}).Where("id=?", entry.ID).Update("published_at", time.Now().UTC()).Error; err != nil {
			return err
		}
	}
	return nil
}
func ParseID(raw string) (int64, error) {
	id, err := strconv.ParseInt(raw, 10, 64)
	if err != nil || id <= 0 {
		return 0, ErrInput
	}
	return id, nil
}
