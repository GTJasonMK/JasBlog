package httpapi

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"runtime/debug"
	"strings"
	"sync/atomic"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v5"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/propagation"
	"go.opentelemetry.io/otel/trace"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
	"jaslearning/orders/internal/order"
)

type Config struct {
	JWTSecret         string
	MockPaymentSecret string
	AllowMockPayment  bool
	TrustedProxies    []string
}

func Router(store *order.Store, queue *order.Queue, config Config) (http.Handler, error) {
	if store == nil || queue == nil || queue.Redis == nil {
		return nil, errors.New("database and queue dependencies required")
	}
	if len(config.JWTSecret) < 32 {
		return nil, errors.New("JWT_SECRET must contain at least 32 bytes")
	}
	if config.AllowMockPayment && len(config.MockPaymentSecret) < 32 {
		return nil, errors.New("MOCK_PAYMENT_SECRET must contain at least 32 bytes")
	}
	gin.EnableJsonDecoderDisallowUnknownFields()
	router := gin.New()
	router.Use(gin.CustomRecoveryWithWriter(io.Discard, func(c *gin.Context, recovered any) {
		log.Printf("panic route=%s type=%T stack=%s", c.FullPath(), recovered, debug.Stack())
		c.AbortWithStatusJSON(500, gin.H{"error": "INTERNAL_ERROR"})
	}))
	if err := router.SetTrustedProxies(config.TrustedProxies); err != nil {
		return nil, err
	}
	var total, failed atomic.Int64
	router.Use(func(c *gin.Context) {
		c.Request.Body = http.MaxBytesReader(c.Writer, c.Request.Body, 16*1024)
		id := rand.Text()
		c.Header("X-Request-Id", id)
		started := time.Now()
		c.Next()
		total.Add(1)
		if c.Writer.Status() >= 500 {
			failed.Add(1)
		}
		fmt.Printf("request_id=%s trace_id=%s method=%s route=%s status=%d duration_ms=%d\n", id, trace.SpanContextFromContext(c.Request.Context()).TraceID(), c.Request.Method, c.FullPath(), c.Writer.Status(), time.Since(started).Milliseconds())
	})
	router.Use(func(c *gin.Context) {
		ctx := otel.GetTextMapPropagator().Extract(c.Request.Context(), propagation.HeaderCarrier(c.Request.Header))
		ctx, span := otel.Tracer("learning-http").Start(ctx, c.Request.Method)
		span.SetAttributes(attribute.String("request.id", c.Writer.Header().Get("X-Request-Id")))
		defer span.End()
		c.Request = c.Request.WithContext(ctx)
		c.Next()
		span.SetName(c.Request.Method + " " + c.FullPath())
	})
	router.GET("/healthz", func(c *gin.Context) { c.JSON(200, gin.H{"status": "alive"}) })
	router.GET("/readyz", func(c *gin.Context) {
		ctx, cancel := context.WithTimeout(c.Request.Context(), time.Second)
		defer cancel()
		pool, err := store.DB.DB()
		if err == nil {
			err = pool.PingContext(ctx)
		}
		if err == nil {
			err = queue.Redis.Ping(ctx).Err()
		}
		if err != nil {
			c.JSON(503, gin.H{"status": "unavailable"})
			return
		}
		c.JSON(200, gin.H{"status": "ready"})
	})
	router.GET("/metrics", func(c *gin.Context) {
		c.Data(200, "text/plain; version=0.0.4", []byte(fmt.Sprintf("# TYPE learning_requests_total counter\nlearning_requests_total %d\n# TYPE learning_server_errors_total counter\nlearning_server_errors_total %d\n", total.Load(), failed.Load())))
	})
	router.POST("/api/v1/auth/login", func(c *gin.Context) {
		address := fmt.Sprintf("%x", sha256.Sum256([]byte(c.ClientIP())))
		attempts, err := queue.Redis.Eval(c.Request.Context(), "local n=redis.call('INCR',KEYS[1]);if n==1 then redis.call('EXPIRE',KEYS[1],60) end;return n", []string{queue.Prefix + ":login:" + address}).Int64()
		if err != nil {
			fail(c, err)
			return
		}
		if attempts > 20 {
			c.Header("Retry-After", "60")
			c.JSON(429, gin.H{"error": "RATE_LIMITED"})
			return
		}
		var input struct {
			Email    string `json:"email"`
			Password string `json:"password"`
		}
		if decode(c, &input) != nil || len(input.Email) < 3 || len(input.Email) > 254 || len(input.Password) < 12 || len(input.Password) > 72 {
			fail(c, order.ErrInput)
			return
		}
		var user order.User
		err = store.DB.WithContext(c.Request.Context()).Where("email=?", strings.ToLower(input.Email)).First(&user).Error
		if err != nil && !errors.Is(err, gorm.ErrRecordNotFound) {
			fail(c, err)
			return
		}
		if err != nil || bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(input.Password)) != nil {
			c.JSON(401, gin.H{"error": "LOGIN_FAILED"})
			return
		}
		token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.RegisteredClaims{Issuer: "jas-learning", Audience: []string{"orders"}, Subject: fmt.Sprint(user.ID), ExpiresAt: jwt.NewNumericDate(time.Now().Add(time.Hour)), IssuedAt: jwt.NewNumericDate(time.Now()), ID: rand.Text()})
		signed, err := token.SignedString([]byte(config.JWTSecret))
		if err != nil {
			fail(c, err)
			return
		}
		c.JSON(200, gin.H{"access_token": signed, "expires_in": 3600})
	})
	authorized := router.Group("/api/v1")
	authorized.Use(func(c *gin.Context) {
		raw := strings.TrimPrefix(c.GetHeader("Authorization"), "Bearer ")
		claims := &jwt.RegisteredClaims{}
		_, err := jwt.ParseWithClaims(raw, claims, func(token *jwt.Token) (any, error) { return []byte(config.JWTSecret), nil }, jwt.WithValidMethods([]string{"HS256"}), jwt.WithIssuer("jas-learning"), jwt.WithAudience("orders"), jwt.WithExpirationRequired())
		userID, idErr := order.ParseID(claims.Subject)
		if err != nil || idErr != nil {
			c.AbortWithStatusJSON(401, gin.H{"error": "UNAUTHENTICATED"})
			return
		}
		c.Set("userID", userID)
		c.Next()
	})
	authorized.GET("/products/:id", func(c *gin.Context) {
		id, err := order.ParseID(c.Param("id"))
		if err != nil {
			fail(c, err)
			return
		}
		var product order.Product
		err = store.DB.WithContext(c.Request.Context()).First(&product, id).Error
		if err != nil {
			fail(c, err)
			return
		}
		c.JSON(200, product)
	})
	authorized.GET("/campaigns/:id", func(c *gin.Context) {
		id, err := order.ParseID(c.Param("id"))
		if err != nil {
			fail(c, err)
			return
		}
		var campaign order.Campaign
		err = store.DB.WithContext(c.Request.Context()).First(&campaign, id).Error
		if err != nil {
			fail(c, err)
			return
		}
		c.JSON(200, campaign)
	})
	authorized.POST("/orders", func(c *gin.Context) {
		var input order.Input
		if decode(c, &input) != nil || input.CampaignID != nil {
			fail(c, order.ErrInput)
			return
		}
		result, err := store.Create(c.Request.Context(), c.MustGet("userID").(int64), c.GetHeader("Idempotency-Key"), input)
		if err != nil {
			fail(c, err)
			return
		}
		c.JSON(201, result)
	})
	authorized.GET("/orders/:id", func(c *gin.Context) {
		result, err := store.Find(c.Request.Context(), c.MustGet("userID").(int64), c.Param("id"))
		if err != nil {
			fail(c, err)
			return
		}
		c.JSON(200, result)
	})
	authorized.POST("/campaigns/:id/claims", func(c *gin.Context) {
		campaign, err := order.ParseID(c.Param("id"))
		if err != nil {
			fail(c, err)
			return
		}
		var input order.Input
		if decode(c, &input) != nil || input.CampaignID != nil {
			fail(c, order.ErrInput)
			return
		}
		id, err := queue.Claim(c.Request.Context(), c.MustGet("userID").(int64), campaign, c.GetHeader("Idempotency-Key"), input)
		if err != nil {
			fail(c, err)
			return
		}
		c.JSON(202, gin.H{"request_id": id, "status_url": fmt.Sprintf("/api/v1/campaigns/%d/requests/%s", campaign, c.GetHeader("Idempotency-Key"))})
	})
	authorized.GET("/campaigns/:id/requests/:key", func(c *gin.Context) {
		campaign, err := order.ParseID(c.Param("id"))
		if err != nil {
			fail(c, err)
			return
		}
		result, err := queue.Status(c.Request.Context(), c.MustGet("userID").(int64), campaign, c.Param("key"))
		if err != nil {
			fail(c, err)
			return
		}
		c.JSON(200, result)
	})
	if config.AllowMockPayment {
		router.POST("/api/v1/payments/mock-callback", func(c *gin.Context) {
			if subtle.ConstantTimeCompare([]byte(c.GetHeader("X-Mock-Secret")), []byte(config.MockPaymentSecret)) != 1 {
				c.JSON(401, gin.H{"error": "UNAUTHENTICATED"})
				return
			}
			var input struct {
				OrderID     string `json:"order_id"`
				ProviderRef string `json:"provider_ref"`
				Amount      int64  `json:"amount_cents"`
			}
			if decode(c, &input) != nil {
				fail(c, order.ErrInput)
				return
			}
			if err := store.Pay(c.Request.Context(), input.OrderID, input.ProviderRef, input.Amount); err != nil {
				fail(c, err)
				return
			}
			c.Status(204)
		})
	}
	return router, nil
}
func fail(c *gin.Context, err error) {
	status, code := 503, "DEPENDENCY_FAILURE"
	switch {
	case errors.Is(err, order.ErrInput):
		status, code = 400, "INVALID_INPUT"
	case errors.Is(err, order.ErrConflict):
		status, code = 409, "REQUEST_CONFLICT"
	case errors.Is(err, order.ErrSoldOut):
		status, code = 409, "SOLD_OUT"
	case errors.Is(err, order.ErrNotFound) || errors.Is(err, gorm.ErrRecordNotFound):
		status, code = 404, "NOT_FOUND"
	}
	c.AbortWithStatusJSON(status, gin.H{"error": code})
}
func decode(c *gin.Context, value any) error {
	decoder := json.NewDecoder(c.Request.Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(value); err != nil {
		return err
	}
	var trailing any
	if err := decoder.Decode(&trailing); !errors.Is(err, io.EOF) {
		return order.ErrInput
	}
	return nil
}
