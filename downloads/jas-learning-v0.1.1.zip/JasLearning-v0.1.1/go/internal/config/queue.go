package config

import (
	"errors"
	"os"
	"regexp"
)

type QueueNames struct {
	Prefix string
	Claims string
	Events string
	Group  string
}

var validPrefix = regexp.MustCompile(`^[a-z0-9_-]{1,64}$`)

func LoadQueueNames() (QueueNames, error) {
	prefix := os.Getenv("QUEUE_PREFIX")
	if prefix == "" {
		prefix = "learning"
	}
	if !validPrefix.MatchString(prefix) {
		return QueueNames{}, errors.New("QUEUE_PREFIX must contain 1..64 lowercase letters, digits, _ or -")
	}
	return QueueNames{prefix, prefix + "-claims", prefix + "-order-events", prefix + "-orders"}, nil
}
