package config

import (
	"crypto/tls"
	"crypto/x509"
	"errors"
	"github.com/segmentio/kafka-go"
	"github.com/segmentio/kafka-go/sasl"
	"github.com/segmentio/kafka-go/sasl/scram"
	"os"
	"strings"
	"time"
)

type Kafka struct {
	Brokers   []string
	Transport *kafka.Transport
	Dialer    *kafka.Dialer
}

func LoadKafka() (*Kafka, error) {
	brokers := strings.Split(os.Getenv("KAFKA_BROKERS"), ",")
	if brokers[0] == "" {
		return nil, errors.New("KAFKA_BROKERS required")
	}
	var security *tls.Config
	if os.Getenv("KAFKA_TLS") == "true" {
		security = &tls.Config{MinVersion: tls.VersionTLS12}
		if path := os.Getenv("KAFKA_CA_FILE"); path != "" {
			pem, err := os.ReadFile(path)
			if err != nil {
				return nil, err
			}
			roots, err := x509.SystemCertPool()
			if err != nil {
				return nil, err
			}
			if !roots.AppendCertsFromPEM(pem) {
				return nil, errors.New("KAFKA_CA_FILE contains no certificates")
			}
			security.RootCAs = roots
		}
	}
	var mechanism sasl.Mechanism
	username, password := os.Getenv("KAFKA_SASL_USER"), os.Getenv("KAFKA_SASL_PASSWORD")
	if username != "" || password != "" {
		if username == "" || password == "" || security == nil {
			return nil, errors.New("Kafka SCRAM requires TLS and both credentials")
		}
		var err error
		mechanism, err = scram.Mechanism(scram.SHA512, username, password)
		if err != nil {
			return nil, err
		}
	}
	return &Kafka{brokers, &kafka.Transport{TLS: security, SASL: mechanism}, &kafka.Dialer{Timeout: 5 * time.Second, TLS: security, SASLMechanism: mechanism}}, nil
}
func (settings *Kafka) Writer(topic string) *kafka.Writer {
	return &kafka.Writer{Addr: kafka.TCP(settings.Brokers...), Topic: topic, RequiredAcks: kafka.RequireAll, WriteTimeout: 5 * time.Second, Transport: settings.Transport}
}
func (settings *Kafka) Reader(topic, group string) *kafka.Reader {
	return kafka.NewReader(kafka.ReaderConfig{Brokers: settings.Brokers, Topic: topic, GroupID: group, CommitInterval: 0, MaxBytes: 1 << 20, Dialer: settings.Dialer})
}
