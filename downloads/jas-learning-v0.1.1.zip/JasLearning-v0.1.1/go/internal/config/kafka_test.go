package config

import "testing"

func TestKafkaCredentialBoundary(t *testing.T) {
	t.Setenv("KAFKA_BROKERS", "localhost:9092")
	t.Setenv("KAFKA_TLS", "")
	t.Setenv("KAFKA_SASL_USER", "")
	t.Setenv("KAFKA_SASL_PASSWORD", "")
	settings, err := LoadKafka()
	if err != nil {
		t.Fatal(err)
	}
	settings.Transport.CloseIdleConnections()
	t.Setenv("KAFKA_SASL_USER", "worker")
	t.Setenv("KAFKA_SASL_PASSWORD", "test-only-password")
	if _, err = LoadKafka(); err == nil {
		t.Fatal("credentials must not cross plaintext connection")
	}
	t.Setenv("KAFKA_TLS", "true")
	settings, err = LoadKafka()
	if err != nil {
		t.Fatal(err)
	}
	defer settings.Transport.CloseIdleConnections()
	if settings.Transport.TLS.InsecureSkipVerify {
		t.Fatal("verification disabled")
	}
}

func TestQueueNames(t *testing.T) {
	t.Setenv("QUEUE_PREFIX", "own_test")
	names, err := LoadQueueNames()
	if err != nil || names.Claims != "own_test-claims" || names.Group != "own_test-orders" {
		t.Fatal(names, err)
	}
	t.Setenv("QUEUE_PREFIX", "other{slot}")
	if _, err = LoadQueueNames(); err == nil {
		t.Fatal("unsafe prefix accepted")
	}
}
