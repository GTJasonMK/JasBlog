"""只复制已经核对的模型产物，构建有明确模型版本的推理镜像。"""

import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
from tempfile import TemporaryDirectory
from urllib.parse import urlsplit
from learning.artifacts import verify, sha256

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("kind", choices=("forecast", "vision"))
    parser.add_argument("directory", type=Path)
    parser.add_argument(
        "--host-proxy",
        action="store_true",
        help="显式使用 Linux 本机无认证 HTTP 代理构建",
    )
    args = parser.parse_args()
    network = []
    if args.host_proxy:
        proxies = [
            os.environ.get(name)
            for name in ("http_proxy", "https_proxy")
            if os.environ.get(name)
        ]
        if not proxies:
            raise ValueError("未配置本机 HTTP 代理")
        for proxy in proxies:
            value = urlsplit(proxy)
            if (
                value.scheme != "http"
                or value.hostname not in {"127.0.0.1", "localhost", "::1"}
                or value.username
                or value.password
            ):
                raise ValueError("此选项只接纳本机无认证代理，凭据不能通过构建参数传递")
        network = [
            "--network",
            "host",
            "--build-arg",
            "http_proxy",
            "--build-arg",
            "https_proxy",
        ]
    metadata = verify(args.directory, args.kind)
    artifact_hash = sha256(args.directory / "artifact.json")
    if not re.fullmatch(r"[a-zA-Z0-9_.-]{1,64}", metadata["version"]):
        raise ValueError("模型版本不适合作为镜像标签")
    version = (ROOT / "VERSION").read_text().strip()
    runtime_image = f"jaslearning/python-api:{version}"
    base_id = json.loads(
        subprocess.check_output(
            ["docker", "image", "inspect", runtime_image], text=True
        )
    )[0]["Id"]
    tag = f"jaslearning/{args.kind}:{version}-{metadata['version']}"
    existing = subprocess.check_output(
        ["docker", "image", "ls", "--filter", f"reference={tag}", "-q"], text=True
    ).strip()
    if existing:
        actual = json.loads(
            subprocess.check_output(["docker", "image", "inspect", tag], text=True)
        )[0]
        if (
            actual["Config"].get("Labels", {}).get("learning.model.sha256")
            != metadata["sha256"]
            or actual["Config"].get("Labels", {}).get("learning.artifact.sha256")
            != artifact_hash
            or actual["Config"].get("Labels", {}).get("learning.runtime.id") != base_id
        ):
            raise RuntimeError("镜像标签已对应另一模型，不能覆盖")
        print(f"已存在且模型摘要相同：{tag}")
        return
    with TemporaryDirectory(prefix="learning-model-") as temporary:
        context = Path(temporary)
        (context / "model").mkdir()
        for name in ("artifact.json", metadata["file"]):
            shutil.copyfile(args.directory / name, context / "model" / name)
        shutil.copyfile(ROOT / "python/Dockerfile.inference", context / "Dockerfile")
        shutil.copyfile(
            ROOT / "python/requirements-vision.lock",
            context / "requirements-vision.lock",
        )
        subprocess.run(
            [
                "docker",
                "build",
                *network,
                "--build-arg",
                f"PYTHON_RUNTIME_IMAGE={runtime_image}",
                "--label",
                f"learning.model.sha256={metadata['sha256']}",
                "--label",
                f"learning.model.version={metadata['version']}",
                "--label",
                f"learning.artifact.sha256={artifact_hash}",
                "--label",
                f"learning.runtime.id={base_id}",
                "-t",
                tag,
                str(context),
            ],
            check=True,
        )
    print(tag)


if __name__ == "__main__":
    main()
