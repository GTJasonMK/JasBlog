# JasLearning

四套面向生产实践的独立教学工程。先运行一个完整业务，再沿输入、状态、持久化与失败过程阅读源码。版本为 `0.1.0`。

| 方向 | 入口 | 业务成果 |
|---|---|---|
| 数据库 | [database](database/README.md) | 并发下单、权限拒绝、独立恢复与迁移续跑 |
| TypeScript | [typescript](typescript/README.md) | 有会话和资源隔离的多用户任务管理 |
| Go | [go](go/README.md) | 事务订单、异步受理、消息重放和对账 |
| Python | [python](python/README.md) | 可续跑 ETL、任务 API、需求预测与图像识别 |

每套独立安装与测试，不要求一次启动全部服务。源码和测试共同定义行为，博客讲解对应固定版本。数据库附件从本仓库生成，博客不维护第二份手写源码。

## 教学阶段

先做成功路径与输入验证，再验证并发、越权和中断；最后阅读 [Kubernetes 配置讲解](docs/kubernetes.md) 与发布恢复流程。各工程 README 给出这一条路径的文件和命令。

阶段标签由 `scripts/tag-stage.py` 在对应检查通过、工作区已提交时创建。阶段是源码历史，不是复制目录；未通过的阶段不打标签。检查结果和当前未验证范围见 [实施记录](docs/implementation.md)。

本轮按数据库、TypeScript、Go、Python 保存了独立阶段提交与标签；后续新增版本可使用该脚本继续校验和打标。最终通过范围见 [验证记录](docs/verification.md)，192 篇原文章的应用位置见 [章节覆盖表](docs/coverage.md)。

## 环境和数据

Linux、Docker Engine / Compose、Node.js 24、Go 1.27.4、Python 3.12 以上，本轮实测 Python 3.14.7。各项目通过锁文件固定依赖。`.env.example` 只声明字段，真实凭据由本机环境提供。原始数据、模型、备份和日志保存在 `.local/`，不进入下载包。

后端单测使用 60 秒上限；集成、训练、恢复和浏览器检查分别执行。数据库测试针对专用数据库并使用事务或唯一夹具，失败保留证据。日常停止不删除数据卷。
